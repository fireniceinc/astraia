# CPL16-R
Clean-room relational redesign of CPL16 for Architecture B / Astraia.

This prototype deliberately separates machine-semantic transformations from ARM64's ordinary arithmetic mechanics. It implements the proposed 16-bit word shape, three projections, 3x9 register addressing, self-inverse MIRROR, 13-rule inference IDs, and 231 gate IDs.

It is an executable semantic scaffold, not yet the final Astraia runtime or phone image.
