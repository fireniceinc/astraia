# CPL16-R v0.1 clean-room specification

CPL16-R replaces the earlier flat-opcode prototype. ARM64 remains responsible for ordinary arithmetic and register mechanics. CPL16-R represents Astraia-native relational transformations.

## 16-bit word
Bits 15..14: FORM (2 bits)
- 00 atom
- 01 relation
- 10 transform
- 11 control

Bits 13..12: VIEW (2 bits)
- 00 center/unprojected
- 01 Abraham/structure
- 10 David/action
- 11 Solomon/judgment

Bits 11..10: REGISTER (2 bits)
- 00 center/local
- 01 units register
- 10 tens register
- 11 hundreds register

Bits 9..6: POSITION (4 bits)
- 0 center/unplaced
- 1..9 manifested relational position
- 10..15 reserved

Bits 5..0: OP (6 bits)
- semantic operation within FORM

The same 16-bit shape is used at every recursion depth. Extension words carry deeper coordinates or references rather than changing the grammar.

## Core transform operations
0 NOOP: state preserving.
1 MIRROR: self-inverse orientation transform. Runtime invariant: MIRROR(MIRROR(x)) = x.
2 RELATE: establish typed relation.
3 PROJECT: expose one view without changing the underlying atom.
4 INFER: apply one of the 13 reasoning rules supplied by an extension word.
5 GATE: address one pair-relation supplied by an extension word.
6 BOUND: establish/reduce authority boundary.
7 PROBE: bounded observation request.
8 OBSERVE: attach observed result/provenance.
9 CORRECT: supersede without erasing prior state.
10 COMMIT: place a coherent transition into persistent state.
11 RETURN: traverse an explicitly reversible relation.

## Reasoning rules
CPL16-R reserves rule identifiers 1..13 for formalized inference rules. They are not treated as opaque language names internally. Every inferred atom records rule, sources, provenance, and generation.

## Gate space
For the 22-form canonical semantic set, unordered distinct pairs total 231. CPL16-R stores a gate ID of 0..230 in an extension word. Direction is separate from gate identity.

## 27-position register hypothesis
Architecture B also recognizes a 3 x 9 coordinate register (units/tens/hundreds). This is an addressing/register layer, not a claim that all 27 Hebrew letter forms are distinct CPL16 opcodes.

## Clean-room constraint
The historical sources motivate mathematical structures to test. CPL16-R semantics are newly specified here and must stand or fall by deterministic machine usefulness, not symbolism.
