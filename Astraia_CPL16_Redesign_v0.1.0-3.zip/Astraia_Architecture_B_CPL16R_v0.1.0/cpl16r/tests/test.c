#include "cpl16r.h"
#include <assert.h>
#include <stdio.h>
int main(void){cpl16r_decoded d; cpl16r_atom a={.id=1,.source_a=2,.source_b=3};
cpl16r_word w=cpl16r_encode(F_TRANSFORM,V_SOLOMON,R_TENS,7,OP_MIRROR);assert(cpl16r_decode(w,&d));assert(d.view==V_SOLOMON&&d.reg==R_TENS&&d.pos==7);assert(cpl16r_apply(&d,&a,0)&&a.mirrored==1);assert(cpl16r_apply(&d,&a,0)&&a.mirrored==0);
w=cpl16r_encode(F_TRANSFORM,V_SOLOMON,R_HUNDREDS,9,OP_INFER);assert(cpl16r_decode(w,&d));assert(cpl16r_apply(&d,&a,13)&&a.rule==13);assert(!cpl16r_apply(&d,&a,14));
w=cpl16r_encode(F_RELATION,V_ABRAHAM,R_UNITS,3,OP_GATE);assert(cpl16r_decode(w,&d));assert(cpl16r_apply(&d,&a,230)&&a.gate==230);assert(!cpl16r_apply(&d,&a,231));puts("CPL16-R clean-room tests passed");return 0;}
