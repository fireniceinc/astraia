#ifndef CPL16R_H
#define CPL16R_H
#include <stdint.h>
typedef uint16_t cpl16r_word;
typedef enum {F_ATOM=0,F_RELATION=1,F_TRANSFORM=2,F_CONTROL=3} cpl16r_form;
typedef enum {V_CENTER=0,V_ABRAHAM=1,V_DAVID=2,V_SOLOMON=3} cpl16r_view;
typedef enum {R_CENTER=0,R_UNITS=1,R_TENS=2,R_HUNDREDS=3} cpl16r_register;
typedef enum {OP_NOOP=0,OP_MIRROR=1,OP_RELATE=2,OP_PROJECT=3,OP_INFER=4,OP_GATE=5,OP_BOUND=6,OP_PROBE=7,OP_OBSERVE=8,OP_CORRECT=9,OP_COMMIT=10,OP_RETURN=11} cpl16r_op;
typedef struct {uint8_t form,view,reg,pos,op;} cpl16r_decoded;
typedef struct {uint64_t id;uint64_t source_a;uint64_t source_b;uint64_t provenance;uint32_t generation;uint16_t gate;uint8_t rule;uint8_t view;uint8_t reg;uint8_t pos;uint8_t mirrored;uint8_t committed;} cpl16r_atom;
cpl16r_word cpl16r_encode(uint8_t form,uint8_t view,uint8_t reg,uint8_t pos,uint8_t op);
int cpl16r_decode(cpl16r_word w,cpl16r_decoded*out);
int cpl16r_apply(const cpl16r_decoded*d,cpl16r_atom*a,uint16_t ext);
#endif
