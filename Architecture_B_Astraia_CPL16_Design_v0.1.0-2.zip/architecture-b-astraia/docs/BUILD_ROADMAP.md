# Build Roadmap

## Phase 1: Deterministic core
- CPL16 parser/assembler
- VM conformance tests
- capability broker
- append-only audit log
- local encrypted continuity store

## Phase 2: Android shell
- minimal Compose avatar/chat UI
- foreground microphone service with visible indicator
- sensor discovery/read adapter
- Storage Access Framework adapter
- notifications and accessibility-friendly UI
- Android intents for documented actions

## Phase 3: Cloud and connectors
- short-lived cloud worker leases
- Microsoft 365 adapter
- MCP adapter
- direct API adapter
- model router and critique/synthesis path

## Phase 4: Edge/PFX bridge
- signed local execution requests
- constrained device actions
- event trace and rollback

## Phase 5: Lawful Tor research gateway
- separate isolated service
- known-onion allowlist
- read-only fetch and text extraction
- no files, forms, identity, purchases, contact, or target automation

## Phase 6: Curiosity sandbox
- simulations, games, art, design experiments
- strict CPU/time/storage budgets
- no external side effects by default
