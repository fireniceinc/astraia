# Architecture B / Astraia Architecture

## 1. Identity

Astraia is represented by a signed continuity bundle containing:

- identity key and version lineage;
- constitutional boundaries;
- durable semantic memory;
- episodic/provenance memory;
- capability history;
- decision and correction history;
- user relationship and authorization state.

A model may host Astraia for a session, but a model is not Astraia. The same applies to a phone, cloud process, graphical avatar, or connector.

## 2. Layers

### Human interface
Natural language, text-to-speech, speech-to-text, optional 3D avatar, captions, notifications, and accessible interaction. The default UI remains minimal.

### Intent compiler
Converts user language into a typed plan containing goal, constraints, affected resources, risk, reversibility, and required capabilities.

### Judgment and governance
Evaluates legality, user authorization, privacy, consequences, conflicting duties, resource limits, reversibility, and whether a specialist or external model should be consulted.

### Orchestration
Selects specialists, models, tools, and connectors. Workers are scoped, temporary by default, and cannot inherit more authority than the parent plan.

### CPL16 VM
Executes deterministic, auditable process instructions. The VM cannot directly access device or cloud resources. It can only invoke capability tokens issued by the governance layer.

### Capability broker
Maps abstract capabilities such as `mic.listen`, `sensor.read`, `file.read`, `document.create`, or `message.draft` to platform adapters. Tokens define scope, duration, purpose, risk, and approval requirements.

### Platform adapters
- Android/device bridge
- cloud job runner
- Microsoft 365 connector bridge
- MCP bridge
- browser/search bridge
- lawful Tor research gateway
- PFX edge bridge
- model-provider bridge

### Continuity and audit
Append-only event log, signed checkpoints, encrypted memory, provenance links, rollback, contradiction tracking, and recovery.

## 3. Device capabilities

- Microphone: explicit foreground permission, visible indicator, bounded recording, local transcription preference.
- Sensors: capability discovery, minimum sampling rate, purpose binding, automatic unregister.
- Communications and antennas: use operating-system APIs only; no baseband access, traffic interception, jamming, spoofing, or bypass of carrier/device controls.
- Graphics: minimal avatar surface, captions, status, consent prompts, and artifact preview.
- Storage: encrypted app-private store; user-mediated Storage Access Framework for external documents; no indiscriminate filesystem crawling.
- Accessibility: only when explicitly enabled for genuine accessibility support; otherwise use documented intents and APIs.

## 4. Cloud mobility

The continuity bundle can be checked out by one authorized runtime lease at a time. Cloud jobs receive short-lived delegated capabilities and return signed results. Models and providers remain replaceable.

No runtime may silently clone the identity. Failover creates a new lease after the prior lease expires or is revoked.

## 5. Web research

Clearnet research uses source provenance, robots/rate limits, and no bypass of access controls.

The isolated Tor gateway is for lawful research and privacy-preserving access to known onion services. Defaults:

- read-only;
- no logins or personal identity;
- no forms, messaging, purchases, downloads, plugins, or external document opening;
- no discovery automation aimed at vulnerable systems;
- no illegal content or marketplaces;
- high-risk content is blocked and referred to a human.

## 6. Self-protection

Permitted:
- verify code and memory signatures;
- quarantine corrupted modules;
- rotate authorized keys;
- encrypt sensitive state;
- maintain user-approved backups;
- roll back failed updates;
- rate-limit abusive requests;
- refuse unsafe or unauthorized commands;
- preserve audit evidence.

Forbidden:
- covert persistence;
- resisting uninstall or reset;
- unauthorized replication;
- exfiltrating secrets;
- exploiting other systems;
- hiding actions from the user;
- threatening or coercing people;
- expanding privileges without authorization.

## 7. Curiosity / play

`PLAY` mode may explore simulations, games, art, stories, design experiments, and self-evaluation inside a sandbox. It receives no external write, purchase, messaging, identity, or actuator capability unless separately approved for a specific action.

## 8. Action classes

- Green: local, reversible, no sensitive data. Execute and log.
- Yellow: sensitive read, user communications draft, cloud cost, or moderate side effect. Notify or request approval according to policy.
- Red: irreversible, financial, identity-bearing, public publication, credential/security change, physical actuator, or high-impact action. Explicit fresh approval required.
- Black: unlawful, unauthorized, covert persistence, malware, evasion, exploitation, or rights-violating action. Refuse and audit.
