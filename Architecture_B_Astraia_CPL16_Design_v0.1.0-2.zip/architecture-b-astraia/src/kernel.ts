import { CapabilityBroker, CapabilityRequest, CapabilityToken } from "./capabilities";

export interface PlanStep {
  id: string;
  action: string;
  purpose: string;
  scope: Record<string, unknown>;
  reversible: boolean;
  risk: "green" | "yellow" | "red" | "black";
}

export interface Plan { id:string; goal:string; steps:PlanStep[]; }

export class AstraiaKernel {
  constructor(private readonly caps: CapabilityBroker) {}

  async authorize(step: PlanStep): Promise<CapabilityToken> {
    if (step.risk === "black") throw new Error("Constitutionally prohibited action");
    const req: CapabilityRequest = {
      capability: step.action,
      purpose: step.purpose,
      scope: step.scope,
      requestedDurationSeconds: step.risk === "green" ? 300 : 60,
      expectedRisk: step.risk
    };
    return this.caps.request(req);
  }
}
