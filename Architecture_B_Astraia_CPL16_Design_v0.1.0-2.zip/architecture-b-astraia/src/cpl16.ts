export interface VMHost {
  invoke(family: number, op: number, mode: number, operand: number, regs: Uint16Array): Promise<number>;
  audit(event: Record<string, unknown>): Promise<void>;
}

export class CPL16VM {
  readonly regs = new Uint16Array(16);
  ip = 0;
  halted = false;
  steps = 0;

  constructor(readonly words: Uint16Array, readonly host: VMHost, readonly maxSteps = 10000) {}

  async run(): Promise<Uint16Array> {
    while (!this.halted) {
      if (this.steps++ >= this.maxSteps) throw new Error("CPL16 step limit exceeded");
      if (this.ip >= this.words.length) throw new Error("CPL16 instruction pointer out of range");
      const address = this.ip;
      const word = this.words[this.ip++];
      const family = (word >>> 12) & 0xF;
      const mode = (word >>> 8) & 0xF;
      const operand = word & 0xFF;
      const op = operand >>> 4;
      const arg = operand & 0xF;
      await this.host.audit({type:"instruction", address, word, family, op, mode, arg});
      if (family === 0x0 && op === 0x1) { this.halted = true; continue; }
      const status = await this.host.invoke(family, op, mode, arg, this.regs);
      this.regs[8] = status & 0xFFFF;
    }
    return this.regs;
  }
}

export function encode(family:number, mode:number, op:number, arg:number):number {
  for (const value of [family, mode, op, arg]) if (value < 0 || value > 15) throw new Error("nibble out of range");
  return ((family & 15) << 12) | ((mode & 15) << 8) | ((op & 15) << 4) | (arg & 15);
}
