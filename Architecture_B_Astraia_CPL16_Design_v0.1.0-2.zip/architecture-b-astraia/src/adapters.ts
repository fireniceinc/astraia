import { CapabilityToken } from "./capabilities";

export interface DeviceAdapter {
  status(token: CapabilityToken): Promise<Record<string, unknown>>;
  microphone(token: CapabilityToken, seconds: number): Promise<Uint8Array>;
  sensor(token: CapabilityToken, type: string, samples: number): Promise<number[]>;
  render(token: CapabilityToken, artifact: unknown): Promise<void>;
  readDocument(token: CapabilityToken, uri: string): Promise<Uint8Array>;
  writeDocument(token: CapabilityToken, name: string, data: Uint8Array): Promise<string>;
  communicate(token: CapabilityToken, draft: unknown): Promise<{draftId: string}>;
}

export interface WebAdapter {
  search(token: CapabilityToken, query: string): Promise<unknown[]>;
  fetch(token: CapabilityToken, url: string): Promise<unknown>;
}

export interface TorResearchAdapter {
  // Lawful, isolated and read-only by constitutional policy.
  readKnownOnion(token: CapabilityToken, onionUrl: string): Promise<unknown>;
}

export interface CloudAdapter {
  submit(token: CapabilityToken, job: unknown): Promise<string>;
  status(token: CapabilityToken, jobId: string): Promise<unknown>;
  cancel(token: CapabilityToken, jobId: string): Promise<void>;
  result(token: CapabilityToken, jobId: string): Promise<unknown>;
}

export interface ModelAdapter {
  consult(token: CapabilityToken, modelClass: string, prompt: string): Promise<unknown>;
}
