export type Risk = "green" | "yellow" | "red" | "black";

export interface CapabilityToken {
  id: string;
  subject: string;
  capability: string;
  purpose: string;
  scope: Record<string, unknown>;
  risk: Risk;
  issuedAt: string;
  expiresAt: string;
  reversible: boolean;
  userVisible: boolean;
  signature: string;
}

export interface CapabilityRequest {
  capability: string;
  purpose: string;
  scope: Record<string, unknown>;
  requestedDurationSeconds: number;
  expectedRisk: Risk;
}

export interface CapabilityBroker {
  request(req: CapabilityRequest): Promise<CapabilityToken>;
  verify(token: CapabilityToken, capability: string, purpose: string): Promise<boolean>;
  narrow(token: CapabilityToken, scope: Record<string, unknown>): Promise<CapabilityToken>;
  revoke(id: string, reason: string): Promise<void>;
}
