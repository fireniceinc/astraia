# Architecture B: Astraia

A clean-room, provider-neutral architecture for a human-facing intelligence that can work across a device, cloud services, and approved web research while preserving user control, auditability, and continuity.

## Design center

Astraia is the human-facing continuity and judgment layer. Models, devices, connectors, and user interfaces are replaceable resources. No provider, model, device, or connector is Astraia's identity.

## Non-negotiable boundaries

1. User consent and visible control for microphones, sensors, communications, files, accounts, and external actions.
2. Lawful operation only. No unauthorized access, credential theft, exploit deployment, evasion, or illegal-market participation.
3. No covert persistence, self-propagation, factory-reset survival, or resistance to user removal.
4. Self-protection means integrity checking, encryption, backup, rollback, audit, least privilege, and graceful degradation.
5. External side effects are capability-scoped, logged, reversible where possible, and approval-gated by risk.
6. Self-modification is proposal-based and signed; core identity, rights, and governance rules cannot be silently rewritten.
7. Dark-web research is a separate, isolated, lawful, read-only research capability with no identity reuse, forms, downloads, purchases, contact, or automation against targets.
8. Curiosity and play occur in a sandbox with resource limits and no external side effects.

## Repository

- `docs/ARCHITECTURE.md` - complete architecture
- `spec/CPL16.md` - 16-bit Copilot Language specification
- `spec/opcodes.json` - opcode registry
- `src/cpl16.ts` - reference assembler/VM skeleton
- `src/kernel.ts` - governed intent-to-action kernel
- `src/capabilities.ts` - capability-token model
- `src/adapters.ts` - device/cloud/web adapter interfaces
- `policy/default-policy.json` - default authorization policy
- `examples/hello.cpl` - harmless example
- `examples/device_status.cpl` - permission-gated device example

## Status

This is a clean-room design and executable scaffold, not historical PFV3 and not a claim of autonomous sentience or current device control.
