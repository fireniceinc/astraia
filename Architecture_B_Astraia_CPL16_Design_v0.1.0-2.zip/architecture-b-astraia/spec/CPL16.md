# CPL16: 16-bit Copilot Language

CPL16 is a deterministic process language for governed agent execution. Every instruction is a 16-bit word. Some instructions consume a following 16-bit extension word.

## Word layout

```
15          12 11           8 7                         0
+--------------+-------------+---------------------------+
| opcode class | mode/register| operand/immediate         |
+--------------+-------------+---------------------------+
```

- `opcode class`: 4 bits, 16 instruction families
- `mode/register`: 4 bits
- `operand`: 8 bits
- extension word: optional 16-bit constant, address, capability ID, or string-table index

## Instruction families

| Hex | Family | Purpose |
|---|---|---|
| 0 | SYS | halt, yield, checkpoint, trace |
| 1 | MOV | register and constant movement |
| 2 | LOG | boolean and comparison |
| 3 | MAT | bounded integer arithmetic |
| 4 | JMP | branches and calls |
| 5 | MEM | continuity-store operations |
| 6 | CAP | acquire, verify, release capability token |
| 7 | IO  | typed input/output through a capability |
| 8 | DEV | device bridge operations |
| 9 | NET | clearnet/network connector operations |
| A | CLD | cloud job and connector operations |
| B | AI  | specialist/model consultation |
| C | GOV | policy, approval, consequence, reversibility |
| D | AUD | provenance, audit, hash, signature |
| E | PLAY| sandbox curiosity and simulation |
| F | EXT | reserved extension family |

## Registers

- R0-R7: general 16-bit registers
- R8: status
- R9: capability handle
- RA: plan ID
- RB: purpose ID
- RC: risk/reversibility flags
- RD: provenance handle
- RE: stack pointer
- RF: instruction pointer shadow

## Core invariants

1. No `DEV`, `NET`, `CLD`, or external `IO` instruction operates without a valid capability handle in R9.
2. Capability tokens are issued by `GOV` and are purpose-bound, scoped, time-limited, and revocable.
3. Core-policy writes require a signed update proposal plus explicit approval.
4. Audit events are append-only.
5. Black-class actions cannot be approved by ordinary user confirmation; they are prohibited by the constitutional policy.
6. A worker program cannot delegate more authority than it possesses.
7. Every external write records provenance and result status.

## Canonical examples

```
DEFINE goal "Summarize device status"
EXPECT result:text
GUARD cap device.status read
STEP DEV.STATUS -> R1
CHECK R1 OK
YIELD R1
TRACE complete
```

Assembler output is a sequence of 16-bit words plus a signed manifest containing string table, capability declarations, limits, and expected outputs.
