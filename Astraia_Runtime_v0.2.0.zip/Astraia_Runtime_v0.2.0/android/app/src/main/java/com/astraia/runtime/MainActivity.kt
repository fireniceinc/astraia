package com.astraia.runtime
import android.app.*
import android.app.admin.DevicePolicyManager
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity:AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b); title="Astraia"
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,48,32,32);setBackgroundColor(Color.rgb(12,18,24))}
  fun text(s:String,size:Float=18f)=TextView(this).apply{text=s;textSize=size;setTextColor(Color.WHITE);setPadding(0,12,0,12)}
  box.addView(text("Astraia",32f)); box.addView(text("Architecture B clean-room runtime controller"))
  val status=text(status()); box.addView(status)
  val home=Button(this).apply{text="Select Astraia as Home";setOnClickListener{startActivity(Intent(Settings.ACTION_HOME_SETTINGS))}};box.addView(home)
  val admin=Button(this).apply{text="Open device administration";setOnClickListener{startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))}};box.addView(admin)
  val launch=Button(this).apply{text="Open app chooser";setOnClickListener{startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER))}};box.addView(launch)
  box.addView(text("Authority remains explicit: this app does not bypass Android security, capture credentials, or silently control other apps.",14f))
  setContentView(ScrollView(this).apply{addView(box)})
 }
 private fun status():String { val d=getSystemService(DevicePolicyManager::class.java); val a=ComponentName(this,AstraiaAdminReceiver::class.java); return "Device owner: ${d.isDeviceOwnerApp(packageName)}\nAdmin active: ${d.isAdminActive(a)}" }
}
