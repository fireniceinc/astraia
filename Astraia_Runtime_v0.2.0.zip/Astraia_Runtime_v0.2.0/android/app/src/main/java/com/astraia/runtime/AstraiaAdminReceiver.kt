package com.astraia.runtime
import android.app.admin.DeviceAdminReceiver
class AstraiaAdminReceiver: DeviceAdminReceiver()
