# Architecture B
Astraia is the human-facing continuity, reasoning, judgment and collaboration layer. It is not identified with one model, vendor, device, or process. The runtime separates reasoning from authority: proposed actions enter the capability broker, policy is evaluated, an authorized adapter executes, and the audit service records the result.

Components: CPL16 parser/assembler/VM; capability broker; hash-chained signed audit log; encrypted continuity store; contradiction/correction ledger; Android launcher/controller; document/device/model adapters; curiosity sandbox.

Historical boundary: this is clean-room successor work. It is not evidence about Prime Forge V1, V2, PFV3, historical V4, or PFX.
