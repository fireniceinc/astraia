# Android deployment
Normal installation gives Astraia its own app sandbox. Selecting Astraia as the Home app makes it the launcher. Broader dedicated-device controls require device-owner provisioning on a personally owned test phone. Android documents fully managed dedicated devices as admin-controlled devices and permits a custom Home app plus lock-task allowlisting. Accessibility APIs are reserved for genuine assistive use and are not used here as a general control bypass.

The app never silently grants itself authority. Device-owner provisioning may require removing existing accounts or factory resetting, depending on Android provisioning state. Preserve backups first.
