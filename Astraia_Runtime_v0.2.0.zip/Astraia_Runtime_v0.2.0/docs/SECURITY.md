# Security and authority model
1. Deny by default. Every machine action names a capability.
2. User-visible grants. No hidden privilege escalation.
3. Least privilege and expiry. Grants are scoped by action, target and duration.
4. Audit before/after execution. Records are hash chained and signed.
5. Corrections append; history is not silently rewritten.
6. Secrets stay in Android Keystore where available.
7. Device-owner operation is only for a personally owned, deliberately provisioned device.
8. No credential capture, stealth persistence, security bypass, or propagation.
