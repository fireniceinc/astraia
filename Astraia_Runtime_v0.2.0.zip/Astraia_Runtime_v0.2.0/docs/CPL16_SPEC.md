# CPL16 v0.2
Line-oriented deterministic instruction language. UTF-8. Blank lines and lines beginning `#` are ignored.

Instructions: `SET key value`, `GET key`, `EXPECT key value`, `GUARD capability`, `STEP adapter action [json]`, `CHECK key value`, `YIELD value`, `TRACE value`, `LIMIT steps n`, `MODE name`, `BIND name target`, `MAP key value`, `SCHEDULE label epoch_ms`, `HALT`.

Values after the fixed operands are parsed as JSON when valid, otherwise as strings. Execution is bounded by a step limit. `STEP` can run only after `GUARD` confirms an active grant.
