#!/usr/bin/env python3
import json, sys, time, hmac, hashlib, os
from dataclasses import dataclass

class CPL16Error(Exception): pass
@dataclass
class Insn: op:str; args:list; line:int

def atom(s):
    try: return json.loads(s)
    except Exception: return s

def parse(text):
    out=[]
    for n,raw in enumerate(text.splitlines(),1):
        line=raw.strip()
        if not line or line.startswith('#'): continue
        parts=line.split(maxsplit=3); op=parts[0].upper(); a=parts[1:]
        if op in {'SET','EXPECT','CHECK','MAP','BIND'} and len(a)>=2:
            a=[a[0],atom(' '.join(a[1:]))]
        elif op in {'YIELD','TRACE','MODE'} and a: a=[atom(' '.join(a))]
        elif op=='STEP' and len(a)>=2:
            a=[a[0],a[1],atom(a[2]) if len(a)>2 else {}]
        out.append(Insn(op,a,n))
    return out

class Audit:
    def __init__(self,key=b'astraia-development-key'):
        self.key=key; self.prev='0'*64; self.records=[]
    def add(self,event,data):
        body={'seq':len(self.records)+1,'time_ms':int(time.time()*1000),'event':event,'data':data,'prev':self.prev}
        raw=json.dumps(body,sort_keys=True,separators=(',',':')).encode(); digest=hashlib.sha256(raw).hexdigest()
        body['hash']=digest; body['sig']=hmac.new(self.key,digest.encode(),hashlib.sha256).hexdigest(); self.prev=digest; self.records.append(body)

class Broker:
    def __init__(self): self.grants=set()
    def grant(self,c): self.grants.add(c)
    def require(self,c):
        if c not in self.grants: raise CPL16Error('capability denied: '+c)

class VM:
    def __init__(self,broker=None,audit=None,adapters=None):
        self.s={}; self.b=broker or Broker(); self.a=audit or Audit(); self.adapters=adapters or {}; self.limit=1024; self.mode='normal'; self.output=[]; self.guard=None
    def run(self,program):
        for pc,i in enumerate(program):
            if pc>=self.limit: raise CPL16Error('step limit exceeded')
            op,x=i.op,i.args; self.a.add('instruction',{'line':i.line,'op':op})
            if op=='SET' or op=='MAP' or op=='BIND': self.s[str(x[0])]=x[1]
            elif op=='GET': self.output.append(self.s.get(x[0]))
            elif op in {'EXPECT','CHECK'}:
                if self.s.get(x[0])!=x[1]: raise CPL16Error(f'{op} failed at line {i.line}')
            elif op=='GUARD': self.b.require(str(x[0])); self.guard=str(x[0])
            elif op=='STEP':
                if not self.guard: raise CPL16Error('STEP requires GUARD')
                fn=self.adapters.get(str(x[0]));
                if not fn: raise CPL16Error('adapter unavailable: '+str(x[0]))
                self.output.append(fn(str(x[1]),x[2])); self.guard=None
            elif op=='YIELD': self.output.append(x[0] if x else None)
            elif op=='TRACE': self.a.add('trace',x[0] if x else None)
            elif op=='LIMIT': self.limit=int(x[-1])
            elif op=='MODE': self.mode=str(x[0])
            elif op=='SCHEDULE': self.a.add('schedule',{'label':x[0],'epoch_ms':int(x[1])})
            elif op=='HALT': break
            else: raise CPL16Error(f'unknown instruction {op} at line {i.line}')
        return self.output

def main():
    p=parse(open(sys.argv[1],encoding='utf-8').read()); b=Broker(); b.grant('demo.echo')
    vm=VM(broker=b,adapters={'demo':lambda action,payload:{'action':action,'payload':payload}})
    print(json.dumps({'output':vm.run(p),'state':vm.s,'audit':vm.a.records},indent=2))
if __name__=='__main__': main()
