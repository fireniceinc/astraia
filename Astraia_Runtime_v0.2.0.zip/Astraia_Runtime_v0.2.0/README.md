# Astraia Runtime v0.2.0

Clean-room Architecture B implementation. This package contains a runnable CPL16 reference VM, deterministic audit/continuity services, capability broker, correction ledger, Android launcher/controller source, tests, and documentation.

## Status
- Reference runtime: IMPLEMENTED
- CPL16 parser/assembler/VM: IMPLEMENTED and TESTED by included host tests
- Signed hash-chained audit log: IMPLEMENTED (HMAC reference signer)
- Encrypted continuity store: IMPLEMENTED for Android using Android Keystore/AES-GCM; host reference uses an injected cipher
- Android controller/launcher: IMPLEMENTED source; requires local Android SDK build and user installation
- Device-owner mode: OPTIONAL and requires explicit device provisioning/reset
- Arbitrary silent control of every app: NOT IMPLEMENTED; actions require declared capabilities and Android-granted authority

## Quick host test
```bash
python3 runtime/astraia_runtime.py examples/hello.cpl16
python3 -m unittest discover -s tests
```

## Android build
Open `android/` in Android Studio, use JDK 17, then build/install the debug APK. No prebuilt APK is included because this environment does not contain a trusted Android SDK/signing toolchain.
