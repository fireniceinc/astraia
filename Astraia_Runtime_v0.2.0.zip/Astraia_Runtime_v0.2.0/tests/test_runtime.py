import sys, unittest
sys.path.insert(0,'runtime')
from astraia_runtime import *
class T(unittest.TestCase):
 def test_vm(self):
  b=Broker(); b.grant('demo.echo'); v=VM(broker=b,adapters={'demo':lambda a,p:p})
  self.assertEqual(v.run(parse('SET x 1\nEXPECT x 1\nGUARD demo.echo\nSTEP demo run {"a":2}\nYIELD "ok"')), [{'a':2},'ok'])
 def test_deny(self):
  with self.assertRaises(CPL16Error): VM().run(parse('GUARD no'))
 def test_chain(self):
  a=Audit(); a.add('x',{}); a.add('y',{}); self.assertEqual(a.records[1]['prev'],a.records[0]['hash'])
if __name__=='__main__': unittest.main()
