#include "cpl16.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    const cpl16_word p[] = {CPL16_NOP, CPL16_NOP, CPL16_HALT};
    cpl16_vm vm;
    cpl16_init(&vm, p, 3);
    assert(cpl16_run(&vm, 16) == CPL16_HALTED);
    assert(vm.pc == 3);
    assert(vm.executed == 3);
    const cpl16_word bad[] = {0xFFFF};
    cpl16_init(&vm, bad, 1);
    assert(cpl16_step(&vm) == CPL16_FAULT_OPCODE);
    puts("CPL16 core tests passed");
    return 0;
}
