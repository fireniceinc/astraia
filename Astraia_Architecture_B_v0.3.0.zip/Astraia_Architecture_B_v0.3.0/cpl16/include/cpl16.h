#ifndef CPL16_H
#define CPL16_H
#include <stddef.h>
#include <stdint.h>

typedef uint16_t cpl16_word;

enum cpl16_opcode {
    CPL16_NOP  = 0x0000,
    CPL16_HALT = 0x0001
};

typedef enum {
    CPL16_OK = 0,
    CPL16_HALTED = 1,
    CPL16_FAULT_NULL = -1,
    CPL16_FAULT_ALIGN = -2,
    CPL16_FAULT_OPCODE = -3,
    CPL16_FAULT_BOUNDS = -4
} cpl16_status;

typedef struct {
    const cpl16_word *program;
    size_t word_count;
    uint32_t pc;
    uint64_t executed;
    cpl16_status status;
} cpl16_vm;

void cpl16_init(cpl16_vm *vm, const cpl16_word *program, size_t word_count);
cpl16_status cpl16_step(cpl16_vm *vm);
cpl16_status cpl16_run(cpl16_vm *vm, uint64_t budget);
const char *cpl16_status_name(cpl16_status status);
#endif
