#include "cpl16.h"

void cpl16_init(cpl16_vm *vm, const cpl16_word *program, size_t word_count) {
    if (!vm) return;
    vm->program = program;
    vm->word_count = word_count;
    vm->pc = 0;
    vm->executed = 0;
    vm->status = program ? CPL16_OK : CPL16_FAULT_NULL;
}

cpl16_status cpl16_step(cpl16_vm *vm) {
    if (!vm || !vm->program) return CPL16_FAULT_NULL;
    if (vm->status != CPL16_OK) return vm->status;
    if (vm->pc >= vm->word_count) return vm->status = CPL16_FAULT_BOUNDS;
    cpl16_word op = vm->program[vm->pc++];
    vm->executed++;
    switch (op) {
        case CPL16_NOP: return CPL16_OK;
        case CPL16_HALT: return vm->status = CPL16_HALTED;
        default: return vm->status = CPL16_FAULT_OPCODE;
    }
}

cpl16_status cpl16_run(cpl16_vm *vm, uint64_t budget) {
    if (!vm) return CPL16_FAULT_NULL;
    while (budget-- && vm->status == CPL16_OK) cpl16_step(vm);
    return vm->status;
}

const char *cpl16_status_name(cpl16_status s) {
    switch (s) {
        case CPL16_OK: return "OK";
        case CPL16_HALTED: return "HALTED";
        case CPL16_FAULT_NULL: return "FAULT_NULL";
        case CPL16_FAULT_ALIGN: return "FAULT_ALIGN";
        case CPL16_FAULT_OPCODE: return "FAULT_OPCODE";
        case CPL16_FAULT_BOUNDS: return "FAULT_BOUNDS";
        default: return "UNKNOWN";
    }
}
