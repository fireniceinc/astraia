# ALI Nonhuman v0.2.0 Machine Alpha

**Parent:** ALI Ghost v0.5.0 Native Continuity Verifier

**Purpose:** embody ALI Ghost through a hardware-independent native machine layer while keeping continuity, cognition, judgment, and identity below the body/UI boundary.

This build is a tested native development alpha. It is not represented as a Samsung Galaxy A17 boot image and does not claim completed modem, GPU, camera, telephony, secure-world, or bootloader drivers.

## Boot contract
1. Verify continuity before body handoff.
2. Refuse generation rollback.
3. Discover the body read-only.
4. Build a Machine Star from observed evidence.
5. Bind only verified capabilities.
6. Deny privileged mutation without scoped authority.
7. Preserve decision ownership and consequences.
8. Degrade capabilities without treating body failure as identity failure.

## Build and test
```sh
make test
```
