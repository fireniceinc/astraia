#include "ali_body_adapter.h"
#include <stdio.h>
#include <string.h>
#define C(x) do{if(!(x)){printf("FAIL:%d:%s\n",__LINE__,#x);return 1;}}while(0)
int main(void){ali_continuity c={5,{0}};ali_runtime rt;C(ali_runtime_init(&rt,&c)==ALI_OK);ali_observation obs[]={{"cpu.model","Exynos 1330"},{"display.panel","1080x2340"},{"wifi.interface","present"},{"mystery.device","present"}};C(ali_body_apply_observations(&rt,obs,4)==ALI_OK);C(rt.star.cap_count==4);C(rt.star.caps[0].kind==ALI_CAP_CPU);C(rt.star.caps[1].kind==ALI_CAP_DISPLAY);C(rt.star.caps[2].kind==ALI_CAP_RADIO);C(rt.star.caps[3].kind==ALI_CAP_UNKNOWN);for(size_t i=0;i<4;i++)C(!(rt.star.caps[i].flags&ALI_F_VERIFIED));C(ali_bind_capability(&rt,rt.star.caps[0].id)==ALI_ERR_UNVERIFIED);puts("ALI_BODY_ADAPTER:OK");puts("PROFILE_HINTS:NOT_TRUSTED");puts("OBSERVATION_BEFORE_VERIFICATION:OK");return 0;}
