#include "ali_body_adapter.h"
#include <stdio.h>
#include <string.h>
#define C(x) do{if(!(x)){printf("FAIL:%d:%s\n",__LINE__,#x);return 1;}}while(0)
int main(void){
 ali_continuity c={5,{0}}; ali_runtime rt; C(ali_runtime_init(&rt,&c)==ALI_OK); C(rt.star.cap_count==0);
 ali_observation obs[]={{"cpu.detected","unclassified"},{"storage.node","present"},{"unknown.9f","opaque"}};
 C(ali_body_apply_observations(&rt,obs,3)==ALI_OK); C(rt.star.cap_count==3);
 C(rt.star.caps[0].kind==ALI_CAP_CPU); C(rt.star.caps[1].kind==ALI_CAP_STORAGE); C(rt.star.caps[2].kind==ALI_CAP_UNKNOWN);
 for(size_t i=0;i<3;i++){C((rt.star.caps[i].flags&ALI_F_OBSERVED)!=0);C((rt.star.caps[i].flags&ALI_F_VERIFIED)==0);C((rt.star.caps[i].flags&ALI_F_BOUND)==0);C(rt.star.caps[i].authority_mask==0);}
 C(ali_bind_capability(&rt,rt.star.caps[0].id)==ALI_ERR_UNVERIFIED);
 C(ali_authorize(&rt,rt.star.caps[1].id,1)==ALI_ERR_DENIED);
 puts("PROFILE_FREE_BOOTSTRAP:OK"); puts("ZERO_PREDEFINED_CAPABILITIES:OK"); puts("UNKNOWN_PRESERVATION:OK"); puts("UNVERIFIED_BIND:REJECTED"); puts("UNDELEGATED_AUTHORITY:REJECTED"); return 0;
}
