import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'resolver'))
from resolve import resolve
c=json.loads((Path(__file__).parents[1]/'resources/catalog.json').read_text())
assert resolve([],c)==[]
r=resolve(['cpu.model=Exynos 1330','soc=s5e8535','input=present'],c)
assert r and r[0]['class']=='universal-standard'
assert all(x['verified'] is False and x['authorized'] is False for x in r)
assert any(x['id']=='s5e8535-kernel-source' for x in r)
u=resolve(['unknown.device=opaque'],c); assert u==[]
print('HARDWARE_RESOURCE_RESOLVER:OK')
print('PROFILE_FREE_SEED:PRESERVED')
print('RESOURCE_IS_NOT_VERIFICATION:OK')
print('RESOURCE_IS_NOT_AUTHORITY:OK')
print('UNIVERSAL_RESOURCE:PREFERRED')
