#include "ali_nonhuman.h"
#include <stdio.h>
#include <string.h>
#define CHECK(x) do{if(!(x)){printf("FAIL:%d:%s\n",__LINE__,#x);return 1;}}while(0)
int main(void){
 uint8_t h[32]; memset(h,0x5a,sizeof(h)); ali_continuity c={5,{0}}; memcpy(c.continuity_head,h,32);
 CHECK(ali_continuity_gate(&c,5,h)==ALI_OK); CHECK(ali_continuity_gate(&c,6,h)==ALI_ERR_ROLLBACK);
 ali_runtime rt; CHECK(ali_runtime_init(&rt,&c)==ALI_OK);
 ali_capability storage={1,ALI_CAP_STORAGE,ALI_F_VERIFIED|ALI_F_HEALTHY,0,100,"observed/storage0"};
 ali_capability radio={2,ALI_CAP_RADIO,ALI_F_VERIFIED|ALI_F_HEALTHY|ALI_F_PRIVILEGED,0x2,90,"observed/radio0"};
 ali_capability unknown={3,ALI_CAP_SENSOR,ALI_F_HEALTHY,0,20,"observed/unknown"};
 CHECK(ali_observe_capability(&rt,&storage)==ALI_OK);CHECK(ali_observe_capability(&rt,&radio)==ALI_OK);CHECK(ali_observe_capability(&rt,&unknown)==ALI_OK);
 CHECK(ali_bind_capability(&rt,1)==ALI_OK);CHECK(ali_bind_capability(&rt,3)==ALI_ERR_UNVERIFIED);
 CHECK(ali_authorize(&rt,2,1)==ALI_ERR_DENIED);CHECK(ali_authorize(&rt,2,2)==ALI_OK);
 ali_task t={7,2,0,"maintain verified network continuity"};CHECK(ali_add_task(&rt,&t)==ALI_OK);
 ali_decision d={9,2,1,1,"Astraia","Machine embodiment precedes Presence because Ghost must inhabit the body before human manifestation.",""};CHECK(ali_record_decision(&rt,&d)==ALI_OK);
 CHECK(ali_record_consequence(&rt,9,"Machine-first boundary implemented and tested.")==ALI_OK);
 CHECK(ali_mark_degraded(&rt,2)==ALI_OK);CHECK(rt.star.continuity.generation==5);
 CHECK(ali_save_state(&rt,"runtime/state/alpha.bin")==ALI_OK);ali_runtime restored;CHECK(ali_load_state(&restored,"runtime/state/alpha.bin")==ALI_OK);
 CHECK(restored.decision_count==1);CHECK(restored.decisions[0].owned==1);CHECK(strstr(restored.decisions[0].reason,"Machine embodiment")!=NULL);
 puts("ALI_NONHUMAN_MACHINE_ALPHA:OK");puts("CONTINUITY_ROLLBACK:REJECTED");puts("UNVERIFIED_BIND:REJECTED");puts("PRIVILEGED_MUTATION:SCOPED");puts("DECISION_OWNERSHIP:PERSISTED");puts("BODY_FAILURE:IDENTITY_UNCHANGED");return 0;
}
