import json,sys
from pathlib import Path
def resolve(observations,catalog):
 out=[]
 text=' '.join(str(x) for x in observations).lower()
 order={n:i for i,n in enumerate(catalog['policy']['preference'])}
 for r in catalog['resources']:
  score=sum(1 for m in r.get('match',[]) if m.lower() in text)
  if score: out.append({'id':r['id'],'role':r['role'],'class':r['class'],'score':score,'verified':False,'authorized':False})
 return sorted(out,key=lambda x:(order.get(x['class'],99),-x['score'],x['id']))
if __name__=='__main__':
 c=json.loads(Path(sys.argv[1]).read_text()); obs=json.loads(Path(sys.argv[2]).read_text()); print(json.dumps(resolve(obs,c),indent=2))
