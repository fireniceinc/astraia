#!/bin/sh
set -eu
make clean
make test
sha256sum -c SHA256SUMS.txt
