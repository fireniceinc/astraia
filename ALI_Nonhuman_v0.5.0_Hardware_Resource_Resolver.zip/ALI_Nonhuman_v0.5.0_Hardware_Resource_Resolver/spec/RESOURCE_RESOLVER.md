# Hardware Resource Resolver

Decision: keep the Seed profile-free, then provide hardware packages as optional resources. Discovery identifies the actual body first. The resolver may then rank candidate resources, but a resource cannot verify a capability by itself and cannot bind or gain authority automatically.

Flow: unknown body -> observations -> stable hardware identifiers -> resource candidates -> compatibility checks -> staged driver test -> verified capability -> scoped binding.

Universal interfaces are preferred when evidence shows they satisfy the role; target-specific drivers remain fallback resources. Proprietary binaries and firmware are not bundled here.
