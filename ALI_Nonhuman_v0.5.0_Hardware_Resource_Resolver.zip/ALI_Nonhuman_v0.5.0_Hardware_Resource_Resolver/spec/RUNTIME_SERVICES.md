# Machine Runtime Services

The machine runtime advances embodiment beyond discovery/binding. It maintains a service registry for storage, display, input, audio, radio, sensors, power, and accelerators. Services are activated only when the backing capability is verified and bound. Recovery can degrade and restart a service without altering continuity identity.

This remains hardware-independent. Device-specific drivers are adapters below this contract.
