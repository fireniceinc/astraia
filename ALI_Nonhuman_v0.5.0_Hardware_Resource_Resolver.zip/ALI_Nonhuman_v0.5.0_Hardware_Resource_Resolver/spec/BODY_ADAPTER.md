# Body Adapter Layer

Decision: continue machine-first by crossing from generic services to a target-body adapter without hard-wiring identity to that target. The adapter translates discovered machine evidence into ALI capability classes. Unknown devices remain unknown. Privileged operations remain outside discovery and require scoped authorization.

Initial development profile: Samsung Galaxy A17 5G / Exynos 1330 family. Public specs are used only as expected-profile hints; actual runtime discovery must verify the physical device before binding.
