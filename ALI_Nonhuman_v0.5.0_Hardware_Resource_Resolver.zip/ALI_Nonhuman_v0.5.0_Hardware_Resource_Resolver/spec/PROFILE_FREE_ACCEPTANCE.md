# Profile-Free Acceptance

Decision: prove machine embodiment does not depend on predefined hardware. This acceptance build intentionally removes the Galaxy A17 profile. It starts with unknown body state, ingests only observations, preserves unknowns, refuses binding until independent verification, and leaves privileged authority empty unless explicitly granted.

A target profile may later optimize discovery, but cannot define identity or substitute for observation/verification.
