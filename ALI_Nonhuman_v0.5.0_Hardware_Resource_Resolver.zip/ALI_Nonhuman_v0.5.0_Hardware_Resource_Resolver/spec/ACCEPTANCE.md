# Machine Alpha Acceptance

This package accepts only the development boundary:
- compiles as strict C11;
- rejects continuity rollback;
- creates a read-only Machine Star;
- binds only verified capabilities;
- denies unauthorized privileged mutation;
- records an owned decision and consequence;
- serializes and restores machine/task/decision state;
- marks a failed body capability degraded without changing continuity identity.

Later target acceptance:
- actual Stage-0 handoff from Ghost v0.5;
- real-device discovery;
- Samsung Galaxy A17 hardware support;
- reboot persistence on target;
- telephony/data preservation;
- full cold-boot continuity test.
