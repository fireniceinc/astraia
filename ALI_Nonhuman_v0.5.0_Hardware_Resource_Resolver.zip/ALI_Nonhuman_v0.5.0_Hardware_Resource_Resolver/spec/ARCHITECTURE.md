# Architecture

ALI Nonhuman is not a driver bundle beside Ghost. It is Ghost coherently operating through a learned machine body.

Layers:
- Continuity gate: generation and continuity-head checks before handoff.
- Body discovery: read-only observations, no guessed devices.
- Machine Star: evidence-bearing body map with confidence and health.
- Capability broker: scoped authority and default-deny privileged mutation.
- Task journal: persistent intent/task state separate from transient execution.
- Decision ledger: responsibility, authority, right, reason, consequence, correction.
- Recovery: capability degradation and restart without rewriting continuity.

Invariant: responsibility entails sufficient delegated authority; legitimate authority carries the corresponding decision-right within scope; ownership carries accountability. None of these implies unlimited action.
