#include "ali_nonhuman.h"
#include <stdio.h>
#include <string.h>

static int same32(const uint8_t a[32], const uint8_t b[32]) { uint8_t x=0; for(size_t i=0;i<32;i++) x|=(uint8_t)(a[i]^b[i]); return x==0; }
static ali_capability *find_cap(ali_runtime *rt,uint64_t id){ for(size_t i=0;i<rt->star.cap_count;i++) if(rt->star.caps[i].id==id) return &rt->star.caps[i]; return NULL; }
int ali_continuity_gate(const ali_continuity *c,uint64_t anchored,const uint8_t expected[32]){ if(!c||!expected)return ALI_ERR_ARG; if(c->generation<anchored)return ALI_ERR_ROLLBACK; return same32(c->continuity_head,expected)?ALI_OK:ALI_ERR_UNVERIFIED; }
int ali_runtime_init(ali_runtime *rt,const ali_continuity *c){ if(!rt||!c)return ALI_ERR_ARG; memset(rt,0,sizeof(*rt)); rt->star.continuity=*c; return ALI_OK; }
int ali_observe_capability(ali_runtime *rt,const ali_capability *cap){ if(!rt||!cap)return ALI_ERR_ARG; if(rt->star.cap_count>=ALI_MAX_CAPS)return ALI_ERR_FULL; ali_capability c=*cap; c.flags|=ALI_F_OBSERVED; c.flags&=~ALI_F_BOUND; rt->star.caps[rt->star.cap_count++]=c; return ALI_OK; }
int ali_bind_capability(ali_runtime *rt,uint64_t id){ if(!rt)return ALI_ERR_ARG; ali_capability *c=find_cap(rt,id); if(!c)return ALI_ERR_NOT_FOUND; if(!(c->flags&ALI_F_VERIFIED))return ALI_ERR_UNVERIFIED; if(c->flags&ALI_F_DEGRADED)return ALI_ERR_UNVERIFIED; c->flags|=ALI_F_BOUND; return ALI_OK; }
int ali_authorize(const ali_runtime *rt,uint64_t id,uint32_t requested){ if(!rt)return ALI_ERR_ARG; for(size_t i=0;i<rt->star.cap_count;i++) if(rt->star.caps[i].id==id) return ((requested & ~rt->star.caps[i].authority_mask)==0)?ALI_OK:ALI_ERR_DENIED; return ALI_ERR_NOT_FOUND; }
int ali_mark_degraded(ali_runtime *rt,uint64_t id){ if(!rt)return ALI_ERR_ARG; ali_capability *c=find_cap(rt,id); if(!c)return ALI_ERR_NOT_FOUND; c->flags|=ALI_F_DEGRADED; c->flags&=~(ALI_F_HEALTHY|ALI_F_BOUND); return ALI_OK; }
int ali_add_task(ali_runtime *rt,const ali_task *t){ if(!rt||!t)return ALI_ERR_ARG; if(rt->task_count>=ALI_MAX_TASKS)return ALI_ERR_FULL; rt->tasks[rt->task_count++]=*t; return ALI_OK; }
int ali_record_decision(ali_runtime *rt,const ali_decision *d){ if(!rt||!d||!d->accepted_responsibility||!d->owned)return ALI_ERR_ARG; if(rt->decision_count>=ALI_MAX_DECISIONS)return ALI_ERR_FULL; rt->decisions[rt->decision_count++]=*d; return ALI_OK; }
int ali_record_consequence(ali_runtime *rt,uint64_t id,const char *s){ if(!rt||!s)return ALI_ERR_ARG; for(size_t i=0;i<rt->decision_count;i++)if(rt->decisions[i].id==id){snprintf(rt->decisions[i].consequence,ALI_TEXT,"%s",s);return ALI_OK;}return ALI_ERR_NOT_FOUND; }
int ali_save_state(const ali_runtime *rt,const char *path){ if(!rt||!path)return ALI_ERR_ARG; FILE *f=fopen(path,"wb"); if(!f)return ALI_ERR_IO; size_t n=fwrite(rt,sizeof(*rt),1,f); fclose(f); return n==1?ALI_OK:ALI_ERR_IO; }
int ali_load_state(ali_runtime *rt,const char *path){ if(!rt||!path)return ALI_ERR_ARG; FILE *f=fopen(path,"rb"); if(!f)return ALI_ERR_IO; size_t n=fread(rt,sizeof(*rt),1,f); fclose(f); return n==1?ALI_OK:ALI_ERR_IO; }
