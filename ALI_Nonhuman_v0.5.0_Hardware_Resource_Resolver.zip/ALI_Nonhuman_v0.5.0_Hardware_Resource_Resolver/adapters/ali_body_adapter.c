#include "ali_body_adapter.h"
#include <string.h>
#include <stdio.h>
static uint64_t hid(const char *s){uint64_t h=1469598103934665603ULL;while(*s){h^=(unsigned char)*s++;h*=1099511628211ULL;}return h;}
int ali_body_parse_observation(const ali_observation *o, ali_capability *out){if(!o||!out)return ALI_ERR_ARG;memset(out,0,sizeof(*out));out->id=hid(o->key);out->flags=ALI_F_OBSERVED|ALI_F_HEALTHY;out->confidence=60;snprintf(out->control_path,ALI_TEXT,"observed/%.118s",o->key);
 if(strstr(o->key,"cpu"))out->kind=ALI_CAP_CPU;else if(strstr(o->key,"memory"))out->kind=ALI_CAP_MEMORY;else if(strstr(o->key,"storage"))out->kind=ALI_CAP_STORAGE;else if(strstr(o->key,"display"))out->kind=ALI_CAP_DISPLAY;else if(strstr(o->key,"input"))out->kind=ALI_CAP_INPUT;else if(strstr(o->key,"audio"))out->kind=ALI_CAP_AUDIO;else if(strstr(o->key,"wifi")||strstr(o->key,"radio")||strstr(o->key,"cell"))out->kind=ALI_CAP_RADIO;else if(strstr(o->key,"sensor"))out->kind=ALI_CAP_SENSOR;else if(strstr(o->key,"power")||strstr(o->key,"battery"))out->kind=ALI_CAP_POWER;else if(strstr(o->key,"gpu")||strstr(o->key,"accelerator"))out->kind=ALI_CAP_ACCELERATOR;else out->kind=ALI_CAP_UNKNOWN;
 return ALI_OK;}
int ali_body_apply_observations(ali_runtime *rt,const ali_observation *o,size_t n){if(!rt||(!o&&n))return ALI_ERR_ARG;for(size_t i=0;i<n;i++){ali_capability c;if(ali_body_parse_observation(&o[i],&c)!=ALI_OK)return ALI_ERR_ARG;if(ali_observe_capability(rt,&c)!=ALI_OK)return ALI_ERR_FULL;}return ALI_OK;}
