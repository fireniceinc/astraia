#pragma once
#include "ali_nonhuman.h"
typedef struct {char key[ALI_TEXT]; char value[ALI_TEXT];} ali_observation;
int ali_body_parse_observation(const ali_observation *o, ali_capability *out);
int ali_body_apply_observations(ali_runtime *rt,const ali_observation *o,size_t count);
