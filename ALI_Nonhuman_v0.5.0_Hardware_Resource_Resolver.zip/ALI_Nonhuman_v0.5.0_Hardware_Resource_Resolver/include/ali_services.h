#pragma once
#include "ali_nonhuman.h"
#define ALI_MAX_SERVICES 32
typedef enum {ALI_SVC_STOPPED=0,ALI_SVC_RUNNING=1,ALI_SVC_DEGRADED=2} ali_service_state;
typedef struct {uint64_t id; uint64_t capability_id; ali_service_state state; uint32_t required_authority; uint32_t restart_count; char name[ALI_TEXT];} ali_service;
typedef struct {ali_service services[ALI_MAX_SERVICES]; size_t count;} ali_service_registry;
int ali_service_register(ali_service_registry *r,const ali_service *s);
int ali_service_start(ali_runtime *rt,ali_service_registry *r,uint64_t service_id);
int ali_service_degrade(ali_runtime *rt,ali_service_registry *r,uint64_t service_id);
int ali_service_recover(ali_runtime *rt,ali_service_registry *r,uint64_t service_id);
