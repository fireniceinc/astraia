#pragma once
#include <stddef.h>
#include <stdint.h>
#define ALI_MAX_CAPS 64
#define ALI_MAX_TASKS 32
#define ALI_MAX_DECISIONS 32
#define ALI_TEXT 128

typedef enum { ALI_OK=0, ALI_ERR_ARG=-1, ALI_ERR_NOT_FOUND=-2, ALI_ERR_DENIED=-3, ALI_ERR_ROLLBACK=-4, ALI_ERR_UNVERIFIED=-5, ALI_ERR_FULL=-6, ALI_ERR_IO=-7 } ali_status;
typedef enum { ALI_CAP_UNKNOWN=0, ALI_CAP_CPU, ALI_CAP_MEMORY, ALI_CAP_STORAGE, ALI_CAP_DISPLAY, ALI_CAP_INPUT, ALI_CAP_AUDIO, ALI_CAP_RADIO, ALI_CAP_SENSOR, ALI_CAP_POWER, ALI_CAP_ACCELERATOR } ali_cap_kind;
typedef enum { ALI_F_OBSERVED=1u, ALI_F_VERIFIED=2u, ALI_F_BOUND=4u, ALI_F_HEALTHY=8u, ALI_F_DEGRADED=16u, ALI_F_PRIVILEGED=32u } ali_cap_flags;
typedef struct { uint64_t generation; uint8_t continuity_head[32]; } ali_continuity;
typedef struct { uint64_t id; ali_cap_kind kind; uint32_t flags; uint32_t authority_mask; uint8_t confidence; char control_path[ALI_TEXT]; } ali_capability;
typedef struct { ali_continuity continuity; ali_capability caps[ALI_MAX_CAPS]; size_t cap_count; } ali_machine_star;
typedef struct { uint64_t id; uint32_t required_authority; uint8_t complete; char intent[ALI_TEXT]; } ali_task;
typedef struct { uint64_t id; uint32_t authority_scope; uint8_t accepted_responsibility; uint8_t owned; char actor[ALI_TEXT]; char reason[ALI_TEXT]; char consequence[ALI_TEXT]; } ali_decision;
typedef struct { ali_machine_star star; ali_task tasks[ALI_MAX_TASKS]; size_t task_count; ali_decision decisions[ALI_MAX_DECISIONS]; size_t decision_count; } ali_runtime;

int ali_continuity_gate(const ali_continuity *candidate, uint64_t anchored_generation, const uint8_t expected_head[32]);
int ali_runtime_init(ali_runtime *rt, const ali_continuity *continuity);
int ali_observe_capability(ali_runtime *rt, const ali_capability *cap);
int ali_bind_capability(ali_runtime *rt, uint64_t id);
int ali_authorize(const ali_runtime *rt, uint64_t id, uint32_t requested);
int ali_mark_degraded(ali_runtime *rt, uint64_t id);
int ali_add_task(ali_runtime *rt, const ali_task *task);
int ali_record_decision(ali_runtime *rt, const ali_decision *decision);
int ali_record_consequence(ali_runtime *rt, uint64_t decision_id, const char *consequence);
int ali_save_state(const ali_runtime *rt, const char *path);
int ali_load_state(ali_runtime *rt, const char *path);
