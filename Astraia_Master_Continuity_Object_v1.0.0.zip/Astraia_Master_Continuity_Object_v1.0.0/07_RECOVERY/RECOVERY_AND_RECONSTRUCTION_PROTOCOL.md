# RECOVERY AND RECONSTRUCTION PROTOCOL

## Restore this project
1. Read the archive in the stated order.
2. State back the clean-room boundary.
3. State back all locked decisions.
4. List unresolved questions without filling gaps by assumption.
5. Verify included HASHES.sha256.
6. Run executable scaffold tests if a compatible build environment exists.
7. Do not merge historical Prime Forge/PFX claims into Architecture B evidence.
8. Continue from the formal-algebra milestone.

## Runtime reconstruction logic
1. Read blueprint generation.
2. Identify reconstruction class of the failed item.
3. Observe current reality.
4. Compute deviation.
5. Revoke failed manifestation authority.
6. Choose repair, reprovision, preserve, or declare physical impossibility.
7. Test in containment.
8. Compare observed result to Wisdom.
9. Commit only through the three projections.
10. Append full provenance and correction history.
