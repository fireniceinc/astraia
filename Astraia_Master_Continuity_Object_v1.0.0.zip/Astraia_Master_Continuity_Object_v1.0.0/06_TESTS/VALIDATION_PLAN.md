# VALIDATION PLAN

## Semantic tests
- Same blueprint, damaged manifestation -> repair manifestation only.
- New evidence contradicts blueprint -> preserve both; revise only with formal rule and provenance.
- Two contradictory claims without valid resolver -> UNRESOLVED.
- Mirror twice -> original state, only inside declared domain.
- Gate direction A->B differs from B->A while sharing unordered gate identity.
- Correction retains complete predecessor chain.

## Storage tests
- Deterministic identity always routes to the same shard.
- Distribution remains acceptably balanced for sequential, clustered, and adversarial identities.
- Recursive subdivision does not require global reindex.
- Lost shard can be rebuilt only from items classified accordingly.

## Hardware tests
- Read-only probe timeout causes revocation, not system crash.
- Faulty device module cannot access coherence memory.
- Repeated faults cause quarantine.
- Device-unique data cannot be overwritten by reconstruction logic.

## Projection tests
- Abraham catches invariant violation.
- David catches causal/physical mismatch.
- Solomon catches invalid interpretation or exception.
- Shared blueprint defect is detected through external observation/counterexample.

## Comparative benchmarks
Compare against:
- tagged records;
- conventional graph store;
- binary trie;
- flat 16-bit VM;
- previous CPL16 scaffold.
Measure compactness, deterministic routing, recovery, derivation reconstruction, execution overhead, and fault containment.
