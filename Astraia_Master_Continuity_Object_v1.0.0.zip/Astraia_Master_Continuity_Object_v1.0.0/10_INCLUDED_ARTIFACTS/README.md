# INCLUDED ARTIFACTS

These archives are included for executable history and test scaffolding only.
- CPL16-R v0.1.0: first executable relational prototype; binary layout is provisional.
- Architecture B Resilient v0.8.0: earlier hardware-probe and resilience scaffold; architecture is superseded where it conflicts with the master continuity documents.
