# SOURCE CHECKLIST FOR FUTURE RESEARCH

Re-verify from primary or scholarly-quality sources before making historical claims:
- Sefer Yetzirah 1:1-4 and chapter 2 variants.
- Sefer Yetzirah 2:4-5 and the 231 gates.
- Textual history distinguishing Sefer Yetzirah from later Tree-of-Life path assignments.
- Rabbi Ishmael's 13 principles in Sifra/Baraita.
- Hebrew root-pattern morphology and limits of binyan predictability.
- Niqqud, dagesh/mappiq, cantillation, and tagin as distinct notation layers.
- Mispar Gadol treatment of final forms.
- Diamond cubic lattice and tetrahedral coordination.
- Fault-tolerant microkernel, reconciliation, and user-space driver isolation research.
