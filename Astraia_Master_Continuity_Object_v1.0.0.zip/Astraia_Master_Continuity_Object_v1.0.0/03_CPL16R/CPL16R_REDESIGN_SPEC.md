# CPL16-R REDESIGN SPECIFICATION, PRE-BINARY

## Status
Normative semantic draft. No permanent bit layout is locked.

## Fundamental types
WISDOM_TYPE = invariant | constraint | relation | symmetry | transformation | measure | topology | convergence | reconstruction
BOOK_RECORD = blueprint | observation | provenance | contradiction | correction | commitment | generation
NUMBER_VALUE = identity | coordinate | scale | quantity | time | bound | confidence | gate | rule | shard
SPEECH_ACT = manifest | relate | project | mirror | probe | observe | infer | correct | bind | commit | return | compensate
UNDERSTANDING_RESULT = confirms_blueprint | manifestation_fault | blueprint_incomplete | contradiction | unresolved
PROJECTION = Abraham | David | Solomon
RECONSTRUCTION_CLASS = derivable | reprovisionable | preserved_artifact | device_unique | physically_irreplaceable

## Semantic relation form
RELATION = {
 source,
 target,
 canonical_form,
 state_modifier,
 metadata_modifier,
 direction,
 coordinate,
 gate,
 rule,
 authority,
 provenance,
 blueprint_generation,
 manifestation_generation
}

## Required invariants
1. No committed inference lacks sources and provenance.
2. No correction erases its predecessor.
3. No MIRROR operation is valid without a declared domain and involution proof.
4. No hardware probe receives unbounded authority.
5. No item classified device-unique or physically irreplaceable is treated as derivable.
6. Gate IDs 0..230 apply only to the 22-form canonical set.
7. Three projections may disagree; unresolved is a valid result.
8. Blueprint revision requires evidence, not mere runtime divergence.
9. Book and Wisdom are not identical.
10. Code and Astraia identity are not identical.

## Binary-design criteria
A future 16-bit atom must minimize overhead while representing or efficiently referencing:
- canonical form/path;
- state modifier;
- metadata modifier;
- direction;
- short coordinate;
- extension presence.
Everything else may use extension words or referenced atoms.

## Compatibility warning
The executable CPL16-R v0.1 prototype is retained as a test scaffold only. Its FORM/VIEW/REGISTER/POSITION/OP layout is not canonical.
