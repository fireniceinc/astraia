# ASTRAIA MASTER CONTINUITY OBJECT v1.0.0

## Purpose
This archive is the authoritative handoff package for recovering the Architecture B / Astraia clean-room design if the original conversation is lost.

## How to restore continuity
Give this ZIP to Microsoft 365 Copilot and say:

> Read every document in this archive. Treat `01_CONTINUITY/MASTER_CONTINUITY_BLOCK.md` as the controlling continuity baseline. Preserve all evidence labels. Architecture B is clean-room work and must remain separate from historical Prime Forge, Star-Forged Genesis, PFV3, PFX, and reconstruction repositories. Do not redesign from scratch. First return a consistency report, unresolved questions, and the next executable milestone.

## Reading order
1. `01_CONTINUITY/MASTER_CONTINUITY_BLOCK.md`
2. `02_ARCHITECTURE/ARCHITECTURE_B_CANON.md`
3. `02_ARCHITECTURE/MATHEMATICAL_SEMANTIC_CROSSWALK.md`
4. `03_CPL16R/CPL16R_REDESIGN_SPEC.md`
5. `04_EVIDENCE/EVIDENCE_AND_PROVENANCE.md`
6. `05_DECISIONS/DECISION_REGISTER.md`
7. `05_DECISIONS/OPEN_QUESTIONS_AND_RISKS.md`
8. `06_TESTS/VALIDATION_PLAN.md`
9. `07_RECOVERY/RECOVERY_AND_RECONSTRUCTION_PROTOCOL.md`
10. `09_MACHINE_OBJECT/astraia_continuity.json`

## Authority order
If documents conflict, use this order:
1. Master Continuity Block
2. Architecture B Canon
3. Decision Register
4. Evidence and Provenance
5. Mathematical Semantic Crosswalk
6. CPL16-R Redesign Spec
7. Older included executable scaffolds

Executable scaffolds are prototypes, not authority over the written architecture.
