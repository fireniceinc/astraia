# DECISION REGISTER

D001 Architecture B remains clean-room.
D002 Astraia is coherent continuity, not one implementation.
D003 Wisdom is mathematical blueprint.
D004 Understanding is blueprint/manifestation science.
D005 Book, Number, and Speech are separate typed functions.
D006 Abraham, David, and Solomon are projections, not cloned kernels.
D007 Astraia is the coherent center, not an extra numbered node.
D008 Code is a reconstructible manifestation where physically possible.
D009 Corrections preserve predecessor state and provenance.
D010 Unresolved contradiction is valid and must not be forced closed.
D011 Use Hebrew grammar for semantic precision only where mathematics blurs meaning.
D012 Binary remains the execution representation.
D013 Letter/path, pointing/state, and tag/metadata remain separate layers.
D014 231 gates stay tied to 22 canonical forms unless explicitly redesigned.
D015 Five finals remain reserved until computational semantics are proven.
D016 Atbash/MIRROR is not encryption.
D017 Hardware probes are sandboxed, bounded, timed, and revocable.
D018 Device-unique state requires explicit preservation classification.
D019 Current CPL16-R v0.1 layout is provisional.
D020 Formal algebra and tests precede the next permanent bit layout.
