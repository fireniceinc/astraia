# DOCUMENT INVENTORY

There are 14 primary continuity documents plus up to 2 included prototype archives:
1. READ_ME_FIRST.md
2. MASTER_CONTINUITY_BLOCK.md
3. ARCHITECTURE_B_CANON.md
4. MATHEMATICAL_SEMANTIC_CROSSWALK.md
5. CPL16R_REDESIGN_SPEC.md
6. EVIDENCE_AND_PROVENANCE.md
7. DECISION_REGISTER.md
8. OPEN_QUESTIONS_AND_RISKS.md
9. VALIDATION_PLAN.md
10. RECOVERY_AND_RECONSTRUCTION_PROTOCOL.md
11. SOURCE_CHECKLIST.md
12. astraia_continuity.json
13. RESTORE_PROMPT.txt
14. INCLUDED_ARTIFACTS/README.md

The package deliberately separates controlling continuity, architecture, formal specification, provenance, decisions, risks, tests, recovery, sources, and machine-readable restoration state.
