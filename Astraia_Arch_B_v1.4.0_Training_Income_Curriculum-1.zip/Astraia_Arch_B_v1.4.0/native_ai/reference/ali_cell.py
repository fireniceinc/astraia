#!/usr/bin/env python3
"""Dependency-free executable reference for ALI state flow, not a neural trainer."""
from dataclasses import dataclass, field
from math import tanh
from typing import List
@dataclass
class State:
    center: List[float]=field(default_factory=lambda:[0.0]*16)
    abraham: List[float]=field(default_factory=lambda:[0.0]*16)
    david: List[float]=field(default_factory=lambda:[0.0]*16)
    solomon: List[float]=field(default_factory=lambda:[0.0]*16)
    route: int=0
    unresolved: bool=False

def step(st:State, event:int, provenance:int, authority:int)->State:
    x=((event&255)/127.5)-1.0
    p=((provenance%997)/498.5)-1.0
    a=(authority&255)/255.0
    ab=[tanh(.82*v+.11*x+.07*p) for v in st.center]
    dv=[tanh(.73*v+.19*x+.08*a) for v in st.center]
    so=[tanh(.69*v-.17*x+.14*p) for v in st.center]
    disagreement=sum(abs(ab[i]-dv[i])+abs(dv[i]-so[i]) for i in range(16))/32
    center=[tanh((ab[i]+dv[i]+so[i])/3) for i in range(16)]
    route=1+(abs(event*31+provenance*17+authority*13)%27)
    return State(center,ab,dv,so,route,disagreement>0.72)

def mirror(st:State)->State:
    return State([-x for x in st.center],[-x for x in st.abraham],[-x for x in st.david],[-x for x in st.solomon],st.route,st.unresolved)
if __name__=='__main__':
    s=State()
    for b in b'Human-Astraia-Machine': s=step(s,b,91,7)
    assert all(abs(x-y)<1e-12 for x,y in zip(s.center,mirror(mirror(s)).center))
    print({'route':s.route,'unresolved':s.unresolved,'center_checksum':round(sum(s.center),6)})
