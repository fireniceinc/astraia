import importlib.util, pathlib
p=pathlib.Path(__file__).parents[1]/'reference'/'ali_cell.py'
s=importlib.util.spec_from_file_location('ali',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
a=m.State(); b=m.step(a,65,91,7); c=m.step(a,65,91,7)
assert b.center==c.center and b.route==c.route
assert 1<=b.route<=27
assert m.mirror(m.mirror(b)).center==b.center
print('ALI reference tests passed')
