# Astraia Lattice Intelligence
Run the reference state-flow test:

    python3 native_ai/reference/ali_cell.py

The reference is intentionally tiny and dependency-free. It proves state flow, three projections, deterministic 27-route selection, unresolved disagreement, and mirror involution. It is not trained language intelligence.
