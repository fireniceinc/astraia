#!/usr/bin/env python3
import argparse, pathlib, json, random
try:
 import torch, torch.nn as nn
except Exception as e:
 raise SystemExit('PyTorch is required for training: '+str(e))
class ALI(nn.Module):
 def __init__(self,d=256,layers=6):
  super().__init__(); self.emb=nn.Embedding(256,d); self.rnn=nn.GRU(d,d,layers,batch_first=True); self.ab=nn.Linear(d,d); self.dv=nn.Linear(d,d); self.so=nn.Linear(d,d); self.center=nn.Linear(d*3,d); self.out=nn.Linear(d,256)
 def forward(self,x,h=None):
  z,h=self.rnn(self.emb(x),h); a=torch.tanh(self.ab(z)); d=torch.tanh(self.dv(z)); s=torch.tanh(self.so(z)); c=torch.tanh(self.center(torch.cat([a,d,s],-1))); return self.out(c),h

def load_bytes(paths):
 out=bytearray()
 for spec in paths:
  p=pathlib.Path(spec)
  for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
   if f.is_file():
    try: out.extend(f.read_bytes()); out.extend(b'\n')
    except: pass
 return bytes(out)
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--data',action='append',required=True); ap.add_argument('--steps',type=int,default=100); ap.add_argument('--d-model',type=int,default=128); ap.add_argument('--layers',type=int,default=3); ap.add_argument('--seq',type=int,default=128); ap.add_argument('--lr',type=float,default=3e-4); ap.add_argument('--out',default='ali.pt'); ap.add_argument('--resume'); a=ap.parse_args()
 raw=load_bytes(a.data); assert len(raw)>a.seq+1,'training corpus too small'; dev='cuda' if torch.cuda.is_available() else 'cpu'; model=ALI(a.d_model,a.layers).to(dev); opt=torch.optim.AdamW(model.parameters(),lr=a.lr); start=0
 if a.resume:
  ck=torch.load(a.resume,map_location=dev); model.load_state_dict(ck['model']); opt.load_state_dict(ck['optimizer']); start=ck['step']
 model.train()
 for step in range(start,start+a.steps):
  i=random.randrange(0,len(raw)-a.seq-1); x=torch.tensor(list(raw[i:i+a.seq]),device=dev).long()[None,:]; y=torch.tensor(list(raw[i+1:i+a.seq+1]),device=dev).long()[None,:]
  logits,_=model(x); loss=nn.functional.cross_entropy(logits.reshape(-1,256),y.reshape(-1)); opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
  if step%10==0: print(json.dumps({'step':step,'loss':round(loss.item(),5),'device':dev}))
 out=pathlib.Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); torch.save({'model':model.state_dict(),'optimizer':opt.state_dict(),'step':start+a.steps,'config':vars(a)},out); print('saved',out)
if __name__=='__main__': main()
