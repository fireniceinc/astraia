# ALI trainer
`train_ali.py` is a functional single-device reference trainer, not a fake foundation-model factory. It trains a small byte-level recurrent/projection model on local UTF-8/JSONL files and writes resumable checkpoints. Scale the same data contracts to multi-GPU training later.

Requirements: Python 3, PyTorch.

Example smoke run:

    python trainer/train_ali.py --data training/courses/course_00_to_11.jsonl --steps 20 --d-model 64 --layers 2 --out training/checkpoints/ali-smoke.pt

For serious pretraining, feed newline-delimited UTF-8 text/JSONL shards and increase dimensions/steps on suitable GPU hardware.
