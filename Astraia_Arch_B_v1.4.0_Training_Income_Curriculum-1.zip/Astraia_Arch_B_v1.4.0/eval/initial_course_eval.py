#!/usr/bin/env python3
import json,pathlib
p=pathlib.Path(__file__).parents[1]/'training'/'courses'/'course_00_to_11.jsonl'
rows=[json.loads(x) for x in p.read_text().splitlines() if x.strip()]
assert {r['course'] for r in rows}==set(range(12))
assert all(r.get('input') and r.get('target') for r in rows)
print({'courses':12,'seed_examples':len(rows),'status':'PASS'})
