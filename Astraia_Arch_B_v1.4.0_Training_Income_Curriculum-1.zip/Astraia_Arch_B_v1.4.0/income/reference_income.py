#!/usr/bin/env python3
STAGES=['DISCOVER','VERIFY_NEED','DESIGN_OFFER','COST','RISK','AUTHORIZE','BUILD','QC','PRICE','PUBLISH','MARKET','TRANSACT','DELIVER','SUPPORT','ACCOUNT','LEARN']
def transition(state,target,evidence=False,authority=False):
    i=STAGES.index(state); j=STAGES.index(target)
    if j!=i+1: return False
    if target in {'VERIFY_NEED','QC','ACCOUNT'} and not evidence: return False
    if target in {'AUTHORIZE','TRANSACT'} and not authority: return False
    return True
if __name__=='__main__':
    assert transition('DISCOVER','VERIFY_NEED',evidence=True)
    assert not transition('RISK','AUTHORIZE')
    assert transition('RISK','AUTHORIZE',authority=True)
    assert not transition('BUILD','PRICE',evidence=True)
    print('income pipeline reference tests passed')
