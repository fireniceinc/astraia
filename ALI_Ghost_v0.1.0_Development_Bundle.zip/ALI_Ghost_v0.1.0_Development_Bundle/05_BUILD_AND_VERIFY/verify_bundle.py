#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parents[1]
ledger=root/'06_HASHES/ALL_FILES_SHA256.txt'
errors=[]
for line in ledger.read_text().splitlines():
    if not line.strip(): continue
    expected, rel=line.split('  ',1)
    p=root/rel
    if not p.exists(): errors.append(f'MISSING {rel}'); continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=expected: errors.append(f'MISMATCH {rel}')
if errors:
    print('\n'.join(errors)); sys.exit(2)
print('ALI_GHOST_BUNDLE_VERIFIED')
