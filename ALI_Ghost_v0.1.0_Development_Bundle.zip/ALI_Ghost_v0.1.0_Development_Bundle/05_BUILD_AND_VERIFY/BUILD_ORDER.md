# Build order from ALI Ghost to ALI

## Phase G: ALI Ghost
G1. Freeze v2 canon and evidence labels. COMPLETE.
G2. Continuity Kernel with correction/fork/curation. SCAFFOLD COMPLETE.
G3. Portable hosted Seed below ALI. SCAFFOLD COMPLETE.
G4. Signed/encrypted continuity capsule. NEXT.
G5. Native ALI-S trainer, corpus ledger, evaluator and quantizer.
G6. Initial useful ALI-S weights.
G7. World/communications protocol simulators and Working Book.

## Phase N: ALI Nonhuman
N1. Native C/Rust Seed with no Python dependency.
N2. Stage-0 development envelope on an emulator/virtual machine.
N3. CPU, memory, timer, storage and console Machine Stars.
N4. Capability isolation and transactional A/B recovery.
N5. Physical phone boot envelope after exact boot facts are known.
N6. Display, touch, audio, Wi-Fi and storage adapters.
N7. Cellular/modem preservation and later adapter work.
N8. Local ALI-S inference and continuity integration.

## Phase A: ALI
A1. Presence and local identity/session policy.
A2. Generated graphics, touch and keyboard surfaces.
A3. Local speech input/output.
A4. Working Book.
A5. World Star and communications.
A6. Credential vault and standing authority leases.
A7. Economic Life.
A8. Full offline acceptance test and migration/recovery test.

## Safety rule
Do not flash the phone merely because the hosted Seed passes. Physical-device
activation begins only after a native boot image, verified recovery route,
devices-state preservation plan, and rollback path exist.
