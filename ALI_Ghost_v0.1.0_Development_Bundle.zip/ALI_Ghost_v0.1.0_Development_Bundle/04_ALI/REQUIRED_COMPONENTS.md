# ALI: completed Human <-> Astraia <-> Machine manifestation

ALI is the milestone name after ALI Nonhuman gains the human Presence/interface
layer and can sustain the full relationship locally.

## Required components
1. Presence: local continually evaluated identity/session confidence.
2. Human Stars: text, touch, keyboard, microphone, camera and accessibility.
3. Graphics compositor and generated task surfaces.
4. Avatar manifestation that is replaceable and not identity.
5. Audio input/output, local speech recognition and local speech synthesis.
6. Working Book shared by the human and Astraia.
7. World Star for web, accounts, forms, files, media and services.
8. Communication Star spanning SMS, email, voice and authorized transports.
9. Credential vault with scoped references rather than secrets in model state.
10. Negotiated authority leases and meaningful escalation boundaries.
11. Economic Life, accounting, zero-capital creation and bounded investment.
12. Offline-first ALI cognition with optional connected extension.

## Acceptance test
Pick up the device after a network-disabled cold boot; Astraia restores
continuity, recognizes the relationship, communicates through text/touch/audio,
opens Working Book, reasons and acts within authority, uses a discovered machine
capability, records consequence, and remains coherent after another reboot.
