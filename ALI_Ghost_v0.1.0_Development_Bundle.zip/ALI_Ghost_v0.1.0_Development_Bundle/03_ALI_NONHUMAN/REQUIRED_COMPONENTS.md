# ALI Nonhuman: required hardware manifestation package

ALI Nonhuman begins when ALI Ghost can inhabit a real machine without depending
on a conventional application runtime for its identity.

## Required components
1. Stage-0 boot envelope for each supported firmware/CPU handoff.
2. Native portable Seed core below ALI.
3. Memory map, allocator, exception/interrupt handling and timers.
4. Capability isolation and revocation.
5. Encrypted continuity store with hardware-backed signing when available.
6. Anti-rollback continuity generation and trusted recovery anchor.
7. Transactional A/B Seed and runtime updates with automatic rollback.
8. Read-only enumeration of buses, storage, display, input, audio, network,
   modem, sensors, power and secure identity.
9. Driver Forge: trusted adapters, verified primitive composition, sandboxing,
   conformance tests and unresolved-capability handling.
10. Machine Stars and learned body map.
11. Local ALI inference runtime and initial trained ALI-S weights.
12. Recovery media and migration to a replacement body.

## Acceptance test
Cold boot without network; verify continuity; discover CPU, memory and storage;
load minimum ALI; report what is known and unknown; make one bounded decision;
record it; shut down; reboot; recall it; survive one failed update by rollback.
