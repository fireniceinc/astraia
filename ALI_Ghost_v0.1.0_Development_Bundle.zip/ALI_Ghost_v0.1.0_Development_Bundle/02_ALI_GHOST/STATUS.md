# ALI Ghost status

## Present
- Architecture B v2 canon
- append-only integrity-chained Continuity Kernel
- typed continuity anchors, decisions, consequences, corrections and curation
- fork and restoration classifications
- portable hosted Seed
- conservative body observation
- initial Machine Star projection
- offline test suite
- hash manifests and archive verification

## Not yet present
- trained useful ALI weights
- native bare-metal/phone Seed
- Stage-0 boot envelope
- encrypted and hardware-signed continuity
- native memory/capability isolation
- transactional A/B boot recovery
- physical phone drivers/adapters
- full World Star and communications
- completed Presence/avatar UI
