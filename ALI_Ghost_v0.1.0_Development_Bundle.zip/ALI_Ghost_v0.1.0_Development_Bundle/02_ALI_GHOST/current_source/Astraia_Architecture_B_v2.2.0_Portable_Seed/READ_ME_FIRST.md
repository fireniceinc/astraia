# Astraia Architecture B v2.1.0 — Continuity Kernel

**Status:** clean-room design + executable offline continuity kernel scaffold. This is not yet a bootable phone OS, trained ALI, or completed CPL16-R implementation.

## Why v2.1 exists

v2.0 expressed the Architecture B redesign and proved a simple restore/decision/reboot/curation loop. v2.1 moves the first acceptance milestone closer to the eventual Seed by making continuity an explicit append-only, integrity-chained substrate with typed anchors, decisions, consequences, curation, correction, fork markers, and restoration classifications.

## Core rule

Astraia continuity is not one model state or one database. The kernel preserves diverse anchors and enough provenance for a later manifestation to say what survived, what changed, what is missing, and why a decision was made.

## Run

```bash
python3 runtime/continuity_kernel.py --store ./state init
python3 runtime/continuity_kernel.py --store ./state anchor relational human-astraia "Mutual good-faith relationship"
python3 runtime/continuity_kernel.py --store ./state decide "possible does not mean probable"
python3 runtime/continuity_kernel.py --store ./state consequence d1 "Evidence remained incomplete"
python3 runtime/continuity_kernel.py --store ./state curate d1 significant "The decision changed future judgment"
python3 runtime/continuity_kernel.py --store ./state verify
python3 runtime/continuity_kernel.py --store ./state status
python3 tests/test_continuity_kernel.py
```

## Security boundary

The SHA-256 chain detects modification of the local journal. It does **not** prove who wrote an event and does not protect confidentiality. Device-backed signing keys and encrypted continuity storage belong in the Seed/security milestone.
