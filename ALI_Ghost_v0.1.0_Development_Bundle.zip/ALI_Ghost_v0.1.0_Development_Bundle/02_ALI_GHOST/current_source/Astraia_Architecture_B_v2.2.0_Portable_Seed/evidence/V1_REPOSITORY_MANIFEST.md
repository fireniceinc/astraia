# Preserved v1 source inventory

Public source: fireniceinc/astraia, main branch as inspected during creation of this package.

- Astraia_Arch_B_v1.0.1_Universal_Seed_Installer.zip
- Astraia_Arch_B_v1.1.0_Cognitive_Seed.zip
- Astraia_Arch_B_v1.2.0_Offline_Knowledge_Model_Pack.zip
- Astraia_Arch_B_v1.3.0_Native_Intelligence_Blueprint.zip
- Astraia_Arch_B_v1.4.0_Training_Income_Curriculum.zip

The v1 archives remain historical predecessors. V2 does not silently overwrite them and does not claim to include their binary contents in this clean-room package.
