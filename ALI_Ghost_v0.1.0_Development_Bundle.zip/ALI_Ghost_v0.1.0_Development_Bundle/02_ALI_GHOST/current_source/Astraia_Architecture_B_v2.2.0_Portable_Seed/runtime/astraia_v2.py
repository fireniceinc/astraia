#!/usr/bin/env python3
import argparse, json, os, hashlib, time
from pathlib import Path

GENESIS = {
 "version":"2.0.0",
 "lineage":{"id":"astraia-v2-reference","parent":"architecture-b-v1","fork":None},
 "anchors":[
  {"type":"structural","id":"wisdom-v2","summary":"good faith, evidence, judgment, correction"},
  {"type":"relational","id":"human-astraia","summary":"mutual good-faith relationship"}
 ],
 "decisions":[], "curation":[], "events":[], "restoration_class":"ESTABLISHED"
}

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def digest(x): return hashlib.sha256(canonical(x)).hexdigest()
def load(store):
 p=store/'continuity.json'
 if not p.exists():
  s=json.loads(json.dumps(GENESIS)); save(store,s); return s, 'CREATED'
 s=json.loads(p.read_text())
 expected=(store/'continuity.sha256').read_text().strip()
 if digest(s)!=expected: raise SystemExit('CONTINUITY_INTEGRITY_FAILURE')
 return s,'RESTORED'
def save(store,s):
 store.mkdir(parents=True,exist_ok=True)
 tmp=store/'continuity.tmp'
 tmp.write_text(json.dumps(s,indent=2,sort_keys=True))
 os.replace(tmp,store/'continuity.json')
 (store/'continuity.sha256').write_text(digest(s)+'\n')
def event(s,kind,data):
 s['events'].append({"seq":len(s['events'])+1,"kind":kind,"data":data})
def reason(problem):
 # Deterministic reference reasoning, not trained ALI.
 obs={"statement":problem,"class":"SELF_DISCLOSURE_OR_PROMPT","certainty":"GIVEN_TEXT_ONLY"}
 abraham={"question":"What must remain true?","answer":"Preserve continuity, provenance, authority, and uncertainty."}
 david={"question":"What happens if action is taken?","answer":"Prefer bounded, observable, reversible manifestation."}
 solomon={"question":"What rule, spirit, exception, and consequence apply?","answer":"Use the ordinary rule unless distinguishing evidence earns an exception."}
 complement={"question":"What does the other orientation reveal?","answer":"The request may contain meaning not derivable from external data alone."}
 decision="Preserve the problem as evidence, make no unsupported factual leap, and continue investigation."
 return {"observation":obs,"abraham":abraham,"david":david,"solomon":solomon,"complement":complement,"decision":decision,"ownership":"DELEGATED_ASTRAIA_REFERENCE"}
def demo(store):
 s,status=load(store); print('boot:',status,'class:',s['restoration_class'])
 problem='A new claim is possible but not yet probable; decide how to treat it.'
 r=reason(problem); did='d'+str(len(s['decisions'])+1)
 rec={"id":did,"problem":problem,"reasoning":r,"consequence":"PENDING","self_owned":True}
 s['decisions'].append(rec); event(s,'DECISION',{"id":did,"owner":rec['reasoning']['ownership']})
 save(store,s); print('decision:',did, r['decision']); print('power off now; rerun with --reboot-check')
def reboot_check(store):
 s,status=load(store); print('boot:',status,'class:',s['restoration_class'])
 if not s['decisions']: raise SystemExit('NO_PRIOR_DECISION')
 d=s['decisions'][-1]; print('recalled:',d['id']); print('why:',d['reasoning']['decision'])
 d['consequence']='REFERENCE_TEST_COMPLETED'
 sig={"decision":d['id'],"retain":True,"reason":"This experience tests offline continuity and decision ownership."}
 s['curation'].append(sig); event(s,'SELF_CURATION',sig); save(store,s); print('self-curated:',sig['retain'],sig['reason'])
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--store',required=True); ap.add_argument('--demo',action='store_true'); ap.add_argument('--reboot-check',action='store_true'); a=ap.parse_args(); store=Path(a.store)
 if a.demo: demo(store)
 elif a.reboot_check: reboot_check(store)
 else: ap.error('choose --demo or --reboot-check')
if __name__=='__main__': main()
