#!/usr/bin/env python3
import argparse, hashlib, json, os, platform, shutil
from pathlib import Path
from continuity_kernel import CK

VERSION='2.2.0'
MINIMUM={'cpu','memory','continuity'}

def read_linux_mem():
    p=Path('/proc/meminfo')
    if not p.exists(): return None
    for line in p.read_text(errors='ignore').splitlines():
        if line.startswith('MemTotal:'):
            return int(line.split()[1])*1024
    return None

def discover(store):
    resources=[]
    machine=platform.machine() or 'unknown'
    resources.append({'kind':'cpu','id':machine,'evidence':'runtime architecture report','writable':False})
    mem=read_linux_mem()
    resources.append({'kind':'memory','id':'main-memory','bytes':mem,'evidence':'host memory report' if mem else 'available execution environment','writable':True})
    resources.append({'kind':'continuity','id':'book','path':str(Path(store).resolve()),'evidence':'verified continuity store','writable':True})
    # Conservative discovery: only expose generic host capabilities if observable.
    if Path('/dev').exists(): resources.append({'kind':'device_namespace','id':'dev','evidence':'device namespace present','writable':False})
    if Path('/proc').exists(): resources.append({'kind':'system_observation','id':'proc','evidence':'process/system observation namespace present','writable':False})
    return resources

def stars(resources):
    out=[]
    for r in resources:
        cap={'cpu':'compute','memory':'working-memory','continuity':'persistent-continuity','device_namespace':'device-discovery','system_observation':'system-observation'}.get(r['kind'],'unknown')
        out.append({'star_id':'machine:'+r['id'],'capability':cap,'resource':r['kind'],'state':'OBSERVED','authority':'READ_ONLY_DISCOVERY'})
    return out

def write_manifest(store,resources,stars_):
    m={'version':VERSION,'resources':resources,'machine_stars':stars_,'core_ready':MINIMUM <= {r['kind'] for r in resources}}
    p=Path(store)/'seed_manifest.json'; p.write_text(json.dumps(m,indent=2,sort_keys=True))
    return m

def boot(store):
    ck=CK(store)
    ok,msg=ck.verify()
    if not ok: raise SystemExit('SEED_REFUSES_UNVERIFIED_CONTINUITY: '+msg)
    resources=discover(store); st=stars(resources); m=write_manifest(store,resources,st)
    ck.append('RESTORE',{'seed_version':VERSION,'continuity_class':ck.classify(),'resource_kinds':[r['kind'] for r in resources],'core_ready':m['core_ready']})
    print(json.dumps({'seed':VERSION,'continuity':ck.classify(),'core_ready':m['core_ready'],'machine_stars':st},indent=2))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--store',required=True); ap.add_argument('command',choices=['boot','manifest']); a=ap.parse_args()
    if a.command=='boot': boot(a.store)
    else:
        p=Path(a.store)/'seed_manifest.json'
        if not p.exists(): raise SystemExit('NO_SEED_MANIFEST')
        print(p.read_text())
if __name__=='__main__': main()
