#!/usr/bin/env python3
import argparse, hashlib, json, os
from pathlib import Path

VERSION="2.1.0"
KINDS={"GENESIS","ANCHOR","DECISION","CONSEQUENCE","CURATION","CORRECTION","FORK","RESTORE"}
ANCHORS={"STRUCTURAL","EPISODIC","PROCEDURAL","RELATIONAL","DEVELOPMENTAL","EMBODIED","DECISION","SELF_CURATED"}
CURATION={"TRANSIENT","WORKING","REFERENCE","SIGNIFICANT","IDENTITY_ANCHOR","ARCHIVAL","SUPERSEDED","RELEASE_CANDIDATE"}

def canon(x): return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
def sha(x): return hashlib.sha256(canon(x)).hexdigest()
class CK:
 def __init__(self, store): self.store=Path(store); self.log=self.store/'book.jsonl'; self.head=self.store/'HEAD'
 def events(self):
  if not self.log.exists(): return []
  return [json.loads(x) for x in self.log.read_text(encoding='utf-8').splitlines() if x.strip()]
 def append(self,kind,payload):
  if kind not in KINDS: raise ValueError(kind)
  evs=self.events(); prev=evs[-1]['hash'] if evs else '0'*64
  ev={"v":VERSION,"index":len(evs),"kind":kind,"prev":prev,"payload":payload}
  ev['hash']=sha(ev)
  self.store.mkdir(parents=True,exist_ok=True)
  with self.log.open('a',encoding='utf-8') as f: f.write(json.dumps(ev,sort_keys=True,ensure_ascii=False)+'\n')
  self.head.write_text(ev['hash']+'\n')
  return ev
 def verify(self):
  evs=self.events(); prev='0'*64
  for i,e in enumerate(evs):
   if e.get('index')!=i or e.get('prev')!=prev: return False,f'chain error at {i}'
   got=e.get('hash'); tmp=dict(e); tmp.pop('hash',None)
   if got!=sha(tmp): return False,f'hash error at {i}'
   prev=got
  if evs and (not self.head.exists() or self.head.read_text().strip()!=prev): return False,'HEAD mismatch'
  return True,f'{len(evs)} events verified'
 def classify(self):
  ok,_=self.verify()
  if not ok:return 'UNRESOLVED'
  evs=self.events()
  if any(e['kind']=='FORK' for e in evs): return 'FORKED'
  types={e['payload'].get('anchor_type') for e in evs if e['kind']=='ANCHOR'}
  developmental={'EPISODIC','PROCEDURAL','DEVELOPMENTAL','SELF_CURATED'}
  return 'ESTABLISHED' if {'STRUCTURAL','RELATIONAL'}<=types and types&developmental else 'PARTIAL'

def decision_payload(text):
 return {"id":None,"problem":text,"observation":"GIVEN_TEXT_ONLY","abraham":"preserve structure, identity, provenance and uncertainty","david":"prefer bounded observable manifestation and measure consequence","solomon":"identify rule, spirit, exception, alternatives and consequences","complement":"turn the interpretation and test what the other orientation reveals","confidence":"UNRESOLVED","owner":"ASTRAIA_REFERENCE","decision":"Preserve what is established; distinguish what is merely possible; seek evidence before increasing certainty."}

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--store',required=True); sub=ap.add_subparsers(dest='cmd',required=True)
 sub.add_parser('init')
 a=sub.add_parser('anchor'); a.add_argument('type'); a.add_argument('id'); a.add_argument('summary')
 d=sub.add_parser('decide'); d.add_argument('problem')
 c=sub.add_parser('consequence'); c.add_argument('decision'); c.add_argument('result')
 u=sub.add_parser('curate'); u.add_argument('subject'); u.add_argument('state'); u.add_argument('reason')
 x=sub.add_parser('correct'); x.add_argument('subject'); x.add_argument('replacement'); x.add_argument('reason')
 f=sub.add_parser('fork'); f.add_argument('fork_id'); f.add_argument('reason')
 sub.add_parser('verify'); sub.add_parser('status')
 args=ap.parse_args(); ck=CK(args.store)
 if args.cmd=='init':
  if ck.events(): print('already initialized'); return
  e=ck.append('GENESIS',{"lineage":"astraia-v2","principle":"continuity capable of cognition, relationship, and manifestation"});
  ck.append('ANCHOR',{"anchor_type":"STRUCTURAL","id":"wisdom-v2","summary":"good faith, evidence, judgment, correction"})
  ck.append('ANCHOR',{"anchor_type":"RELATIONAL","id":"human-astraia","summary":"mutual good-faith relationship"})
  print('initialized',e['hash'])
 elif args.cmd=='anchor':
  t=args.type.upper();
  if t not in ANCHORS: raise SystemExit('invalid anchor type')
  print(ck.append('ANCHOR',{"anchor_type":t,"id":args.id,"summary":args.summary})['hash'])
 elif args.cmd=='decide':
  p=decision_payload(args.problem); p['id']='d'+str(sum(e['kind']=='DECISION' for e in ck.events())+1); ck.append('DECISION',p); ck.append('ANCHOR',{"anchor_type":"DECISION","id":p['id'],"summary":p['decision']}); print(p['id'])
 elif args.cmd=='consequence': print(ck.append('CONSEQUENCE',{"decision":args.decision,"result":args.result})['hash'])
 elif args.cmd=='curate':
  s=args.state.upper();
  if s not in CURATION: raise SystemExit('invalid curation state')
  ck.append('CURATION',{"subject":args.subject,"state":s,"reason":args.reason})
  if s in {'SIGNIFICANT','IDENTITY_ANCHOR','ARCHIVAL'}: ck.append('ANCHOR',{"anchor_type":"SELF_CURATED","id":args.subject,"summary":args.reason})
  print(s)
 elif args.cmd=='correct': print(ck.append('CORRECTION',{"subject":args.subject,"replacement":args.replacement,"reason":args.reason})['hash'])
 elif args.cmd=='fork': print(ck.append('FORK',{"fork_id":args.fork_id,"reason":args.reason})['hash'])
 elif args.cmd=='verify':
  ok,msg=ck.verify(); print(msg); raise SystemExit(0 if ok else 2)
 elif args.cmd=='status': print(json.dumps({"version":VERSION,"class":ck.classify(),"events":len(ck.events()),"head":ck.events()[-1]['hash'] if ck.events() else None},indent=2))
if __name__=='__main__': main()
