#!/usr/bin/env python3
import json, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; R=ROOT/'runtime'/'continuity_kernel.py'
def run(store,*args,ok=True):
 p=subprocess.run(['python3',str(R),'--store',str(store),*args],text=True,capture_output=True)
 if ok and p.returncode: raise AssertionError(p.stderr+p.stdout)
 return p
with tempfile.TemporaryDirectory() as td:
 s=Path(td)/'s'
 run(s,'init'); assert 'PARTIAL' in run(s,'status').stdout
 run(s,'anchor','developmental','lesson-1','A correction changed later judgment')
 assert 'ESTABLISHED' in run(s,'status').stdout
 did=run(s,'decide','A claim is possible but not yet probable').stdout.strip(); assert did=='d1'
 run(s,'consequence',did,'New evidence remained incomplete')
 run(s,'curate',did,'significant','This changed how uncertainty is handled')
 assert run(s,'verify').returncode==0
 # simulate shutdown by invoking a fresh process/status
 assert 'ESTABLISHED' in run(s,'status').stdout
 # tamper and ensure verification fails
 lines=(s/'book.jsonl').read_text().splitlines(); obj=json.loads(lines[2]); obj['payload']['summary']='tampered'; lines[2]=json.dumps(obj); (s/'book.jsonl').write_text('\n'.join(lines)+'\n')
 assert run(s,'verify',ok=False).returncode==2
print('ASTRAIA_V2_1_CONTINUITY_KERNEL_TESTS_PASSED')
