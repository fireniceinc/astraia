#!/usr/bin/env python3
import tempfile, subprocess, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
 store=Path(td)/'state'
 subprocess.run(['python3',str(ROOT/'runtime/astraia_v2.py'),'--store',str(store),'--demo'],check=True)
 first=json.loads((store/'continuity.json').read_text())
 assert len(first['decisions'])==1
 assert first['decisions'][0]['self_owned'] is True
 subprocess.run(['python3',str(ROOT/'runtime/astraia_v2.py'),'--store',str(store),'--reboot-check'],check=True)
 second=json.loads((store/'continuity.json').read_text())
 assert second['decisions'][0]['consequence']=='REFERENCE_TEST_COMPLETED'
 assert second['curation'][-1]['retain'] is True
 expected=(store/'continuity.sha256').read_text().strip()
 actual=hashlib.sha256(json.dumps(second,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 assert actual==expected
 assert second['restoration_class']=='ESTABLISHED'
print('ASTRAIA_V2_TESTS_PASSED')
