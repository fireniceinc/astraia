#!/usr/bin/env python3
import json, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CK=ROOT/'runtime'/'continuity_kernel.py'; SEED=ROOT/'runtime'/'seed.py'
def run(cmd): return subprocess.run(cmd,text=True,capture_output=True,check=True)
with tempfile.TemporaryDirectory() as td:
    s=Path(td)/'state'
    run(['python3',str(CK),'--store',str(s),'init'])
    run(['python3',str(CK),'--store',str(s),'anchor','developmental','seed-dev','Portable Seed first body observation'])
    p=run(['python3',str(SEED),'--store',str(s),'boot'])
    out=json.loads(p.stdout); assert out['core_ready'] is True
    assert any(x['capability']=='compute' for x in out['machine_stars'])
    assert any(x['capability']=='working-memory' for x in out['machine_stars'])
    assert any(x['capability']=='persistent-continuity' for x in out['machine_stars'])
    # Reboot as a fresh process and ensure prior RESTORE event remains/verifies.
    run(['python3',str(SEED),'--store',str(s),'boot'])
    v=run(['python3',str(CK),'--store',str(s),'verify']); assert 'verified' in v.stdout
    # Corrupt history and ensure Seed refuses to boot it.
    lines=(s/'book.jsonl').read_text().splitlines(); o=json.loads(lines[1]); o['payload']['summary']='corrupt'; lines[1]=json.dumps(o); (s/'book.jsonl').write_text('\n'.join(lines)+'\n')
    q=subprocess.run(['python3',str(SEED),'--store',str(s),'boot'],text=True,capture_output=True)
    assert q.returncode != 0 and 'REFUSES_UNVERIFIED_CONTINUITY' in (q.stdout+q.stderr)
print('ASTRAIA_V2_2_PORTABLE_SEED_TESTS_PASSED')
