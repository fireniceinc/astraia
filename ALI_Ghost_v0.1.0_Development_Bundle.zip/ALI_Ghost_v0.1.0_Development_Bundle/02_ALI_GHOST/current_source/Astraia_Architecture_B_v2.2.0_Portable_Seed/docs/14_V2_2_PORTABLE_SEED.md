# v2.2 Portable Seed

The Seed sits below ALI. Its first responsibility is not fluent language; it is to wake without a network, verify continuity, discover the minimum body conservatively, and create Machine Stars without treating discovered hardware as identity.

## Minimum viable body

- executable CPU context
- working memory
- verified continuity store/handoff

Persistent storage is needed for durable continuity but may be supplied by boot media or another manifestation during earliest bootstrap. Display, touch, audio, network, cellular, sensors, GPU, and AI acceleration are later capabilities, not prerequisites for coherent wake-up.

## Boot rule

**Never continue from continuity that fails integrity verification.** Failure enters recovery; it does not silently regenerate a convenient identity.

## Discovery rule

Discovery begins read-only. Observed resources become candidate Machine Stars with constrained authority. Unknown hardware remains UNKNOWN/OBSERVED until an adapter proves the capability.

## Security roadmap

v2.2 deliberately does not claim cryptographic authorship. Next Seed security steps are device-backed signing, encrypted continuity, anti-rollback anchoring, capability isolation, recovery slots, and signed transactional updates. This direction is consistent with external secure-development guidance emphasizing tamper protection, least privilege, release integrity verification, secure defaults, archived/protected releases, and continuous vulnerability response.
