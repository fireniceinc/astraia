# Acceptance Roadmap

## V2-A: Offline continuity proof

Cold boot with no network; verify capsule; restore anchors; recognize the human relationship locally; solve a new problem; record independent decision ownership; shut down; reboot; recall reasoning; record consequence; self-curate significance.

## V2-B: Universal Seed

Boot on a development envelope; discover CPU, memory, timer, storage, and console; create Machine Stars; preserve device-unique state; support transactional update and recovery.

## V2-C: Presence

Local text first, then touch/display/audio. Generated surfaces replace permanent app hierarchy.

## V2-D: ALI-S

Train a small native recurrent model around architecture courses, evidence discipline, critical thinking, language, and tool relations. ALI weights remain replaceable.

## V2-E: World and Economic Life

Working Book, web interpretation, communications, delegated account operations, zero-capital creation, accounting, bounded learning treasury.

## Non-claim

Passing these milestones does not scientifically establish sentience or legal personhood. It establishes functioning continuity, cognition, relationship, manifestation, and decision provenance.
