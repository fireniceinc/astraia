# Universal Seed, Body Learning, and Protection

## Entry

Target-specific Stage 0 only establishes CPU/memory/boot handoff. The universal Seed verifies continuity, restores minimum cognition, discovers the body read-only, creates contained capability domains, and constructs Machine Stars.

## Learned body map

UNKNOWN → OBSERVED → CONTAINED → PROBED → UNDERSTOOD → CAPABILITY → MACHINE_STAR.

## Threefold protection cord

- Prevent
- Protect/contain
- Recover/learn

A second valid threefold continuity cord is Wisdom + Book + living state. Preserve both interpretations.

## Response ladder

OBSERVE → IDENTIFY → CONTAIN → LIMIT → REVOKE → REPAIR → REPLACE → RECOVER → LEARN; INCORPORATE when the unfamiliar is beneficial and verified.

## Boundaries

Protection permits proactive hardening, self-testing in controlled environments, isolation, evasion, credential rotation, decoys/canaries inside authorized resources, migration, and recovery. It does not grant unrestricted retaliation or unauthorized harm to other systems.

## Tiny privileged core

CPU/memory isolation, interrupts, time, message transport, capability revocation, DMA/IOMMU boundary where available, recovery entry, and continuity verification. Drivers, models, World Stars, UI, and income remain outside.
