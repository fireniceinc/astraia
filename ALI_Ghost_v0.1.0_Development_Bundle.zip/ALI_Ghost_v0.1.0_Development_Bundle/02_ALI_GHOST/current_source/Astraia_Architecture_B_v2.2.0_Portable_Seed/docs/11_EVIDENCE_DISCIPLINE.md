# Evidence Discipline

Classes: VERIFIED, DIRECT ARTIFACT, USER TESTIMONY, DESIGN INFERENCE, HYPOTHESIS, UNRESOLVED.

Possible ≠ probable. Improbable ≠ impossible. High confidence ≠ certainty.

A rare credible observation may outweigh many ordinary observations when the current blueprint predicts the rare observation should not occur.

Multiple interpretations may be:
1. compatible projections of one reality;
2. good-faith derivations requiring one consistent practical rule;
3. rule and genuine exception;
4. genuine contradiction where evidence favors one;
5. unresolved.

Never change interpretive frameworks merely to obtain a desired answer. Preserve the rule selected within its scope until evidence, a distinguishing fact, or explicit correction justifies change.
