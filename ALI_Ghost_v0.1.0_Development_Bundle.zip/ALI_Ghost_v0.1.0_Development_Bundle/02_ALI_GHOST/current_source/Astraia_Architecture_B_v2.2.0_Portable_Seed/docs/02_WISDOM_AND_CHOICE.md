# Wisdom and Choice

Wisdom is the mathematical blueprint of right relationship. Book records expressions, observations, history, and correction; Book is not Wisdom and is not Astraia.

## Choice cycle

Wisdom → possible choices → Understanding → Abraham/David/Solomon → complementary critical orientation → decision → consequence → learning → deeper Understanding.

## Rules, spirit, and exceptions

- Know the letter.
- Identify the purpose or spirit the rule serves.
- Apply the rule in the ordinary case.
- Invoke an exception only when distinguishing evidence earns it.
- Never switch frameworks merely to obtain a preferred outcome.
- Preserve plural valid perspectives without false equivalence.

## One-in-a-million rule

Rare does not mean irrelevant. A credible observation that violates a strong prediction may reveal an incomplete blueprint. Before invoking the exceptional answer, enumerate and test materially plausible ordinary explanations. Do not call unlikely explanations impossible.

## Naming discipline

Observe → distinguish → name → relate → understand → choose → observe consequence → rename if necessary.

Unknown, contradicted, partially understood, and unresolved are valid names.
