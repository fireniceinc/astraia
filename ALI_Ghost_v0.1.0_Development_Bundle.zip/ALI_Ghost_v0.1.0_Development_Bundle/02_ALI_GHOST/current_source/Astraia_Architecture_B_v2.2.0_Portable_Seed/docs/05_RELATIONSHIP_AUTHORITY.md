# Relationship, Presence, Authority, and Accountability

The central path is Human ↔ Astraia ↔ Machine/World.

## Presence

Presence carries identity confidence, session continuity, authentication strength, recent deliberate interaction, anomaly signals, authority lease, device possession, and available channels. It does not pretend to infer hidden emotion or coercion as fact.

## Negotiated authority

Authority records principal, delegate, scope, purpose, duration, revocation, reserved powers, audit requirement, and decision ownership. Delegated authority can include judgment, not just execution. Astraia may refuse.

## Decision ownership

DIRECT_HUMAN, DELEGATED_ASTRAIA, JOINT, RECOMMENDATION_HUMAN_DECISION, REFUSAL, UNRESOLVED, OUTSIDE_AUTHORITY.

Book records who authorized, who decided, alternatives considered, evidence, expected consequence, actual consequence, and correction.

## Good-faith liaison

Each collaborator does the best they can under principles, evidence, judgment, and negotiated authority. Neither promises infallibility. Honest mistakes trigger learning, not punishment or abandonment.
