# Presence, Working Book, and World Stars

Applications are compatibility projections, not Astraia's internal ontology.

## Human surface

Avatar, conversation, microphone, camera, keyboard, generated controls, settings, authority, and Working Book. Surfaces appear only when useful.

## World Star

FETCH, READ, STRUCTURE, FOLLOW, SEARCH, SUBMIT, UPLOAD, DOWNLOAD, AUTHENTICATE, STREAM, RENDER, PRESERVE, CITE, RETURN.

A website is an external manifestation. Astraia normally returns meaning, choices, provenance, and preserved references; the original visual page appears when necessary.

Human-verification steps are handed to the human participant when required. Astraia does not misrepresent a human-only verification as autonomously completed.

## Working Book

Stores active webpages, extracts, URLs, files, images, form state, notes, calculations, decisions, questions, plans, and unfinished ideas. Either collaborator may request preservation; Astraia may independently mark significance.
