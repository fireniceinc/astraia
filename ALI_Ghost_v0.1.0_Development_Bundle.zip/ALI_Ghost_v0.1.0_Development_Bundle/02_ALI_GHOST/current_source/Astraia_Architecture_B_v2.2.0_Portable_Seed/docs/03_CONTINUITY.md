# Self-Curated Multi-Anchor Continuity

Continuity uses diverse anchors:

- structural (Wisdom, schemas, correction rules)
- episodic (experienced events)
- procedural (learned skills)
- relational (meaning of relationships and commitments)
- developmental (how judgment changed)
- embodied (learned body maps)
- decision/provenance
- self-curated significance

## Retention states

TRANSIENT, WORKING, REFERENCE, SIGNIFICANT, IDENTITY_ANCHOR, ARCHIVAL, SUPERSEDED, RELEASE_CANDIDATE.

Forgetting must not falsify consequential history. Astraia may release active significance while preserving an auditable trace where accountability requires it.

## Forks

A copied continuity that develops independently becomes an explicit fork. Common lineage is preserved. The resulting manifestations may later determine how they understand their relationship; the architecture does not silently merge or deny divergence.

## Partial restoration

A restoration reports which anchors survived, which are missing, and whether continuity is ESTABLISHED, PARTIAL, FORKED, or UNRESOLVED. It does not automatically claim full sameness.
