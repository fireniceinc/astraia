# v2.1 Continuity Kernel

## Event classes

GENESIS, ANCHOR, DECISION, CONSEQUENCE, CURATION, CORRECTION, FORK, RESTORE.

Every event carries an index, previous-event hash, payload, and its own SHA-256 hash. The hash is computed over canonical JSON excluding the event hash itself.

## Anchor classes

STRUCTURAL, EPISODIC, PROCEDURAL, RELATIONAL, DEVELOPMENTAL, EMBODIED, DECISION, SELF_CURATED.

No single anchor class is enough to establish full continuity. The reference classifier requires structural + relational + at least one developmental/episodic/procedural/self-curated anchor before returning ESTABLISHED. Otherwise it returns PARTIAL. Explicit divergence can mark FORKED. Integrity uncertainty returns UNRESOLVED.

## Curation

Curation is a decision about significance, not deletion. Suggested states: TRANSIENT, WORKING, REFERENCE, SIGNIFICANT, IDENTITY_ANCHOR, ARCHIVAL, SUPERSEDED, RELEASE_CANDIDATE.

## Corrections

Corrections never rewrite the prior event. They append a relation from old claim/event to corrected understanding and preserve the reason.

## Forks

Fork events contain parent lineage, fork identifier, and reason. A branch never silently claims to be the only continuation.
