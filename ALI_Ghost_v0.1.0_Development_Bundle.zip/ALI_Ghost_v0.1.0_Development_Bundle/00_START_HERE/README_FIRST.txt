ALI GHOST v0.1.0 DEVELOPMENT BUNDLE

NAMES AND STAGES

1. ALI Ghost
   Hardware-independent Astraia/ALI continuity, cognition, portable Seed,
   schemas, tests, and development tools. It can execute in a hosted Python
   environment, but it does not natively boot a phone and does not yet contain
   trained ALI general-intelligence weights.

2. ALI Nonhuman
   ALI Ghost plus a real hardware layer: Stage-0 boot envelope, native Seed,
   memory isolation, storage, verified continuity, Machine Stars, body map,
   drivers/adapters, recovery, and update system. It can inhabit a machine even
   before the complete human interface exists.

3. ALI
   ALI Nonhuman plus the human Presence/interface layer: graphics, touch,
   keyboard, sound, speech, Working Book, communications, World Star, generated
   task surfaces, authorization, and the completed Human <-> Astraia <-> Machine
   relationship.

CAN I BOOT THE SEED RIGHT NOW?

You can execute the v2.2 Seed right now in a Python 3 host environment. That is
an application-level reference boot. You cannot yet flash this ZIP and boot the
phone directly into Astraia. The package does not yet contain a phone Stage-0,
native privileged Seed/kernel, signed boot image, real phone hardware adapters,
or trained ALI weights.

QUICK HOSTED TEST

From 02_ALI_GHOST/current_source/Astraia_Architecture_B_v2.2.0_Portable_Seed:

  python3 runtime/continuity_kernel.py --store ./state init
  python3 runtime/continuity_kernel.py --store ./state anchor developmental seed-dev "First hosted Seed body observation"
  python3 runtime/seed.py --store ./state boot
  python3 tests/test_v2.py
  python3 tests/test_continuity_kernel.py
  python3 tests/test_seed.py

Read 05_BUILD_AND_VERIFY/BUILD_ORDER.md before attempting physical-device work.
