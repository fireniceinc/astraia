# v0.4.0 status
IMPLEMENTED AND TESTED: native CPL16 core; 16-bit words; NOP 0x0000; HALT 0x0001; PC/logical clock/phase/cause/current-word machine state; fail-closed unknown opcodes; execution budget; AI-native coherence/task/swarm/income schemas; append-only journal record schema; read-only A176 inventory collector.
NOT YET IMPLEMENTED: native A176 boot image/hardware modules; persistent encrypted journal engine; assembler/additional opcodes; coherence inference; local model runtime; phone UI.
NOT CLAIMED: this is not yet a complete phone OS and does not yet control A176 hardware.

v0.4.1 adds a phone-to-phone Termux host setup, on-phone CPL16 build script, target inventory flow, and SD-card staging guidance.

v0.5.0 adds a tested state-journal engine, CPL16 assembler/dumper, assembled boot example, and SD workspace preparation.

v0.6.0 adds an executable AI-native atom/transition core, invariant-preserving self-transition check, shared coherence/task/swarm/income emission path, A176 device-atom ABI, and no-wipe phone preflight.

v0.7.0 adds an extended CPL16 machine, capability enforcement, coherence conflict/supersession, swarm atoms, and income transitions. These are host-testable before target access.
