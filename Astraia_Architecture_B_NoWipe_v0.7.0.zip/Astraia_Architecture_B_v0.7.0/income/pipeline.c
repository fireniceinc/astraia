#include "pipeline.h"
int income_next(income_atom*a,income_phase n,uint64_t rules){if(!a)return 0;if((uint16_t)n!=(uint16_t)(a->phase+1))return 0;if((a->rules&rules)!=rules)return 0;a->phase=(uint16_t)n;return 1;}
