#ifndef ASTRAIA_INCOME_PIPELINE_H
#define ASTRAIA_INCOME_PIPELINE_H
#include <stdint.h>
typedef enum {I_DISCOVER=0,I_VALIDATE=1,I_CREATE=2,I_QC=3,I_PRICE=4,I_PUBLISH=5,I_DELIVER=6,I_SUPPORT=7,I_ACCOUNT=8,I_LEARN=9} income_phase;
typedef struct {uint64_t id;uint64_t opportunity;uint64_t evidence;uint64_t artifact;uint64_t customer;uint64_t revenue_minor;uint64_t cost_minor;uint64_t rules;uint32_t currency;uint16_t phase;uint16_t quality;} income_atom;
int income_next(income_atom*,income_phase,uint64_t rule_mask);
#endif
