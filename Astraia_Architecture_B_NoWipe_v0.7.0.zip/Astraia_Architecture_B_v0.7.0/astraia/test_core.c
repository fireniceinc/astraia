#include "core.h"
#include <assert.h>
#include <stdio.h>
int main(void){remove("build/core.astraj");astra_core c;astra_init(&c,0x0f);assert(astra_transition_allowed(&c,0x0f,0x03));assert(!astra_transition_allowed(&c,0x07,0x03));astra_atom a;assert(astra_emit(&c,"build/core.astraj",ASTRA_COHERENCE,1,11,0,0,&a)==0);assert(astra_emit(&c,"build/core.astraj",ASTRA_TASK,1,12,a.id,1,&a)==0);astra_journal_state s;uint64_t n;assert(astra_journal_verify("build/core.astraj",&s,&n)==0&&n==2);puts("Astraia core transition tests passed");}
