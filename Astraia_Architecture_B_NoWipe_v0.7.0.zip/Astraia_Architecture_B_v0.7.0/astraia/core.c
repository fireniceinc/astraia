#include "core.h"
#include <string.h>
void astra_init(astra_core*c,uint64_t m){memset(c,0,sizeof(*c));c->invariant_mask=m;}
int astra_transition_allowed(const astra_core*c,uint64_t preserves,uint64_t requires){if(!c)return 0;if((preserves&c->invariant_mask)!=c->invariant_mask)return 0;if((requires&~preserves)!=0)return 0;return 1;}
int astra_emit(astra_core*c,const char*j,uint16_t kind,uint16_t state,uint32_t ref,uint64_t relation,uint64_t capability,astra_atom*out){if(!c||!j)return -1;astra_atom a={c->next_id++,kind,state,ref,relation,++c->tick,capability};int rc=astra_journal_append(j,&c->journal,kind,c->tick,&a,sizeof(a));if(rc)return rc;if(out)*out=a;return 0;}
