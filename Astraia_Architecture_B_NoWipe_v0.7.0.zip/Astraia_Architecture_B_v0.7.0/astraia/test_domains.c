#include "../coherence/ledger.h"
#include "../income/pipeline.h"
#include <assert.h>
#include <stdio.h>
int main(void){c_atom a={1,9,10,3,0,1,C_DIRECT,65535,0},b={2,9,11,4,0,2,C_INFERENCE,30000,0},c={3,9,11,4,1,3,C_DIRECT,65535,0};assert(!coherence_compatible(&a,&b));assert(coherence_compatible(&a,&c));income_atom i={0};i.rules=7;assert(income_next(&i,I_VALIDATE,3));assert(!income_next(&i,I_PRICE,3));puts("Coherence and income transition tests passed");}
