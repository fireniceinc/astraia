#ifndef ASTRAIA_CORE_H
#define ASTRAIA_CORE_H
#include <stdint.h>
#include "../persistence/journal.h"
typedef uint64_t astra_id;
typedef enum {ASTRA_COHERENCE=1,ASTRA_TASK=2,ASTRA_SWARM=3,ASTRA_INCOME=4,ASTRA_CORRECTION=5,ASTRA_CAPABILITY=6,ASTRA_TRANSITION=7} astra_kind;
typedef struct {astra_id id;uint16_t kind;uint16_t state;uint32_t ref;uint64_t relation;uint64_t tick;uint64_t capability;} astra_atom;
typedef struct {astra_journal_state journal;uint64_t tick;uint64_t next_id;uint64_t invariant_mask;} astra_core;
void astra_init(astra_core *c,uint64_t invariant_mask);
int astra_emit(astra_core *c,const char *journal,uint16_t kind,uint16_t state,uint32_t ref,uint64_t relation,uint64_t capability,astra_atom *out);
int astra_transition_allowed(const astra_core *c,uint64_t preserves,uint64_t requires);
#endif
