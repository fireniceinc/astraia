#ifndef ASTRAIA_SWARM_ATOM_H
#define ASTRAIA_SWARM_ATOM_H
#include <stdint.h>
typedef struct {uint64_t id;uint64_t origin;uint64_t destination;uint64_t intent;uint64_t evidence;uint64_t transition;uint64_t capabilities;uint64_t deadline;uint32_t priority;uint32_t state;} swarm_atom;
#endif
