#ifndef ASTRAIA_AI_NATIVE_STATE_H
#define ASTRAIA_AI_NATIVE_STATE_H
#include <stdint.h>
typedef uint64_t astra_id; typedef uint64_t astra_tick; typedef uint32_t astra_ref;
typedef enum {EVIDENCE_DIRECT=1,EVIDENCE_ARTIFACT=2,EVIDENCE_TESTIMONY=3,EVIDENCE_INFERENCE=4,EVIDENCE_HYPOTHESIS=5,EVIDENCE_UNRESOLVED=6} evidence_class;
typedef struct {astra_id id; evidence_class cls; uint16_t confidence; astra_ref payload; astra_id provenance; astra_id supersedes; astra_tick observed;} coherence_atom;
typedef enum {TASK_DORMANT=0,TASK_READY=1,TASK_ACTIVE=2,TASK_BLOCKED=3,TASK_COMPLETE=4,TASK_REJECTED=5} task_state;
typedef struct {astra_id id; astra_ref objective; astra_ref constraints; uint64_t capability_bits; task_state state; uint16_t priority; astra_tick created; astra_tick changed;} task_atom;
typedef struct {astra_id sender; astra_id receiver; astra_ref intent; astra_ref evidence; astra_ref proposed_transition; uint64_t required_capabilities;} swarm_atom;
typedef enum {INCOME_DISCOVER=0,INCOME_VALIDATE=1,INCOME_CREATE=2,INCOME_QC=3,INCOME_PRICE=4,INCOME_PUBLISH=5,INCOME_DELIVER=6,INCOME_SUPPORT=7,INCOME_ACCOUNT=8,INCOME_LEARN=9} income_state;
#endif
