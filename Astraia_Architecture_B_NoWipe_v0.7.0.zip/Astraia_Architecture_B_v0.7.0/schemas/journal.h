#ifndef ASTRAIA_JOURNAL_H
#define ASTRAIA_JOURNAL_H
#include <stdint.h>
#define ASTRAIA_JOURNAL_MAGIC 0x41535452u
typedef struct {uint32_t magic;uint16_t version;uint16_t type;uint32_t bytes;uint64_t sequence;uint64_t logical_time;uint32_t previous_crc;uint32_t payload_crc;} journal_record;
#endif
