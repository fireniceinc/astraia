# Initial device target

Target family: Samsung Galaxy A17 5G, likely SM-A176U family, Exynos 1330 / s5e8535, ARM64.

This package does not contain a flashable image. Device-specific bring-up requires exact model/build identity, bootloader state, partition inventory, backed-up stock images, recovery path, and hardware-module implementation.

Final target is not Android or Linux as the operating environment. Temporary host systems may be used only for development, extraction, testing, and recovery.
