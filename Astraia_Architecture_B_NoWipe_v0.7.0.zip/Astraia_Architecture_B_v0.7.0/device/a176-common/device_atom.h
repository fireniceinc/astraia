#ifndef ASTRAIA_A176_DEVICE_ATOM_H
#define ASTRAIA_A176_DEVICE_ATOM_H
#include <stdint.h>
typedef enum {DEV_UNKNOWN=0,DEV_DISPLAY=1,DEV_TOUCH=2,DEV_STORAGE=3,DEV_AUDIO=4,DEV_CAMERA=5,DEV_MODEM=6,DEV_WIFI=7,DEV_BLUETOOTH=8,DEV_SENSOR=9,DEV_POWER=10,DEV_USB=11,DEV_NFC=12,DEV_FINGERPRINT=13} device_class;
typedef struct {uint64_t identity;uint32_t vendor_code;uint16_t cls;uint16_t variant;uint64_t operation_mask;uint64_t evidence_ref;} device_atom;
#endif
