#ifndef ASTRAIA_COHERENCE_LEDGER_H
#define ASTRAIA_COHERENCE_LEDGER_H
#include <stdint.h>
typedef enum {C_DIRECT=1,C_ARTIFACT=2,C_TESTIMONY=3,C_INFERENCE=4,C_HYPOTHESIS=5,C_UNRESOLVED=6} c_class;
typedef struct {uint64_t id;uint64_t subject;uint64_t value;uint64_t provenance;uint64_t supersedes;uint64_t tick;uint16_t cls;uint16_t confidence;uint32_t flags;} c_atom;
int coherence_compatible(const c_atom*,const c_atom*);
#endif
