#include "ledger.h"
int coherence_compatible(const c_atom*a,const c_atom*b){if(!a||!b)return 0;if(a->subject!=b->subject)return 1;if(a->value==b->value)return 1;if(b->supersedes==a->id||a->supersedes==b->id)return 1;return 0;}
