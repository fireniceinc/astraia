#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
make clean test
mkdir -p "$HOME/storage/shared/Astraia/build"
cp build/test_cpl16 "$HOME/storage/shared/Astraia/build/cpl16-host-test"
sha256sum build/test_cpl16 > "$HOME/storage/shared/Astraia/build/cpl16-host-test.sha256"
echo "CPL16 built and tested on this phone."
