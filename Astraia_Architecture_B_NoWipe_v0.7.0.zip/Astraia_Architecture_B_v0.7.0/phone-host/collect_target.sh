#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ADB="${ADB:-termux-adb}"
command -v "$ADB" >/dev/null || { echo "Missing $ADB"; exit 1; }
"$ADB" devices
TMP="${HOME}/astraia-a176-inventory"
rm -rf "$TMP"
ADB="$ADB" sh "$ROOT/bootstrap/collect_a176.sh" "$TMP"
termux-setup-storage >/dev/null 2>&1 || true
DEST="${HOME}/storage/shared/Astraia/a176-inventory"
mkdir -p "$(dirname "$DEST")"
rm -rf "$DEST"
cp -a "$TMP" "$DEST"
echo "Saved inventory to $DEST"
