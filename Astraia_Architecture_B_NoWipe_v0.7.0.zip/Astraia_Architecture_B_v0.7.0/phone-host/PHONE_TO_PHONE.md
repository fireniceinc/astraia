# Phone-to-phone bootstrap

## Roles
- Host phone: runs Termux, compiles CPL16, stores backups, and controls the USB link.
- Target A17: enables Developer options and USB debugging, then approves the host key.

## Host dependencies
1. Install Termux and Termux:API from F-Droid.
2. In Termux run: `bash phone-host/setup_termux_host.sh`
3. Install phone-to-phone ADB/fastboot using the maintained `nohajc/termux-adb` instructions. This tool uses Termux:API USB file-descriptor access so a non-rooted Android phone can control another Android device over USB.
4. Connect the phones with a USB-C data cable. The host must assume the USB-host role.
5. On the target, approve the USB debugging prompt.
6. Run: `bash phone-host/collect_target.sh`

## SD card
Use the SD card for source, inventories, firmware packages, hashes, and multiple recovery copies. Do not treat an ordinary file copy as a full restorable image of protected boot/vendor/modem partitions. Restore capability must be verified before any destructive operation.

## Current capability
This stage builds/tests CPL16 on the host phone and collects target details. It does not unlock, flash, replace partitions, or boot Astraia natively yet.
