#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
make clean test
ADB="${ADB:-termux-adb}"
if command -v "$ADB" >/dev/null; then
  "$ADB" devices
  echo "ADB transport present. No partitions were written."
else
  echo "CPL16/Astraia tests passed; phone transport not installed yet."
fi
