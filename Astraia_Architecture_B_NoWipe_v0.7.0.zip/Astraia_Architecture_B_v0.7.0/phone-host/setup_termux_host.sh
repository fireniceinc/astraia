#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
pkg update
pkg install -y clang make git curl wget unzip zip termux-api
printf '\nBase build tools installed.\n'
printf 'Install the separate Termux:API application, then install termux-adb as documented in PHONE_TO_PHONE.md.\n'
