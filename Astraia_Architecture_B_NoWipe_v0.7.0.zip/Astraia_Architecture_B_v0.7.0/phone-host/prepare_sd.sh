#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
termux-setup-storage >/dev/null 2>&1 || true
DEST="$HOME/storage/shared/Astraia"
mkdir -p "$DEST"/{source,build,inventory,recovery,firmware,manifests}
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cp -a "$ROOT" "$DEST/source/Architecture_B_v0.5.0"
( cd "$DEST/source/Architecture_B_v0.5.0" && sha256sum MANIFEST.sha256 > "$DEST/manifests/source-manifest.sha256" )
echo "Astraia workspace prepared at $DEST"
