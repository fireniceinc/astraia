#!/usr/bin/env python3
import argparse,struct
OPS={"NOP":0x0000,"HALT":0x0001}
def assemble(text):
 out=[]
 for line_no,raw in enumerate(text.splitlines(),1):
  line=raw.split('#',1)[0].strip()
  if not line: continue
  token=line.upper()
  if token not in OPS: raise SystemExit(f"line {line_no}: unknown CPL16 word {token}")
  out.append(OPS[token])
 return b''.join(struct.pack('<H',x) for x in out)
def main():
 p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('-o','--output',required=True);a=p.parse_args()
 data=assemble(open(a.source,encoding='utf-8').read());open(a.output,'wb').write(data);print(f"wrote {len(data)//2} CPL16 words")
if __name__=='__main__':main()
