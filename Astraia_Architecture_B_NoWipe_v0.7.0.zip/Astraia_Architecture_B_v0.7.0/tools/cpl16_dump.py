#!/usr/bin/env python3
import argparse,struct
N={0x0000:'NOP',0x0001:'HALT'}
p=argparse.ArgumentParser();p.add_argument('binary');a=p.parse_args();d=open(a.binary,'rb').read()
if len(d)%2:raise SystemExit('invalid CPL16 byte count')
for i in range(0,len(d),2):
 w=struct.unpack_from('<H',d,i)[0];print(f'{i//2:08x}  {w:04x}  {N.get(w,"FAULT") }')
