#!/bin/sh
set -eu
ADB="${ADB:-adb}"
OUT="${1:-astraia-a176-inventory}"; mkdir -p "$OUT"
"$ADB" get-state > "$OUT/adb-state.txt"
"$ADB" shell getprop > "$OUT/getprop.txt"
"$ADB" shell uname -a > "$OUT/uname.txt"
"$ADB" shell cat /proc/cpuinfo > "$OUT/cpuinfo.txt"
"$ADB" shell cat /proc/meminfo > "$OUT/meminfo.txt"
"$ADB" shell 'ls -l /dev/block/by-name 2>/dev/null || ls -l /dev/block/platform/*/by-name 2>/dev/null || true' > "$OUT/partitions.txt"
"$ADB" shell cat /proc/partitions > "$OUT/proc-partitions.txt"
for s in battery sensorservice media.camera audio wifi bluetooth_manager; do "$ADB" shell dumpsys "$s" > "$OUT/$s.txt" 2>&1 || true; done
"$ADB" shell 'getprop ro.product.model; getprop ro.product.device; getprop ro.bootloader; getprop ro.boot.verifiedbootstate; getprop ro.boot.flash.locked; getprop ro.build.fingerprint; getprop ro.boot.hardware' > "$OUT/identity.txt"
( cd "$OUT" && sha256sum * > SHA256SUMS.txt ); echo "Inventory written to $OUT"
