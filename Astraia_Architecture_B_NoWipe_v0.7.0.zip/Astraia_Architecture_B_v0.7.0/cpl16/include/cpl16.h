#ifndef CPL16_H
#define CPL16_H
#include <stddef.h>
#include <stdint.h>
typedef uint16_t cpl16_word; typedef uint32_t cpl16_ref; typedef uint64_t cpl16_tick;
enum cpl16_opcode { CPL16_NOP=0x0000, CPL16_HALT=0x0001 };
typedef enum { CPL16_RUN=0,CPL16_STOP=1,CPL16_FAULT=2 } cpl16_phase;
typedef enum { CPL16_CAUSE_NONE=0,CPL16_CAUSE_HALT=1,CPL16_CAUSE_NULL=2,CPL16_CAUSE_OPCODE=3,CPL16_CAUSE_BOUNDS=4,CPL16_CAUSE_BUDGET=5 } cpl16_cause;
typedef struct { uint32_t pc; cpl16_tick clock; cpl16_phase phase; cpl16_cause cause; cpl16_word current; } cpl16_state;
typedef struct { const cpl16_word *program; size_t word_count; cpl16_state state; } cpl16_vm;
void cpl16_reset(cpl16_vm*,const cpl16_word*,size_t); cpl16_phase cpl16_step(cpl16_vm*); cpl16_phase cpl16_run(cpl16_vm*,uint64_t); const char *cpl16_phase_name(cpl16_phase); const char *cpl16_cause_name(cpl16_cause);
#endif
