#ifndef CPL16_MACHINE_H
#define CPL16_MACHINE_H
#include <stdint.h>
#include <stddef.h>
#define CPL16_CELLS 256u
#define CPL16_CAPS 64u
enum { OP_NOP=0x0000,OP_HALT=0x0001,OP_LIT=0x0010,OP_GET=0x0011,OP_SET=0x0012,OP_ADD=0x0013,OP_EQ=0x0014,OP_JMP=0x0020,OP_JZ=0x0021,OP_CAP=0x0030,OP_EMIT=0x0040 };
typedef enum {M_RUN=0,M_STOP=1,M_FAULT=2} m_phase;
typedef enum {F_NONE=0,F_HALT=1,F_OPCODE=2,F_BOUNDS=3,F_STACK=4,F_CAP=5,F_BUDGET=6} m_fault;
typedef struct {const uint16_t*code;uint32_t words;uint32_t pc;uint64_t tick;uint32_t cell[CPL16_CELLS];uint32_t stack[64];uint8_t sp;uint64_t caps;m_phase phase;m_fault fault;uint16_t last;} cpl16_machine;
void machine_reset(cpl16_machine*,const uint16_t*,uint32_t,uint64_t);
m_phase machine_step(cpl16_machine*);
m_phase machine_run(cpl16_machine*,uint64_t);
#endif
