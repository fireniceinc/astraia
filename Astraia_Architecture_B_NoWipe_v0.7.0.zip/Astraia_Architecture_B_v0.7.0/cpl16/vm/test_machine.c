#include "machine.h"
#include <assert.h>
#include <stdio.h>
int main(void){uint16_t p[]={OP_LIT,7,OP_SET,3,OP_GET,3,OP_LIT,5,OP_ADD,OP_SET,4,OP_CAP,2,OP_HALT};cpl16_machine m;machine_reset(&m,p,sizeof(p)/2,1ull<<2);assert(machine_run(&m,100)==M_STOP&&m.fault==F_HALT&&m.cell[4]==12);machine_reset(&m,p,sizeof(p)/2,0);assert(machine_run(&m,100)==M_FAULT&&m.fault==F_CAP);puts("CPL16 extended machine tests passed");}
