#include "cpl16.h"
#include <assert.h>
#include <stdio.h>
int main(void){cpl16_vm v;const cpl16_word p[]={CPL16_NOP,CPL16_NOP,CPL16_HALT};cpl16_reset(&v,p,3);assert(cpl16_run(&v,8)==CPL16_STOP);assert(v.state.pc==3&&v.state.clock==3&&v.state.cause==CPL16_CAUSE_HALT);const cpl16_word bad[]={0xffff};cpl16_reset(&v,bad,1);assert(cpl16_step(&v)==CPL16_FAULT&&v.state.cause==CPL16_CAUSE_OPCODE);const cpl16_word bounded[]={CPL16_NOP,CPL16_NOP};cpl16_reset(&v,bounded,2);assert(cpl16_run(&v,1)==CPL16_STOP&&v.state.cause==CPL16_CAUSE_BUDGET);puts("CPL16 machine-state tests passed");return 0;}
