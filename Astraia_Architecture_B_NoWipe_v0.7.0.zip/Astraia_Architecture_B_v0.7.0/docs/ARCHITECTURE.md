# Architecture B: locked direction

## Human boundary
Only the Astraia interaction surface is human-oriented: avatar, conversation, microphone, camera, keyboard, generated controls, settings, and explicit authorization.

## AI-native stack
1. Hardware and signed device-module packs
2. CPL16 native execution and machine contract
3. Astraia coherence, operating authority, and human interface
4. Governed core swarm
5. Extended intelligence and all capability categories

First-class protected requirements: Astraia coherence; core swarm; governed income pipeline; thin human interface. CPL16 is the native language joining them.

## Word-size decision
- ARM64 machine/kernel foundation
- 16-bit CPL16 base instruction word
- 32-bit default component values/handles in the future design
- explicit 64-bit extension where needed

## Historical boundary
Architecture B is clean-room work. It is separate from historical Prime Forge V1, V2/prime-forge-genesis, completed PFV3, historical V4, and PFX. Historical evidence can provide design lessons but Architecture B is not retroactive evidence.
