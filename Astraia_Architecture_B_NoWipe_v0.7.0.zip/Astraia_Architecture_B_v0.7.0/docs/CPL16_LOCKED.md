# CPL16 locked items

- Instruction word: exactly 16 bits.
- Byte order for serialized programs: little-endian.
- Opcode `0x0000`: `NOP`. It changes no machine state except advancing the program counter and execution count.
- Opcode `0x0001`: `HALT`. Reserved here so test programs terminate deterministically; all additional opcode assignments remain open.
- Unknown opcodes fault closed.
- Execution uses an explicit instruction budget.

No memory model, capability-handle format, register file, or extended encoding has been locked yet.
