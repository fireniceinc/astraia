# Immediate bootstrap
`make test` builds and validates the CPL16 core. `bootstrap/collect_a176.sh` performs a read-only ADB inventory of an attached A176-family phone. It does not root, unlock, flash, or alter partitions. The final target is a bootable Astraia system, not an APK. An APK may be generated only as a temporary collector and interaction shell.
