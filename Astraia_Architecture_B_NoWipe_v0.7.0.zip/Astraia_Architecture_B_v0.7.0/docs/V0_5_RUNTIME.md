# v0.5 runtime increment

Implemented:
- CPL16 text-to-binary assembler for the locked words NOP and HALT.
- CPL16 binary inspector.
- Append-only binary state journal with sequence, logical time, previous-record linkage, payload hash, record hash, append, and full-chain verification.
- Phone-host SD/workspace preparation.

AI-native interpretation:
- Journal records are compact state transitions, not human documents.
- Human-readable CPL16 text exists only as a development boundary. The machine consumes little-endian 16-bit words.
- Coherence, tasks, swarm state, and income state share the same append-only transition substrate rather than imitating separate human applications.
