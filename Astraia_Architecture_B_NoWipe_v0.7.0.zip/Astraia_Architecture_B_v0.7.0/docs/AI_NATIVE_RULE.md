# Non-drift rule
Only the Astraia interaction boundary is designed for humans. All internal execution, persistence, coherence, swarm coordination, capability representation, hardware mapping, and self-transition mechanisms are AI-native. Human software metaphors are documentation aids only and never define the internal architecture.
