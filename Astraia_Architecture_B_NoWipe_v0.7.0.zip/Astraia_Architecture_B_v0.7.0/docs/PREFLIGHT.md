# Preflight before any wipe

Everything in this package can be built and tested before touching the target. Run `phone-host/preflight_no_wipe.sh` on the host phone. Then connect the target only for read-only inventory.

Do not wipe for the first test. Native replacement cannot be finalized until exact target evidence is collected. If the device exposes DSU and accepts an appropriately trusted image, DSU may offer a guest-boot test path that returns to the original system after a cold reboot. Availability and accepted signatures are manufacturer controlled.

A wipe becomes relevant only after: host build passes; target inventory is captured; matching factory firmware is stored; boot acceptance is established; radio identity is preserved; and a recovery path is verified.
