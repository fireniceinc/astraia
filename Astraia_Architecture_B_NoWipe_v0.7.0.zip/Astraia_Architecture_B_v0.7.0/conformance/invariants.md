# Astraia invariants v0

Bit 0: continuity history remains append-only.
Bit 1: correction does not erase the corrected state.
Bit 2: capability is explicit for machine-affecting transitions.
Bit 3: provenance remains attached to accepted evidence.

The runtime represents these as machine-checkable bits. A self-transition is rejected when it drops any active invariant. This is an AI-native state condition, not a human release workflow.
