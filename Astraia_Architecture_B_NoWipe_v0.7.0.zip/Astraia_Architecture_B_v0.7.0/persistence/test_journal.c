#include "journal.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){const char*p="build/test.astraj";remove(p);astra_journal_state s={0,0};const char*a="coherence";const char*b="task";assert(astra_journal_append(p,&s,1,1,a,(uint32_t)strlen(a))==0);assert(astra_journal_append(p,&s,2,2,b,(uint32_t)strlen(b))==0);astra_journal_state v={0};uint64_t n=0;assert(astra_journal_verify(p,&v,&n)==0);assert(n==2&&v.next_sequence==2&&v.previous_hash==s.previous_hash);puts("Astraia journal tests passed");return 0;}
