#ifndef ASTRAIA_PERSISTENCE_JOURNAL_H
#define ASTRAIA_PERSISTENCE_JOURNAL_H
#include <stddef.h>
#include <stdint.h>
#define ASTRAIA_JOURNAL_MAGIC 0x41535452u
#define ASTRAIA_JOURNAL_VERSION 1u
typedef struct {
 uint32_t magic;
 uint16_t version;
 uint16_t type;
 uint32_t payload_bytes;
 uint64_t sequence;
 uint64_t logical_time;
 uint32_t previous_hash;
 uint32_t payload_hash;
 uint32_t record_hash;
} astra_record_header;
typedef struct { uint64_t next_sequence; uint32_t previous_hash; } astra_journal_state;
uint32_t astra_hash32(const void *data,size_t bytes,uint32_t seed);
int astra_journal_append(const char *path,astra_journal_state *state,uint16_t type,uint64_t logical_time,const void *payload,uint32_t payload_bytes);
int astra_journal_verify(const char *path,astra_journal_state *out_state,uint64_t *record_count);
#endif
