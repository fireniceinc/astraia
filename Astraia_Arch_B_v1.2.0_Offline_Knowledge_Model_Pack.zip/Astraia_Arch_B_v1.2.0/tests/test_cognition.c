#include "astraia_cognition.h"
#include <assert.h>
#include <string.h>
int main(void){a11_mind m;a11_plan p;char x[128];a11_fact f={1,10,1,99,900,A11_TRUE,0},c={1,10,1,100,900,A11_FALSE,0};a11_rule r={10,1,20,1,1};a11_action a={20,1,30,1,2,1,2,1,9};assert(a11_mind_init(&m)==A09_OK);assert(a11_assert(&m,&f)==A09_OK);assert(a11_add_rule(&m,&r)==A09_OK);assert(a11_derive(&m,4)==1);assert(a11_query(&m,1,20,1)==A11_TRUE);assert(a11_add_action(&m,&a)==A09_OK);assert(a11_plan_goal(&m,1,30,1,&p)==A09_OK&&p.action_id==9);assert(a11_explain(&m,1,20,1,x,sizeof x)==A09_OK&&strstr(x,"derived=1"));assert(a11_assert(&m,&c)==A09_UNRESOLVED);assert(a11_query(&m,1,10,1)==A11_CONTRADICTED);return 0;}
