#include "astraia_seed.h"
#include <assert.h>
int main(void){a101_seed s;a101_capsule c={1,2,3,4,1};a101_resource cpu={10,11,1,0,0,A101_CPU,0,A09_DERIVABLE,0},mem={12,13,2,0,4096,A101_MEMORY,0,A09_DERIVABLE,0},store={14,15,3,0,1000,A101_STORAGE,0,A09_PRESERVE,1};assert(a101_seed_init(&s,&c,0,0)==A09_OK);assert(a101_restore_continuity(&s)==A09_OK);assert(a101_observe_resource(&s,&cpu)==A09_OK);assert(a101_observe_resource(&s,&mem)==A09_OK);assert(a101_observe_resource(&s,&store)==A09_OK);assert(a101_classify_resource(&s,14,A09_PRESERVE)==A09_OK);assert(a101_plan_install(&s)==A09_OK);return 0;}
