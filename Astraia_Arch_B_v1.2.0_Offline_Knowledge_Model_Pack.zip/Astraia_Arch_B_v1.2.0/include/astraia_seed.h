#ifndef ASTRAIA_SEED_H
#define ASTRAIA_SEED_H
#include "astraia_v1.h"
#define A101_MAX_RESOURCES 64u
typedef enum{A101_UNKNOWN=0,A101_CPU=1,A101_MEMORY=2,A101_STORAGE=3,A101_CONSOLE=4,A101_TIMER=5,A101_BUS=6,A101_NETWORK=7,A101_INPUT=8,A101_DISPLAY=9,A101_AUDIO=10,A101_SENSOR=11,A101_POWER=12}a101_resource_kind;
typedef enum{A101_DISCOVERED=1,A101_CLASSIFIED=2,A101_ADAPTER_FOUND=3,A101_ADAPTER_NEEDED=4,A101_READY=5,A101_UNRESOLVED=6}a101_resource_state;
typedef struct{uint64_t identity;uint64_t evidence;uint64_t relation;uint64_t address;uint64_t size;uint8_t kind;uint8_t state;uint8_t reconstruction;uint8_t writable;}a101_resource;
typedef struct{uint64_t capsule_hash;uint64_t book_generation;uint64_t wisdom_generation;uint64_t provenance;uint8_t verified;}a101_capsule;
typedef struct{a1_system system;a101_capsule capsule;a101_resource resources[A101_MAX_RESOURCES];size_t resource_count;uint8_t continuity_restored;uint8_t destructive_authorized;}a101_seed;
a09_result a101_seed_init(a101_seed*,const a101_capsule*,a095_event_sink,void*);
a09_result a101_restore_continuity(a101_seed*);
a09_result a101_observe_resource(a101_seed*,const a101_resource*);
a09_result a101_classify_resource(a101_seed*,uint64_t,uint8_t);
a09_result a101_plan_install(const a101_seed*);
a09_result a101_authorize_destructive(a101_seed*,uint64_t);
#endif
