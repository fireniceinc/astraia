#ifndef ASTRAIA_COGNITION_H
#define ASTRAIA_COGNITION_H
#include "astraia_seed.h"
#define A11_MAX_FACTS 256u
#define A11_MAX_RULES 128u
#define A11_MAX_ACTIONS 64u
typedef enum{A11_FALSE=0,A11_TRUE=1,A11_UNKNOWN=2,A11_CONTRADICTED=3}a11_truth;
typedef struct{uint32_t subject,predicate,object;uint64_t provenance;uint16_t confidence;uint8_t truth,derived;}a11_fact;
typedef struct{uint32_t if_predicate,if_object,then_predicate,then_object;uint8_t rule_id;}a11_rule;
typedef struct{uint32_t pre_predicate,pre_object,effect_predicate,effect_object;uint16_t cost,risk;uint8_t authority,reversible,action_id;}a11_action;
typedef struct{a11_fact facts[A11_MAX_FACTS];size_t fact_count;a11_rule rules[A11_MAX_RULES];size_t rule_count;a11_action actions[A11_MAX_ACTIONS];size_t action_count;uint8_t contradiction_count;}a11_mind;
typedef struct{uint8_t action_id,requires_authority,complete;uint32_t cost,risk;}a11_plan;
a09_result a11_mind_init(a11_mind*);a09_result a11_assert(a11_mind*,const a11_fact*);a11_truth a11_query(const a11_mind*,uint32_t,uint32_t,uint32_t);a09_result a11_add_rule(a11_mind*,const a11_rule*);a09_result a11_add_action(a11_mind*,const a11_action*);size_t a11_derive(a11_mind*,unsigned);a09_result a11_plan_goal(const a11_mind*,uint32_t,uint32_t,uint32_t,a11_plan*);a09_result a11_explain(const a11_mind*,uint32_t,uint32_t,uint32_t,char*,size_t);
#endif
