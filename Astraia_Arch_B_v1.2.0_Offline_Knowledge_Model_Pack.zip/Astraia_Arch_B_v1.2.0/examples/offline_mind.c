#include "astraia_cognition.h"
#include <stdio.h>
int main(void){a11_mind m;a11_plan p;char why[128];a11_fact f={1,10,1,100,1000,A11_TRUE,0};a11_rule r={10,1,20,1,1};a11_action a={20,1,30,1,1,1,1,1,7};a11_mind_init(&m);a11_assert(&m,&f);a11_add_rule(&m,&r);a11_derive(&m,4);a11_add_action(&m,&a);a11_plan_goal(&m,1,30,1,&p);a11_explain(&m,1,20,1,why,sizeof why);puts(why);printf("plan action=%u risk=%u\n",p.action_id,p.risk);return 0;}
