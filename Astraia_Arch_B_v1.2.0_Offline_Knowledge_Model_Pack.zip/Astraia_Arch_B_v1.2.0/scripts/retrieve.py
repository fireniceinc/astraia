#!/usr/bin/env python3
import sqlite3, pathlib, sys
root=pathlib.Path(__file__).resolve().parents[1]; db=root/'knowledge'/'astraia_knowledge.db'
q=' '.join(sys.argv[1:]).strip() or 'Astraia continuity boot doctrine'
con=sqlite3.connect(db)
try:
 rows=con.execute('''select d.path,c.shard,c.ordinal,snippet(chunks_fts,0,'[',']','...',24) from chunks_fts join chunks c on c.id=chunks_fts.rowid join documents d on d.id=c.document_id where chunks_fts match ? order by bm25(chunks_fts) limit 8''',(q,)).fetchall()
except sqlite3.OperationalError:
 rows=[]
for path,shard,ordn,text in rows: print(f'[{path} shard={shard} chunk={ordn}] {text}\n')
