#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
Q="$*"
[ -n "$Q" ] || Q="Describe current Astraia boot state."
PROMPT="$(python "$ROOT/scripts/build_prompt.py" "$Q")"
MODEL="$ROOT/model_runtime/astraia-local.gguf"
if command -v llama-cli >/dev/null 2>&1 && [ -f "$MODEL" ]; then
  exec llama-cli -m "$MODEL" -c 4096 -n 384 --temp 0.2 --top-p 0.9 -p "$PROMPT"
fi
printf '%s\n' "LOCAL MODEL UNAVAILABLE. Cognitive Seed + Book retrieval mode:" "" "$PROMPT"
