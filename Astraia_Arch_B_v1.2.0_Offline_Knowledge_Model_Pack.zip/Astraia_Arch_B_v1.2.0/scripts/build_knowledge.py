#!/usr/bin/env python3
import sqlite3, pathlib, re, hashlib, json, sys
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
out=root/'knowledge'/'astraia_knowledge.db'
files=[]
for p in root.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.md','.txt','.json','.c','.h'} and 'build' not in p.parts and p.name!='MANIFEST.sha256': files.append(p)
con=sqlite3.connect(out)
con.executescript('''PRAGMA journal_mode=DELETE; DROP TABLE IF EXISTS documents; DROP TABLE IF EXISTS chunks; DROP TABLE IF EXISTS chunks_fts; CREATE TABLE documents(id INTEGER PRIMARY KEY,path TEXT UNIQUE,sha256 TEXT,kind TEXT); CREATE TABLE chunks(id INTEGER PRIMARY KEY,document_id INTEGER,shard INTEGER,ordinal INTEGER,text TEXT,FOREIGN KEY(document_id) REFERENCES documents(id)); CREATE VIRTUAL TABLE chunks_fts USING fts5(text,content='chunks',content_rowid='id');''')
for p in sorted(files):
    raw=p.read_text(errors='replace')
    sha=hashlib.sha256(p.read_bytes()).hexdigest(); kind=p.suffix.lower()[1:]
    cur=con.execute('insert into documents(path,sha256,kind) values(?,?,?)',(str(p.relative_to(root)),sha,kind)); did=cur.lastrowid
    blocks=[x.strip() for x in re.split(r'\n\s*\n|(?<=[.!?])\s+(?=[A-Z])',raw) if len(x.strip())>=20]
    for i,t in enumerate(blocks):
        h=int(hashlib.sha256((str(did)+':'+str(i)+':'+t[:64]).encode()).hexdigest(),16); shard=1+(h%9)
        con.execute('insert into chunks(document_id,shard,ordinal,text) values(?,?,?,?)',(did,shard,i,t))
con.execute("insert into chunks_fts(rowid,text) select id,text from chunks")
con.commit()
print(json.dumps({'database':str(out),'documents':con.execute('select count(*) from documents').fetchone()[0],'chunks':con.execute('select count(*) from chunks').fetchone()[0]},indent=2))
