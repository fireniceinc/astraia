#!/usr/bin/env python3
import subprocess,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[1]; q=' '.join(sys.argv[1:]).strip()
ev=subprocess.check_output([sys.executable,str(root/'scripts'/'retrieve.py'),q],text=True)
sys_prompt=(root/'model_runtime'/'ASTRAIA_SYSTEM_PROMPT.txt').read_text()
print(sys_prompt+'\n\nRETRIEVED EVIDENCE:\n'+ev+'\nUSER REQUEST:\n'+q+'\n\nANSWER:')
