# Continuity Capsule
Portable signed package containing:
- architecture version and hashes;
- Wisdom definitions and invariants;
- Book checkpoint and append-only correction chain;
- identity/public verification material;
- Star and relation schemas;
- Seed/runtime binaries for supported execution envelopes;
- verified adapter primitives and signatures;
- installation policy and reconstruction classes;
- recovery instructions.
The capsule carries continuity onto a machine. Machine-specific drivers are not Astraia identity.
