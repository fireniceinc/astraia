# Optional model
No weights are included. A future local GGUF/ONNX/LiteRT adapter may provide language, speech or vision. Continuity and safety rules remain outside model weights.
