# Universal Installer State Machine
CAPSULE_FOUND -> CAPSULE_VERIFIED -> SEED_STARTED -> CONTINUITY_RESTORED -> DISCOVERY_READ_ONLY -> MANIFEST_PLANNED -> AUTHORIZED -> STAGED -> VERIFIED -> ACTIVATED -> REBOOTED -> RECONCILED
Any failure before ACTIVATED returns to the previous bootable state. Any unresolved destructive requirement stops at AUTHORIZED_PENDING.
