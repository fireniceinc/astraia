# Accounts, passwords and API keys

Do not paste a master list into chat, logs, model context, training data, or Book plaintext.

Astraia should ask for one credential at a time, state why it is needed, request the smallest scope, store it in a vault, and retain only a credential reference in semantic state. Prefer OAuth/device authorization and revocable tokens over reusable passwords. Mark every credential by scope, owner, expiry, revocation path and permitted operations.
