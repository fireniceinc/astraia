plugins { id("com.android.application") }

android { namespace = "com.firenice.astraia.bootstrap"; compileSdk = 36
    defaultConfig { applicationId = "com.firenice.astraia.bootstrap"; minSdk = 28; targetSdk = 36; versionCode = 1; versionName = "0.1.0" }
}
