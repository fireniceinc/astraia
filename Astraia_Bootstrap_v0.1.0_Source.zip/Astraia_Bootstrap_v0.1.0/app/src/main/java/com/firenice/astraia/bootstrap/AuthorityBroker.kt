package com.firenice.astraia.bootstrap
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
object AuthorityBroker {
 fun isDeviceOwner(c:Context)=c.getSystemService(DevicePolicyManager::class.java).isDeviceOwnerApp(c.packageName)
 fun reboot(c:Context):Boolean { val d=c.getSystemService(DevicePolicyManager::class.java); if(!d.isDeviceOwnerApp(c.packageName)) return false; d.reboot(ComponentName(c,AdminReceiver::class.java)); return true }
 fun hasSu():Boolean = listOf("/system/xbin/su","/system/bin/su","/sbin/su").any{java.io.File(it).exists()}
}
