package com.firenice.astraia.bootstrap
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.KeyGenerator
object SecretVault {
 private const val ALIAS="astraia-bootstrap-v1"
 fun ensureKey(){ val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}; if(ks.containsAlias(ALIAS)) return
  val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
  kg.init(KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setUserAuthenticationRequired(true).build()); kg.generateKey() }
}
