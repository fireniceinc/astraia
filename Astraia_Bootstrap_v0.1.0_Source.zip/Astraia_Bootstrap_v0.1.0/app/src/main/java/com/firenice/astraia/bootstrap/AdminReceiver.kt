package com.firenice.astraia.bootstrap
import android.app.admin.DeviceAdminReceiver
class AdminReceiver: DeviceAdminReceiver()
