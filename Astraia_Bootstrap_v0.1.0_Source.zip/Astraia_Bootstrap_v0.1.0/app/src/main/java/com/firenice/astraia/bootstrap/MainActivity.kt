package com.firenice.astraia.bootstrap
import android.app.Activity
import android.os.Bundle
import android.widget.*
import org.json.JSONObject
class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b); SecretVault.ensureKey(); val inv=JSONObject(DeviceInventory.collect()).toString(2)
  val status=TextView(this).apply{text="Astraia Bootstrap

$inv

Device owner: ${AuthorityBroker.isDeviceOwner(this@MainActivity)}
Existing su: ${AuthorityBroker.hasSu()}

No secrets are displayed or logged."}
  val reboot=Button(this).apply{text="Authorized reboot";setOnClickListener{if(!AuthorityBroker.reboot(this@MainActivity)) Toast.makeText(this@MainActivity,"Device Owner authority not available",Toast.LENGTH_LONG).show()}}
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(status);addView(reboot)};setContentView(box)} }
