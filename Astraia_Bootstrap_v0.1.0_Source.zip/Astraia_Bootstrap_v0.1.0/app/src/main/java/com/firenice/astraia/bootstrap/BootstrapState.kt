package com.firenice.astraia.bootstrap

enum class Phase { VERIFY, INVENTORY, VAULT, AUTHORIZE, STAGE_SEED, STAGE_BUILD, READY_TO_REBOOT, NATIVE_HANDOFF, FAULT }
data class BootstrapState(val phase: Phase, val evidence: List<String> = emptyList(), val fault: String? = null)
