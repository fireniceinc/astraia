package com.firenice.astraia.bootstrap
import android.os.Build
object DeviceInventory { fun collect(): Map<String,String> = linkedMapOf(
 "manufacturer" to Build.MANUFACTURER, "model" to Build.MODEL, "device" to Build.DEVICE,
 "board" to Build.BOARD, "hardware" to Build.HARDWARE, "fingerprint" to Build.FINGERPRINT,
 "abi" to Build.SUPPORTED_ABIS.joinToString(","), "sdk" to Build.VERSION.SDK_INT.toString()) }
