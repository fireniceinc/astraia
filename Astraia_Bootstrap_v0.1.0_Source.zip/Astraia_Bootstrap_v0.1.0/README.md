# Astraia Bootstrap v0.1.0

Temporary Android bridge only. It does not define Astraia's internal architecture.

## Sequence
1. Launch and verify Continuity Capsule.
2. Inventory device read-only.
3. Create hardware-backed bootstrap key where available.
4. Accept credentials only through explicit credential-entry screens; never print or log secret values.
5. Request scoped authorizations.
6. Stage Seed and build manifests.
7. Reboot only when Device Owner or an already-authorized root broker is available.
8. On native boot, retire Android bootstrap.

## Hard boundary
An APK cannot lawfully or reliably manufacture root or bypass a locked verified-boot chain. This bridge detects existing authority and uses it; it does not exploit the device.
