#ifndef ASTRAIA_V09_H
#define ASTRAIA_V09_H
#include <stddef.h>
#include <stdint.h>

typedef enum { A09_OK=0, A09_INVALID=1, A09_UNRESOLVED=2, A09_DENIED=3, A09_MISMATCH=4 } a09_result;
typedef enum { A09_ABRAHAM=1, A09_DAVID=2, A09_SOLOMON=3 } a09_projection;
typedef enum { A09_DERIVABLE=1, A09_REPROVISIONABLE=2, A09_PRESERVE=3, A09_DEVICE_UNIQUE=4, A09_PHYSICAL=5 } a09_reconstruction;
typedef enum { A09_CONFIRM=1, A09_MANIFESTATION_FAULT=2, A09_BLUEPRINT_INCOMPLETE=3, A09_CONTRADICTION=4, A09_REMAINS_UNRESOLVED=5 } a09_understanding;
typedef enum { A09_DIR_NONE=0, A09_FORWARD=1, A09_REVERSE=2, A09_BIDIRECTIONAL=3 } a09_direction;

typedef struct {
  uint64_t source;
  uint64_t target;
  uint64_t provenance;
  uint32_t blueprint_generation;
  uint32_t manifestation_generation;
  uint16_t gate;
  uint8_t canonical_form;
  uint8_t state_modifier;
  uint8_t metadata_modifier;
  uint8_t direction;
  uint8_t rule;
  uint8_t authority;
} a09_relation;

typedef struct {
  uint64_t identity;
  uint64_t expected;
  uint64_t observed;
  uint64_t evidence;
  uint32_t generation;
  uint8_t reconstruction;
} a09_manifestation;

typedef struct {
  uint8_t abraham;
  uint8_t david;
  uint8_t solomon;
} a09_projection_result;

typedef struct {
  void *context;
  a09_result (*observe)(void *context, uint64_t identity, a09_manifestation *out);
  a09_result (*apply)(void *context, const a09_relation *proposal, a09_manifestation *out);
  a09_result (*revoke)(void *context, uint64_t identity);
} a09_manifestation_adapter;

uint16_t a09_gate_id(uint8_t a, uint8_t b);
a09_result a09_validate_relation(const a09_relation *r);
a09_result a09_mirror_relation(a09_relation *r, uint8_t domain_max);
a09_understanding a09_compare(const a09_manifestation *m);
a09_result a09_can_reconstruct(uint8_t reconstruction);
a09_result a09_commit_ready(const a09_relation *r, const a09_projection_result *p);
uint8_t a09_route9(uint64_t identity);

typedef enum {
  A091_PRESERVE=0, A091_RELATE=1, A091_PROJECT=2, A091_MIRROR=3,
  A091_PROBE=4, A091_CORRECT=5, A091_INTEGRATE=6
} a091_transform_family;

typedef enum {
  A091_SPARK_INTEGRATED=1, A091_SPARK_QUARANTINED=2,
  A091_SPARK_UNRESOLVED=3, A091_SPARK_REJECTED=4
} a091_spark_status;

typedef struct {
  uint64_t identity;
  uint64_t provenance;
  uint64_t expected_relation;
  uint64_t observed_relation;
  uint8_t transform_family;
  uint8_t rule;
  uint8_t status;
} a091_spark;

uint8_t a091_cell91(uint8_t transform_family,uint8_t rule);
a09_result a091_validate_spark(const a091_spark *spark);

typedef enum {
  A092_HUMAN_STAR=1, A092_MACHINE_STAR=2
} a092_star_class;

typedef enum {
  A092_HUMAN_TO_MACHINE=1, A092_MACHINE_TO_HUMAN=2, A092_BIDIRECTIONAL=3
} a092_bridge_direction;

typedef enum {
  A092_BRIDGE_DECLARED=1, A092_BRIDGE_VALIDATED=2, A092_BRIDGE_MANIFESTED=3,
  A092_BRIDGE_UNRESOLVED=4, A092_BRIDGE_REVOKED=5
} a092_bridge_state;

typedef struct {
  uint64_t identity;
  uint64_t relation;
  uint64_t provenance;
  uint8_t star_class;
  uint8_t authority;
  uint8_t reconstruction;
} a092_star;

typedef struct {
  uint64_t identity;
  uint64_t human_star;
  uint64_t machine_star;
  uint64_t relation;
  uint64_t intent;
  uint64_t constraints;
  uint64_t provenance;
  uint64_t result;
  uint8_t authority;
  uint8_t direction;
  uint8_t state;
} a092_star_bridge;

a09_result a092_validate_star(const a092_star *star);
a09_result a092_validate_bridge(const a092_star_bridge *bridge,const a092_star *human,const a092_star *machine);
a09_result a092_commit_bridge(a092_star_bridge *bridge,const a09_projection_result *projections);
a09_result a092_bridge_to_spark(const a092_star_bridge *bridge,a091_spark *spark);
#endif
