#include "astraia_v09.h"

uint16_t a09_gate_id(uint8_t a, uint8_t b){
  uint8_t i,j; uint16_t before;
  if(a>=22u||b>=22u||a==b)return UINT16_MAX;
  i=a<b?a:b; j=a<b?b:a;
  before=(uint16_t)(i*21u-(i*(i-1u))/2u);
  return (uint16_t)(before+(j-i-1u));
}

a09_result a09_validate_relation(const a09_relation *r){
  if(!r)return A09_INVALID;
  if(r->canonical_form>=22u)return A09_INVALID;
  if(r->gate>230u)return A09_INVALID;
  if(r->rule>13u)return A09_INVALID;
  if(r->direction>A09_BIDIRECTIONAL)return A09_INVALID;
  if(r->source==0u||r->target==0u||r->provenance==0u)return A09_INVALID;
  return A09_OK;
}

a09_result a09_mirror_relation(a09_relation *r,uint8_t domain_max){
  uint64_t tmp;
  if(!r||domain_max==0u||r->canonical_form>=domain_max)return A09_INVALID;
  r->canonical_form=(uint8_t)(domain_max-1u-r->canonical_form);
  tmp=r->source;r->source=r->target;r->target=tmp;
  if(r->direction==A09_FORWARD)r->direction=A09_REVERSE;
  else if(r->direction==A09_REVERSE)r->direction=A09_FORWARD;
  return A09_OK;
}

a09_understanding a09_compare(const a09_manifestation *m){
  if(!m||m->evidence==0u)return A09_REMAINS_UNRESOLVED;
  if(m->expected==m->observed)return A09_CONFIRM;
  if(m->reconstruction==A09_DERIVABLE||m->reconstruction==A09_REPROVISIONABLE)return A09_MANIFESTATION_FAULT;
  if(m->reconstruction==A09_PRESERVE||m->reconstruction==A09_DEVICE_UNIQUE||m->reconstruction==A09_PHYSICAL)return A09_CONTRADICTION;
  return A09_BLUEPRINT_INCOMPLETE;
}

a09_result a09_can_reconstruct(uint8_t r){
  return (r==A09_DERIVABLE||r==A09_REPROVISIONABLE)?A09_OK:A09_DENIED;
}

a09_result a09_commit_ready(const a09_relation *r,const a09_projection_result *p){
  if(a09_validate_relation(r)!=A09_OK||!p)return A09_INVALID;
  if(r->authority==0u)return A09_DENIED;
  return (p->abraham&&p->david&&p->solomon)?A09_OK:A09_UNRESOLVED;
}

uint8_t a09_route9(uint64_t x){
  uint64_t s=0u;
  if(x==0u)return 0u;
  while(x){s+=x%10u;x/=10u;}
  while(s>9u){uint64_t n=0u;while(s){n+=s%10u;s/=10u;}s=n;}
  return (uint8_t)s;
}

uint8_t a091_cell91(uint8_t transform_family,uint8_t rule){
  if(transform_family>6u||rule<1u||rule>13u)return UINT8_MAX;
  return (uint8_t)(13u*transform_family+(rule-1u));
}

a09_result a091_validate_spark(const a091_spark *s){
  if(!s||s->identity==0u||s->provenance==0u)return A09_INVALID;
  if(a091_cell91(s->transform_family,s->rule)==UINT8_MAX)return A09_INVALID;
  if(s->status<A091_SPARK_INTEGRATED||s->status>A091_SPARK_REJECTED)return A09_INVALID;
  return A09_OK;
}

a09_result a092_validate_star(const a092_star *s){
  if(!s||s->identity==0u||s->relation==0u||s->provenance==0u)return A09_INVALID;
  if(s->star_class!=A092_HUMAN_STAR&&s->star_class!=A092_MACHINE_STAR)return A09_INVALID;
  if(s->authority==0u)return A09_DENIED;
  if(s->reconstruction<A09_DERIVABLE||s->reconstruction>A09_PHYSICAL)return A09_INVALID;
  return A09_OK;
}

a09_result a092_validate_bridge(const a092_star_bridge *b,const a092_star *h,const a092_star *m){
  if(!b||a092_validate_star(h)!=A09_OK||a092_validate_star(m)!=A09_OK)return A09_INVALID;
  if(h->star_class!=A092_HUMAN_STAR||m->star_class!=A092_MACHINE_STAR)return A09_INVALID;
  if(b->identity==0u||b->relation==0u||b->intent==0u||b->provenance==0u)return A09_INVALID;
  if(b->human_star!=h->identity||b->machine_star!=m->identity)return A09_MISMATCH;
  if(b->relation!=h->relation||b->relation!=m->relation)return A09_MISMATCH;
  if(b->direction<A092_HUMAN_TO_MACHINE||b->direction>A092_BIDIRECTIONAL)return A09_INVALID;
  if(b->authority==0u||b->authority>h->authority||b->authority>m->authority)return A09_DENIED;
  return A09_OK;
}

a09_result a092_commit_bridge(a092_star_bridge *b,const a09_projection_result *p){
  if(!b||!p)return A09_INVALID;
  if(!p->abraham||!p->david||!p->solomon){b->state=A092_BRIDGE_UNRESOLVED;return A09_UNRESOLVED;}
  if(b->authority==0u)return A09_DENIED;
  b->state=A092_BRIDGE_MANIFESTED;
  return A09_OK;
}

a09_result a092_bridge_to_spark(const a092_star_bridge *b,a091_spark *s){
  if(!b||!s||b->identity==0u||b->provenance==0u)return A09_INVALID;
  s->identity=b->identity;
  s->provenance=b->provenance;
  s->expected_relation=b->relation;
  s->observed_relation=b->result;
  s->transform_family=A091_INTEGRATE;
  s->rule=13u;
  s->status=A091_SPARK_UNRESOLVED;
  return a091_validate_spark(s);
}
