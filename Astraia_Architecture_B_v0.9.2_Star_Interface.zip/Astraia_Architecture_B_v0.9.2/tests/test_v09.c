#include "astraia_v09.h"
#include <assert.h>
#include <stdio.h>

int main(void){
  uint16_t seen[231]={0}; unsigned count=0;
  for(uint8_t a=0;a<22;a++)for(uint8_t b=(uint8_t)(a+1);b<22;b++){
    uint16_t g=a09_gate_id(a,b); assert(g<231); assert(!seen[g]); seen[g]=1; count++;
    assert(a09_gate_id(a,b)==a09_gate_id(b,a));
  }
  assert(count==231); assert(a09_gate_id(1,1)==UINT16_MAX);

  a09_relation r={.source=10,.target=20,.provenance=30,.blueprint_generation=2,.manifestation_generation=1,.gate=20,.canonical_form=3,.direction=A09_FORWARD,.rule=13,.authority=1};
  assert(a09_validate_relation(&r)==A09_OK);
  a09_relation original=r;
  assert(a09_mirror_relation(&r,22)==A09_OK);
  assert(a09_mirror_relation(&r,22)==A09_OK);
  assert(r.source==original.source&&r.target==original.target&&r.canonical_form==original.canonical_form&&r.direction==original.direction);

  a09_manifestation m={.identity=1,.expected=42,.observed=42,.evidence=9,.reconstruction=A09_DERIVABLE};
  assert(a09_compare(&m)==A09_CONFIRM);
  m.observed=41; assert(a09_compare(&m)==A09_MANIFESTATION_FAULT);
  m.reconstruction=A09_DEVICE_UNIQUE; assert(a09_compare(&m)==A09_CONTRADICTION);
  assert(a09_can_reconstruct(A09_DERIVABLE)==A09_OK);
  assert(a09_can_reconstruct(A09_DEVICE_UNIQUE)==A09_DENIED);

  a09_projection_result p={1,1,1}; assert(a09_commit_ready(&original,&p)==A09_OK);
  p.solomon=0; assert(a09_commit_ready(&original,&p)==A09_UNRESOLVED);
  assert(a09_route9(26000)==8); assert(a09_route9(99999)==9); assert(a09_route9(0)==0);
  unsigned cells=0; uint8_t mark[91]={0};
  for(uint8_t f=0;f<7;f++)for(uint8_t rule=1;rule<=13;rule++){uint8_t c=a091_cell91(f,rule);assert(c<91);assert(!mark[c]);mark[c]=1;cells++;}
  assert(cells==91); assert(a091_cell91(7,1)==UINT8_MAX); assert(a091_cell91(0,14)==UINT8_MAX);
  a091_spark sp={.identity=4,.provenance=7,.expected_relation=10,.observed_relation=9,.transform_family=A091_INTEGRATE,.rule=13,.status=A091_SPARK_UNRESOLVED};
  assert(a091_validate_spark(&sp)==A09_OK);
  a092_star hs={.identity=100,.relation=500,.provenance=700,.star_class=A092_HUMAN_STAR,.authority=3,.reconstruction=A09_PRESERVE};
  a092_star ms={.identity=200,.relation=500,.provenance=701,.star_class=A092_MACHINE_STAR,.authority=2,.reconstruction=A09_REPROVISIONABLE};
  a092_star_bridge br={.identity=300,.human_star=100,.machine_star=200,.relation=500,.intent=600,.constraints=601,.provenance=702,.authority=2,.direction=A092_BIDIRECTIONAL,.state=A092_BRIDGE_DECLARED};
  assert(a092_validate_star(&hs)==A09_OK); assert(a092_validate_star(&ms)==A09_OK);
  assert(a092_validate_bridge(&br,&hs,&ms)==A09_OK);
  a09_projection_result bp={1,1,1}; assert(a092_commit_bridge(&br,&bp)==A09_OK); assert(br.state==A092_BRIDGE_MANIFESTED);
  bp.solomon=0; assert(a092_commit_bridge(&br,&bp)==A09_UNRESOLVED); assert(br.state==A092_BRIDGE_UNRESOLVED);
  a091_spark bsp={0}; assert(a092_bridge_to_spark(&br,&bsp)==A09_OK); assert(bsp.identity==br.identity&&bsp.expected_relation==br.relation);
  ms.relation=501; assert(a092_validate_bridge(&br,&hs,&ms)==A09_MISMATCH);
  puts("Architecture B v0.9.2 Star Interface tests passed");
  return 0;
}
