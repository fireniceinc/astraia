# One Relation Model
There is one internal semantic relation, not separate human/app/machine object models.

Human <-> Human Star <-> Semantic Frame <-> Astraia <-> AI/Machine Star <-> manifestation

A common application is a stable family of semantic relations. It is not required to be a process, package, window, API, or installed app.
