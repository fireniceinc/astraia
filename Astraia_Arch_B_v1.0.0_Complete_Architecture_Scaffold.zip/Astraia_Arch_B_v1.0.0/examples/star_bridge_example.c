#include "astraia_v09.h"

/* One semantic relation, rendered at two boundaries. */
int star_bridge_example(void){
  a092_star human={1,77,1001,A092_HUMAN_STAR,2,A09_PRESERVE};
  a092_star machine={2,77,1002,A092_MACHINE_STAR,2,A09_REPROVISIONABLE};
  a092_star_bridge bridge={3,1,2,77,900,901,1003,0,2,A092_HUMAN_TO_MACHINE,A092_BRIDGE_DECLARED};
  return a092_validate_bridge(&bridge,&human,&machine);
}
