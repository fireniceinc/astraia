#include "astraia_v09.h"
/* Hardware-free proof of one relation spanning both boundaries. */
int roundtrip(void){
  a092_star h={1,10,101,A092_HUMAN_STAR,2,A09_PRESERVE};
  a092_star m={2,10,102,A092_MACHINE_STAR,2,A09_REPROVISIONABLE};
  a093_semantic_frame f={3,10,20,30,40,0,50,103,0,2,A093_FRAME_DECLARED};
  a092_star_bridge b={0}; a09_projection_result p={1,1,1};
  if(a093_bind_frame(&f,&h,&m,&b)!=A09_OK)return 1;
  if(a093_validate_commit(&f,&b,&p)!=A09_OK)return 2;
  return a093_observe_result(&f,&b,50,104)==A09_OK?0:3;
}
