#include "astraia_v09.h"
int discovery_example(void){
  a092_star h={1,7,100,A092_HUMAN_STAR,2,A09_PRESERVE};
  a092_star machines[2]={{2,7,101,A092_MACHINE_STAR,2,A09_REPROVISIONABLE},{3,7,102,A092_MACHINE_STAR,2,A09_DERIVABLE}};
  a093_semantic_frame f={4,7,5,6,8,0,9,103,0,2,A093_FRAME_DECLARED};
  a094_selection s={0}; (void)h;
  return a094_select_machine_star(&f,machines,2,0,&s)==A09_OK && s.selected_identity==3 ? 0:1;
}
