#include "astraia_v09.h"
#include <string.h>

typedef struct { a09_manifestation item; } mock_context;
static a09_result observe(void *ctx,uint64_t id,a09_manifestation *out){mock_context*m=ctx;if(!m||!out||m->item.identity!=id)return A09_INVALID;*out=m->item;return A09_OK;}
static a09_result apply(void *ctx,const a09_relation *proposal,a09_manifestation *out){mock_context*m=ctx;if(!m||!proposal||!out)return A09_INVALID;m->item.observed=proposal->target;m->item.generation++;*out=m->item;return A09_OK;}
static a09_result revoke(void *ctx,uint64_t id){mock_context*m=ctx;if(!m||m->item.identity!=id)return A09_INVALID;m->item.observed=0;return A09_OK;}
a09_manifestation_adapter mock_adapter(mock_context *ctx){a09_manifestation_adapter a={ctx,observe,apply,revoke};return a;}
