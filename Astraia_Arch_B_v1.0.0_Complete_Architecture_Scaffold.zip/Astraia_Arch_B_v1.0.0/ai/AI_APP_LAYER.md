# AI Application Layer
AI is a capability behind Astraia, not Astraia's identity.

## Provider-neutral AI Stars
- language/reasoning
- speech-to-meaning
- meaning-to-speech
- vision understanding
- generation/creation
- retrieval/search
- planning
- coding/technical work
- document understanding
- translation

## Common human application capabilities
- conversation/assistant
- contacts/identity
- voice communication
- messaging
- mail
- calendar/reminders/tasks
- notes/memory
- camera/photos/media
- files/documents
- web/research
- maps/navigation/location
- calculator/conversion
- weather/information
- settings/device control
- accessibility
- authentication/authorization

These are semantic capabilities, not conventional apps. Multiple Machine Stars or AI Stars may satisfy one capability.
