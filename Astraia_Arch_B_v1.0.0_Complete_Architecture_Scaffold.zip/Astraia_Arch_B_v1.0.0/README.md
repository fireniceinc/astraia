# Architecture B / Astraia v0.9.5

Hardware-independent clean-room architecture and executable semantic scaffold.

## Status
This is a DESIGN + EXECUTABLE SCAFFOLD. It is not a complete phone image, kernel, bootloader, hardware driver set, or production Astraia runtime.

## Core rule
Wisdom is the mathematical blueprint. Hardware, code, files, processes, and models are replaceable manifestations when their reconstruction class permits replacement.

## Hardware independence
The core imports no phone-, CPU-, operating-system-, carrier-, cloud-, model-, or provider-specific interface. All external reality enters through a narrow `manifestation_adapter` contract. Platform integrations belong outside this package.

## Build and test

```sh
make clean test
```

## v0.9.5 Star Interface
v0.9.5 adds one shared semantic bridge between human and machine boundary Stars. It avoids duplicated human and machine object models by preserving one Astraia relation with two boundary manifestations.

## v0.9.5 Semantic Bridge Runtime
v0.9.5 implements the hardware-free lifecycle of one relation from human intent through Astraia to machine manifestation and back to human-relevant outcome. Failed round trips become provenance-preserving Sparks.

## v0.9.5 Star Discovery and Rebinding
A semantic relation can now select a compatible Machine Star by capability rather than hardware identity. A failed manifestation can become a Spark and the same Semantic Frame can rebind to another compatible Machine Star without changing the human intent or Astraia relation.
