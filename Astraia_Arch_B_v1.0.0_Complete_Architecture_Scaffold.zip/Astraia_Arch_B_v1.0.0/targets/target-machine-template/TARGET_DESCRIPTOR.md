# Target Descriptor
Record observed CPU/ABI, compiler, byte order, memory, privilege boundary, storage, display, input, audio, network, sensors, isolation, recovery path, reversible actions, and device-unique state. Expose each capability through a Machine Star adapter. Keep target facts outside the portable runtime.
