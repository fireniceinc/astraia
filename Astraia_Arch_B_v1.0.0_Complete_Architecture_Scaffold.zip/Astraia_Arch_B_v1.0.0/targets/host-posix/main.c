#include "astraia_runtime.h"
#include <stdio.h>
static void out(void*c,const a095_event*e){(void)c;printf("%llu %u %llu\n",(unsigned long long)e->sequence,e->kind,(unsigned long long)e->subject);}
int main(void){a095_runtime r;a092_star h={1,10,1,A092_HUMAN_STAR,2,A09_PRESERVE},m={2,10,2,A092_MACHINE_STAR,2,A09_DERIVABLE};a093_semantic_frame f={3,10,4,5,6,0,7,3,0,2,A093_FRAME_DECLARED};a09_projection_result p={1,1,1};a092_star_bridge b={0};a091_spark s={0};a095_runtime_init(&r,out,0);a095_register_star(&r,&h);a095_register_star(&r,&m);a095_declare_frame(&r,&f);return a095_run_frame(&r,3,1,&p,7,4,&b,&s);}
