#ifndef ASTRAIA_RUNTIME_H
#define ASTRAIA_RUNTIME_H
#include "astraia_v09.h"
#define A095_MAX_STARS 32u
#define A095_MAX_FRAMES 16u
typedef enum{A095_EV_REGISTER=1,A095_EV_DECLARE,A095_EV_BIND,A095_EV_COMMIT,A095_EV_OBSERVE,A095_EV_SATISFY,A095_EV_FAIL,A095_EV_SPARK}a095_event_kind;
typedef struct{uint64_t sequence,subject,relation,evidence;uint8_t kind,result;}a095_event;
typedef void(*a095_event_sink)(void*,const a095_event*);
typedef struct{a092_star stars[A095_MAX_STARS];size_t star_count;a093_semantic_frame frames[A095_MAX_FRAMES];size_t frame_count;uint64_t sequence;a095_event_sink sink;void*sink_context;}a095_runtime;
a09_result a095_runtime_init(a095_runtime*,a095_event_sink,void*);
a09_result a095_register_star(a095_runtime*,const a092_star*);
a09_result a095_declare_frame(a095_runtime*,const a093_semantic_frame*);
a09_result a095_run_frame(a095_runtime*,uint64_t,uint64_t,const a09_projection_result*,uint64_t,uint64_t,a092_star_bridge*,a091_spark*);
#endif
