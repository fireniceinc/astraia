#ifndef ASTRAIA_V1_H
#define ASTRAIA_V1_H
#include "astraia_runtime.h"
#define A1_MAX_CAPS 32u
#define A1_MAX_AI 16u
typedef enum{A1_CAP_CONVERSE=1,A1_CAP_CONTACTS,A1_CAP_VOICE,A1_CAP_MESSAGE,A1_CAP_MAIL,A1_CAP_CALENDAR,A1_CAP_TASKS,A1_CAP_NOTES,A1_CAP_CAMERA,A1_CAP_MEDIA,A1_CAP_FILES,A1_CAP_WEB,A1_CAP_MAPS,A1_CAP_CALCULATE,A1_CAP_WEATHER,A1_CAP_SETTINGS,A1_CAP_ACCESSIBILITY,A1_CAP_AUTH}a1_common_capability;
typedef enum{A1_AI_REASON=1,A1_AI_SPEECH_IN,A1_AI_SPEECH_OUT,A1_AI_VISION,A1_AI_GENERATE,A1_AI_RETRIEVE,A1_AI_PLAN,A1_AI_CODE,A1_AI_DOCUMENT,A1_AI_TRANSLATE}a1_ai_kind;
typedef struct{uint64_t identity;uint64_t relation;uint64_t provenance;uint8_t kind;uint8_t authority;}a1_ai_star;
typedef struct{uint64_t actor;uint64_t target;uint64_t provenance;uint64_t constraints;uint64_t success;uint8_t capability;uint8_t authority;}a1_human_intent;
typedef struct{uint64_t frame_id;uint64_t relation;uint64_t outcome;uint8_t satisfied;}a1_human_outcome;
typedef struct{a095_runtime runtime;a1_ai_star ai[A1_MAX_AI];size_t ai_count;uint64_t next_frame;}a1_system;
a09_result a1_init(a1_system*,a095_event_sink,void*);
a09_result a1_register_human_star(a1_system*,const a092_star*);
a09_result a1_register_machine_star(a1_system*,const a092_star*);
a09_result a1_register_ai_star(a1_system*,const a1_ai_star*);
a09_result a1_intent_to_frame(a1_system*,const a1_human_intent*,a093_semantic_frame*);
a09_result a1_complete_outcome(const a093_semantic_frame*,a1_human_outcome*);
#endif
