# Astraia Human Interface
The human boundary accepts expression and returns meaning without exposing machine implementation by default.

Input modalities: text, speech, touch/selection, image, gesture/event, imported document.
Output modalities: text, speech, visual surface, notification, haptic/event, accessible structured output.

Human request -> Human Star -> Semantic Frame -> Astraia -> Machine/AI Star.
Machine/AI observation -> Astraia -> Human Star -> consequence/choice/status/explanation.

The interface shows device-level evidence on request or when necessary for informed authorization.
