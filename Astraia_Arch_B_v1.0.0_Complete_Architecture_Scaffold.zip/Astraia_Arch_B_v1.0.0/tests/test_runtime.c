#include "astraia_runtime.h"
#include <assert.h>
static void sink(void*c,const a095_event*e){size_t*n=c;(*n)++;(void)e;}
int main(void){a095_runtime r;size_t n=0;a092_star h={1,20,100,A092_HUMAN_STAR,2,A09_PRESERVE},m={2,20,101,A092_MACHINE_STAR,2,A09_DERIVABLE};a093_semantic_frame f={3,20,4,5,6,0,9,102,0,2,A093_FRAME_DECLARED};a09_projection_result p={1,1,1};a092_star_bridge b={0};a091_spark s={0};assert(a095_runtime_init(&r,sink,&n)==A09_OK);assert(a095_register_star(&r,&h)==A09_OK);assert(a095_register_star(&r,&m)==A09_OK);assert(a095_declare_frame(&r,&f)==A09_OK);assert(a095_run_frame(&r,3,1,&p,9,103,&b,&s)==A09_OK);assert(n>=7);return 0;}
