# Machine Layer
Machine capabilities are exposed as Machine Stars. The portable runtime never invokes a device directly.

Required target capability families:
compute, memory, persistent storage, display, touch/input, audio-in, audio-out, imaging, network, cellular/telephony, messaging transport, positioning, sensors, power, time, secure identity/key material, removable/USB transport.

Every adapter reports identity, relation, authority, reconstruction class, observation evidence, reversible actions, irreversible actions, and revocation behavior.
