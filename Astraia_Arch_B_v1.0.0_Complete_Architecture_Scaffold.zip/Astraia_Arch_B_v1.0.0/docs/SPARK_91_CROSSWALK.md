# Architecture B v0.9.1 - Spark / 91 Crosswalk

## Mathematical correction
91 is NOT 13 factorial. 13! = 6,227,020,800.
91 is both:
- 7 x 13 = 91
- the triangular number T13 = 1+2+...+13 = 91 = 13x14/2.

This distinction is locked so the architecture never confuses factorial, product, and triangular constructions.

## Historical-source boundary
Lurianic 'sparks' are traditionally discussed as 288 sparks associated with shattered vessels and repair/tikkun. Architecture B does not relabel that historical count as 91.

## Clean-room architecture use of 'spark'
A SPARK is a recoverable relational fragment whose local manifestation has become disconnected, degraded, contradictory, or insufficiently integrated while retaining enough identity/provenance to be evaluated against Wisdom.

Redeeming a spark means RE-INTEGRATION, not deletion:
1. preserve fragment identity and provenance;
2. locate its expected place in Wisdom;
3. observe its actual manifestation;
4. evaluate through a transformation family and inference rule;
5. test through Abraham, David, Solomon;
6. re-integrate, quarantine, preserve unresolved, or reject the proposed relation;
7. append the result to Book.

## Why 91 is useful in v0.9.1
The architecture introduces a 7 x 13 validation cross-product:
- 7 transformation families;
- 13 inference rules;
- 91 transformation-rule cells.

This is a CLEAN-ROOM engineering construction. It is not claimed as a historical Kabbalistic teaching.

## Seven transformation families - provisional
0 PRESERVE - retain identity/invariant.
1 RELATE - establish or examine relation.
2 PROJECT - examine through a defined orientation.
3 MIRROR - apply a proven self-inverse counter-orientation.
4 PROBE - request bounded observation from manifestation.
5 CORRECT - supersede while preserving predecessor/provenance.
6 INTEGRATE - restore a validated fragment into coherent state.

Each family can be paired with inference rules 1..13, yielding cells 0..90.

## 91 cell indexing
For family f in 0..6 and rule r in 1..13:

    cell = 13*f + (r-1)

Range: 0..90, exactly 91 cells.

No cell is valid merely because it exists. Each must eventually have formal preconditions, outputs, provenance rules, counterexamples, and conformance tests.
