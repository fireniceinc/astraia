# Machine Interface Contract

The machine interface exposes capabilities and observations through Stars.

A machine Star declares:
- stable identity;
- capability relation;
- observation contract;
- bounded action contract;
- authority requirements;
- reconstruction class;
- evidence form;
- revocation behavior.

The machine interface does not receive natural-language instructions. It receives validated Astraia relations and returns observations/evidence.
