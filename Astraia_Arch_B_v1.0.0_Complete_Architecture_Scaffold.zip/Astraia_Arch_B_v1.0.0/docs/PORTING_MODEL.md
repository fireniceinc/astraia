# Porting Model

A new device does not require changing the Architecture B core.

A port supplies:
- a seed implementation beneath the core;
- one or more manifestation adapters;
- preserved device-unique artifacts where applicable;
- conformance evidence showing that observed effects match abstract contracts.

The first port may target SM-S176V, but no SM-S176V detail exists in canonical core code.
