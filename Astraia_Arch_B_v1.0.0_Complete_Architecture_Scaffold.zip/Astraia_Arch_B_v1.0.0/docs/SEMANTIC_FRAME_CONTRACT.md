# Semantic Frame Contract

A semantic frame is the single center object shared by both boundaries.

Required information:
- relation identity;
- actor reference;
- target/capability reference;
- intent;
- constraints;
- success condition;
- provenance;
- delegated authority;
- lifecycle state.

Human payload and machine payload are not copied into the frame. Boundaries may retain their own payload and attach evidence references.

Lifecycle:
DECLARED -> BOUND -> VALIDATED -> MANIFESTED -> OBSERVED -> SATISFIED
                                               -> UNRESOLVED
                                               -> FAILED -> SPARK

A state transition never erases prior evidence.
