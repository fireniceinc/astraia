# Architecture B v0.9.4 - Star Discovery and Rebinding

## Decision
The next missing capability after the semantic round trip is dynamic manifestation selection.

Astraia must not require a human intent to name a device. A semantic relation names the required capability; available Machine Stars advertise compatible relations.

## Flow
Human intent -> Semantic Frame -> relation requirement -> Machine Star discovery -> candidate selection -> Abraham/David/Solomon -> manifestation -> observation.

If the selected Machine Star fails, preserve the same Semantic Frame and relation identity, create a Spark for the failed manifestation, revoke the failed Star for that bridge, and rebind to another compatible Star if one exists.

## Minimal selection rule
v0.9.4 deliberately uses a small deterministic selector. A candidate is eligible only when:
- it is a valid Machine Star;
- relation matches the Semantic Frame;
- authority is sufficient;
- it is not the excluded failed Star.

Among eligible candidates, prefer the lowest reconstruction risk, then the least authority excess, then the lowest stable identity as a deterministic tie-breaker.

This is a scaffold policy, not the final Solomon policy.
