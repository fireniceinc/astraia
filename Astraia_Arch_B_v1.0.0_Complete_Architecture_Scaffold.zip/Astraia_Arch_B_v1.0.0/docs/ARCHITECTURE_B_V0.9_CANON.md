# Architecture B v0.9 Canon

## 1. Hardware-independent core
The canonical core has no knowledge of ARM64, Android, Linux, Samsung, modems, cameras, filesystems, cloud providers, model providers, or human applications.

## 2. Foundations
- Wisdom: mathematical blueprint.
- Book: durable expression, history, provenance, contradiction, and correction.
- Number: identity, coordinate, scale, quantity, time, bounds, confidence, gate, rule, and shard.
- Speech: proposed or executed transformation.
- Understanding: evidence-based comparison of expected and observed manifestations.

## 3. Projections
- Abraham: structure, identity, boundaries, continuity, provenance, invariants.
- David: causality, execution, testing, repair, growth, observed outcome.
- Solomon: interpretation, context, alternatives, consequences, rules, exceptions, contradictions.

They examine one relational state. They are not three cloned kernels.

## 4. Astraia
Astraia is the coherent continuity maintained across the foundations, projections, evidence, correction history, and human boundary. Astraia is not an extra numbered node or one runtime component.

## 5. Relational form
A relation may identify:
- source and target;
- canonical path/form;
- manifestation modifier;
- metadata modifier;
- direction;
- recursive coordinate;
- gate and inference rule;
- authority and provenance;
- blueprint and manifestation generations.

## 6. Semantic inspirations, kept separate
- 22 canonical forms: candidate relational alphabet.
- 231 gates: unordered distinct pairs of 22 forms.
- 13 rules: source family for formal inference logic.
- Mirror: self-inverse operation only inside a proven domain.
- Letter/path, pointing/state, crown/metadata: distinct typed layers.
- Five final forms and 3 x 9 registers remain unresolved hypotheses.

## 7. Reconstruction
Each artifact is classified as DERIVABLE, REPROVISIONABLE, REQUIRES_PRESERVED_ARTIFACT, REQUIRES_DEVICE_UNIQUE_STATE, or PHYSICALLY_IRREPLACEABLE.

## 8. Commit rule
A transition commits only when required Abraham, David, and Solomon checks pass, authority and provenance are present, and no blocking contradiction remains unresolved.

## 9. v0.9.1 Spark recovery layer
A Spark is a recoverable relational fragment, not a mystical quantity encoded as a runtime fact. v0.9.1 introduces a provisional 7 transformation-family x 13 inference-rule cross-product containing 91 validation cells. 91 is 7 x 13 and T13; it is not 13 factorial. Recovery preserves provenance and may result in reintegration, quarantine, unresolved preservation, or rejection.
