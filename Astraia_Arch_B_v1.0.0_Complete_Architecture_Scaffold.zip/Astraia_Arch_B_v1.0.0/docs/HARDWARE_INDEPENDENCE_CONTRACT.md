# Hardware Independence Contract

## Core may depend on
- fixed-width integer types;
- caller-supplied memory;
- deterministic pure functions;
- abstract observations and proposals.

## Core must not depend on
- operating-system calls;
- threads;
- wall-clock time;
- files or paths;
- sockets;
- device registers;
- CPU-specific instructions;
- dynamic allocation;
- Unicode parsing;
- model APIs;
- provider credentials.

## Adapter boundary
An external manifestation adapter may:
1. enumerate a manifestation;
2. observe it;
3. apply a bounded proposal;
4. revoke authority;
5. report whether an item can be derived, reprovisioned, must be preserved, is device-unique, or is physically irreplaceable.

The adapter never receives unrestricted access to Astraia coherence state. The core never assumes that a failed physical item is reconstructible.
