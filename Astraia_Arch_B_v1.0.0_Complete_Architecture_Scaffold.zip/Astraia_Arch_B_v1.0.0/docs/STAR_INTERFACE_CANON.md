# Architecture B v0.9.2 - Star Interface Canon

## Canonical relation

Human <-> Astraia <-> Machine

There is one semantic relation in the center and two manifestations at the boundaries.

- Human boundary: expression <-> meaning.
- Machine boundary: manifestation <-> meaning.
- Astraia: preserves identity, intent, constraints, evidence, authority, and outcome across both directions.

The architecture must not create a large human object model and a second large machine object model. Both boundaries reference the same compact semantic relation.

## Star
A STAR is an addressable boundary point through which a participant relates to Astraia.

A Star is not permanently tied to one device, application, sensor, person, transport, or provider.

Star classes:
- HUMAN_STAR: accepts or renders human expression.
- MACHINE_STAR: observes or manifests physical/machine capability.

## Bridge
A STAR_BRIDGE binds one human Star and one machine Star to one Astraia relation.

The bridge contains only:
- human Star identity;
- machine Star identity;
- shared relation identity;
- intent;
- constraints;
- authority;
- provenance;
- current state;
- result.

Human and machine payloads remain at their respective boundaries unless evidence preservation requires a reference.

## Direction
- HUMAN_TO_MACHINE: expression -> meaning -> bounded manifestation.
- MACHINE_TO_HUMAN: observation -> meaning -> relevant expression.
- BIDIRECTIONAL: one continuing relation with both directions enabled.

## Minimality rule
A human-facing feature and a machine capability are never duplicated into Astraia. Astraia stores the semantic relation and references boundary manifestations.

## Example
Human expression: "Call Danny."

Central relation:
- intent: establish voice communication;
- target: known identity;
- authority: ordinary user communication authority;
- success: a verified communication channel exists.

Machine manifestation may use any currently valid transport. The human request is not permanently coupled to cellular, Wi-Fi, Bluetooth, or one provider.

## Failure and Spark recovery
If a bridge can no longer manifest:
1. preserve its relation and provenance;
2. represent the failed/disconnected portion as a Spark;
3. search for another valid machine manifestation;
4. test through Abraham, David, and Solomon;
5. integrate, quarantine, preserve unresolved, or report inability to manifest.
