# Human Interface Contract

The human interface may use speech, text, touch, images, gestures, controls, or future modalities.

It must emit a compact intent frame containing:
- actor identity reference;
- requested relation;
- target identity or capability;
- constraints;
- delegated authority;
- success condition;
- provenance reference.

It must render machine outcomes as consequence, choice, state, and explanation appropriate to the human context. Device-level detail remains available as evidence but is not the default human representation.

The human interface does not directly operate hardware.
