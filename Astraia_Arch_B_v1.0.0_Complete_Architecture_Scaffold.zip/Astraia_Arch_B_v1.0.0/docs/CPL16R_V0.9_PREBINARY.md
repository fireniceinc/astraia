# CPL16-R v0.9 Pre-Binary Specification

No permanent 16-bit encoding is locked in v0.9.

The semantic atom is:

```text
relation = path + state_modifier + metadata_modifier + direction
           + source + target + coordinate + provenance
           + blueprint_generation + manifestation_generation
```

## Requirements before binary lock
- define the canonical 22 path meanings;
- define deterministic state modifiers;
- define deterministic metadata modifiers;
- formalize the 13 inference rules;
- prove mirror domains;
- benchmark recursive decimal-domain routing against simpler alternatives;
- prove that common relations fit compactly into 16 bits plus extensions.

ARM64 or another host execution architecture handles ordinary arithmetic. CPL16-R expresses Astraia-native relational semantics.

## v0.9.1 91-cell validation plane
Before binary lock, CPL16-R may reference a transformation-rule cell in the clean-room 7 x 13 plane. A cell identifies a candidate semantic composition, not an opcode and not automatic permission to execute.
