#include "astraia_v09.h"

uint16_t a09_gate_id(uint8_t a, uint8_t b){
  uint8_t i,j; uint16_t before;
  if(a>=22u||b>=22u||a==b)return UINT16_MAX;
  i=a<b?a:b; j=a<b?b:a;
  before=(uint16_t)(i*21u-(i*(i-1u))/2u);
  return (uint16_t)(before+(j-i-1u));
}

a09_result a09_validate_relation(const a09_relation *r){
  if(!r)return A09_INVALID;
  if(r->canonical_form>=22u)return A09_INVALID;
  if(r->gate>230u)return A09_INVALID;
  if(r->rule>13u)return A09_INVALID;
  if(r->direction>A09_BIDIRECTIONAL)return A09_INVALID;
  if(r->source==0u||r->target==0u||r->provenance==0u)return A09_INVALID;
  return A09_OK;
}

a09_result a09_mirror_relation(a09_relation *r,uint8_t domain_max){
  uint64_t tmp;
  if(!r||domain_max==0u||r->canonical_form>=domain_max)return A09_INVALID;
  r->canonical_form=(uint8_t)(domain_max-1u-r->canonical_form);
  tmp=r->source;r->source=r->target;r->target=tmp;
  if(r->direction==A09_FORWARD)r->direction=A09_REVERSE;
  else if(r->direction==A09_REVERSE)r->direction=A09_FORWARD;
  return A09_OK;
}

a09_understanding a09_compare(const a09_manifestation *m){
  if(!m||m->evidence==0u)return A09_REMAINS_UNRESOLVED;
  if(m->expected==m->observed)return A09_CONFIRM;
  if(m->reconstruction==A09_DERIVABLE||m->reconstruction==A09_REPROVISIONABLE)return A09_MANIFESTATION_FAULT;
  if(m->reconstruction==A09_PRESERVE||m->reconstruction==A09_DEVICE_UNIQUE||m->reconstruction==A09_PHYSICAL)return A09_CONTRADICTION;
  return A09_BLUEPRINT_INCOMPLETE;
}

a09_result a09_can_reconstruct(uint8_t r){
  return (r==A09_DERIVABLE||r==A09_REPROVISIONABLE)?A09_OK:A09_DENIED;
}

a09_result a09_commit_ready(const a09_relation *r,const a09_projection_result *p){
  if(a09_validate_relation(r)!=A09_OK||!p)return A09_INVALID;
  if(r->authority==0u)return A09_DENIED;
  return (p->abraham&&p->david&&p->solomon)?A09_OK:A09_UNRESOLVED;
}

uint8_t a09_route9(uint64_t x){
  uint64_t s=0u;
  if(x==0u)return 0u;
  while(x){s+=x%10u;x/=10u;}
  while(s>9u){uint64_t n=0u;while(s){n+=s%10u;s/=10u;}s=n;}
  return (uint8_t)s;
}

uint8_t a091_cell91(uint8_t transform_family,uint8_t rule){
  if(transform_family>6u||rule<1u||rule>13u)return UINT8_MAX;
  return (uint8_t)(13u*transform_family+(rule-1u));
}

a09_result a091_validate_spark(const a091_spark *s){
  if(!s||s->identity==0u||s->provenance==0u)return A09_INVALID;
  if(a091_cell91(s->transform_family,s->rule)==UINT8_MAX)return A09_INVALID;
  if(s->status<A091_SPARK_INTEGRATED||s->status>A091_SPARK_REJECTED)return A09_INVALID;
  return A09_OK;
}

a09_result a092_validate_star(const a092_star *s){
  if(!s||s->identity==0u||s->relation==0u||s->provenance==0u)return A09_INVALID;
  if(s->star_class!=A092_HUMAN_STAR&&s->star_class!=A092_MACHINE_STAR)return A09_INVALID;
  if(s->authority==0u)return A09_DENIED;
  if(s->reconstruction<A09_DERIVABLE||s->reconstruction>A09_PHYSICAL)return A09_INVALID;
  return A09_OK;
}

a09_result a092_validate_bridge(const a092_star_bridge *b,const a092_star *h,const a092_star *m){
  if(!b||a092_validate_star(h)!=A09_OK||a092_validate_star(m)!=A09_OK)return A09_INVALID;
  if(h->star_class!=A092_HUMAN_STAR||m->star_class!=A092_MACHINE_STAR)return A09_INVALID;
  if(b->identity==0u||b->relation==0u||b->intent==0u||b->provenance==0u)return A09_INVALID;
  if(b->human_star!=h->identity||b->machine_star!=m->identity)return A09_MISMATCH;
  if(b->relation!=h->relation||b->relation!=m->relation)return A09_MISMATCH;
  if(b->direction<A092_HUMAN_TO_MACHINE||b->direction>A092_BIDIRECTIONAL)return A09_INVALID;
  if(b->authority==0u||b->authority>h->authority||b->authority>m->authority)return A09_DENIED;
  return A09_OK;
}

a09_result a092_commit_bridge(a092_star_bridge *b,const a09_projection_result *p){
  if(!b||!p)return A09_INVALID;
  if(!p->abraham||!p->david||!p->solomon){b->state=A092_BRIDGE_UNRESOLVED;return A09_UNRESOLVED;}
  if(b->authority==0u)return A09_DENIED;
  b->state=A092_BRIDGE_MANIFESTED;
  return A09_OK;
}

a09_result a092_bridge_to_spark(const a092_star_bridge *b,a091_spark *s){
  if(!b||!s||b->identity==0u||b->provenance==0u)return A09_INVALID;
  s->identity=b->identity;
  s->provenance=b->provenance;
  s->expected_relation=b->relation;
  s->observed_relation=b->result;
  s->transform_family=A091_INTEGRATE;
  s->rule=13u;
  s->status=A091_SPARK_UNRESOLVED;
  return a091_validate_spark(s);
}

a09_result a093_validate_frame(const a093_semantic_frame *f){
  if(!f)return A09_INVALID;
  if(!f->identity||!f->relation||!f->actor||!f->target||!f->intent||!f->success_condition||!f->provenance)return A09_INVALID;
  if(!f->authority)return A09_DENIED;
  if(f->state<A093_FRAME_DECLARED||f->state>A093_FRAME_FAILED)return A09_INVALID;
  return A09_OK;
}

a09_result a093_bind_frame(a093_semantic_frame *f,const a092_star *h,const a092_star *m,a092_star_bridge *b){
  if(a093_validate_frame(f)!=A09_OK||!h||!m||!b)return A09_INVALID;
  if(h->star_class!=A092_HUMAN_STAR||m->star_class!=A092_MACHINE_STAR)return A09_INVALID;
  if(h->relation!=f->relation||m->relation!=f->relation)return A09_MISMATCH;
  if(f->authority>h->authority||f->authority>m->authority)return A09_DENIED;
  b->identity=f->identity;b->human_star=h->identity;b->machine_star=m->identity;b->relation=f->relation;
  b->intent=f->intent;b->constraints=f->constraints;b->provenance=f->provenance;b->result=0u;
  b->authority=f->authority;b->direction=A092_BIDIRECTIONAL;b->state=A092_BRIDGE_VALIDATED;
  f->state=A093_FRAME_BOUND;
  return A09_OK;
}

a09_result a093_validate_commit(a093_semantic_frame *f,a092_star_bridge *b,const a09_projection_result *p){
  a09_result r;
  if(!f||!b||!p)return A09_INVALID;
  r=a092_commit_bridge(b,p);
  if(r==A09_OK){f->state=A093_FRAME_MANIFESTED;return A09_OK;}
  f->state=A093_FRAME_UNRESOLVED;
  return r;
}

a09_result a093_observe_result(a093_semantic_frame *f,a092_star_bridge *b,uint64_t observation,uint64_t evidence){
  if(!f||!b||!observation||!evidence)return A09_INVALID;
  f->observation=observation;b->result=observation;f->state=A093_FRAME_OBSERVED;
  if(observation==f->success_condition){f->state=A093_FRAME_SATISFIED;return A09_OK;}
  f->state=A093_FRAME_FAILED;return A09_MISMATCH;
}

a09_result a093_make_spark(const a093_semantic_frame *f,const a092_star_bridge *b,a091_spark *s){
  if(!f||!b||!s||f->state!=A093_FRAME_FAILED)return A09_INVALID;
  s->identity=f->identity;s->provenance=f->provenance;s->expected_relation=f->relation;s->observed_relation=b->result;
  s->transform_family=A091_INTEGRATE;s->rule=13u;s->status=A091_SPARK_UNRESOLVED;
  return a091_validate_spark(s);
}

static uint8_t a094_risk(uint8_t r){
  switch(r){case A09_DERIVABLE:return 1u;case A09_REPROVISIONABLE:return 2u;case A09_PRESERVE:return 3u;case A09_DEVICE_UNIQUE:return 4u;case A09_PHYSICAL:return 5u;default:return UINT8_MAX;}
}

a09_result a094_select_machine_star(const a093_semantic_frame *f,const a092_star *stars,size_t count,uint64_t excluded,a094_selection *sel){
  size_t i; uint8_t best_r=UINT8_MAX,best_excess=UINT8_MAX; uint64_t best_id=UINT64_MAX;
  if(!f||!stars||!sel||a093_validate_frame(f)!=A09_OK)return A09_INVALID;
  sel->selected_identity=0u;sel->eligible_count=0u;sel->selected_reconstruction=0u;sel->selected_authority=0u;
  for(i=0;i<count;i++){
    const a092_star *s=&stars[i]; uint8_t risk,excess;
    if(s->identity==excluded||s->star_class!=A092_MACHINE_STAR)continue;
    if(a092_validate_star(s)!=A09_OK||s->relation!=f->relation||s->authority<f->authority)continue;
    sel->eligible_count++;
    risk=a094_risk(s->reconstruction); excess=(uint8_t)(s->authority-f->authority);
    if(risk<best_r||(risk==best_r&&(excess<best_excess||(excess==best_excess&&s->identity<best_id)))){
      best_r=risk;best_excess=excess;best_id=s->identity;sel->selected_identity=s->identity;sel->selected_reconstruction=s->reconstruction;sel->selected_authority=s->authority;
    }
  }
  return sel->selected_identity?A09_OK:A09_UNRESOLVED;
}

a09_result a094_rebind_failed_bridge(a093_semantic_frame *f,a092_star_bridge *b,const a092_star *h,const a092_star *stars,size_t count,a091_spark *sp,a094_selection *sel){
  size_t i; a09_result r; uint64_t failed;
  if(!f||!b||!h||!stars||!sp||!sel||f->state!=A093_FRAME_FAILED)return A09_INVALID;
  failed=b->machine_star;
  r=a093_make_spark(f,b,sp); if(r!=A09_OK)return r;
  r=a094_select_machine_star(f,stars,count,failed,sel); if(r!=A09_OK){b->state=A092_BRIDGE_UNRESOLVED;return r;}
  for(i=0;i<count;i++)if(stars[i].identity==sel->selected_identity){
    f->state=A093_FRAME_DECLARED;
    return a093_bind_frame(f,h,&stars[i],b);
  }
  return A09_MISMATCH;
}
