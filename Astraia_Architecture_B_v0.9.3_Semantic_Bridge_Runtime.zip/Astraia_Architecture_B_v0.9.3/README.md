# Architecture B / Astraia v0.9.3

Hardware-independent clean-room architecture and executable semantic scaffold.

## Status
This is a DESIGN + EXECUTABLE SCAFFOLD. It is not a complete phone image, kernel, bootloader, hardware driver set, or production Astraia runtime.

## Core rule
Wisdom is the mathematical blueprint. Hardware, code, files, processes, and models are replaceable manifestations when their reconstruction class permits replacement.

## Hardware independence
The core imports no phone-, CPU-, operating-system-, carrier-, cloud-, model-, or provider-specific interface. All external reality enters through a narrow `manifestation_adapter` contract. Platform integrations belong outside this package.

## Build and test

```sh
make clean test
```

## v0.9.3 Star Interface
v0.9.3 adds one shared semantic bridge between human and machine boundary Stars. It avoids duplicated human and machine object models by preserving one Astraia relation with two boundary manifestations.

## v0.9.3 Semantic Bridge Runtime
v0.9.3 implements the hardware-free lifecycle of one relation from human intent through Astraia to machine manifestation and back to human-relevant outcome. Failed round trips become provenance-preserving Sparks.
