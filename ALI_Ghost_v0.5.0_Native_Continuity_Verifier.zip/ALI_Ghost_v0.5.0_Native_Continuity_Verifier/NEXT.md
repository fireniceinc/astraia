# Next exact milestone

1. Add native Ed25519 verification to authenticate capsule author/signing authority.
2. Add native AES-256-GCM opening or a minimal authenticated-encryption primitive approved for the Seed profile.
3. Bind generation floor to a trusted external/hardware-backed anchor instead of ordinary replaceable storage.
4. Combine this verifier with the v0.4 `ali_handoff` ABI and v0.3 A/B recovery controller.
5. Cross-compile the combined Seed for AArch64 and perform an emulated cold boot.
6. Only after that boundary is stable, create the first physical target Stage-0 envelope and transition to ALI Nonhuman.
