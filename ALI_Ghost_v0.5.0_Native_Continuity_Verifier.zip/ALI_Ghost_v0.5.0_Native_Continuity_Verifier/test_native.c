#include "ali_continuity.h"
#include <stdio.h>
#include <stdlib.h>
int main(void){
 FILE*f=fopen("capsule_ok.bin","rb"); if(!f)return 2; fseek(f,0,SEEK_END); long n=ftell(f); rewind(f);
 unsigned char*b=malloc((size_t)n); if(!b)return 3; if(fread(b,1,(size_t)n,f)!=(size_t)n)return 4; fclose(f);
 if(ali_verify_capsule(b,(size_t)n,7)!=ALI_VERIFY_VERIFIED)return 10;
 if(ali_verify_capsule(b,(size_t)n,8)!=ALI_VERIFY_ROLLBACK)return 11;
 b[n-1]^=1; if(ali_verify_capsule(b,(size_t)n,7)!=ALI_VERIFY_INVALID)return 12;
 free(b); puts("ALI Ghost v0.5 native continuity verifier tests: PASS"); return 0;
}
