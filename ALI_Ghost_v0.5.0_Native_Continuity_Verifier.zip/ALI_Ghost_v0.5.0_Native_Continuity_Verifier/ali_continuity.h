#ifndef ALI_CONTINUITY_H
#define ALI_CONTINUITY_H
#include <stdint.h>
#include <stddef.h>
#define ALI_CAPSULE_MAGIC 0x414C4943u /* ALIC */
#define ALI_CAPSULE_VERSION 1u
typedef enum { ALI_VERIFY_VERIFIED=0, ALI_VERIFY_INVALID=1, ALI_VERIFY_ROLLBACK=2, ALI_VERIFY_UNSUPPORTED=3 } ali_verify_result;
#pragma pack(push,1)
typedef struct {
  uint32_t magic;
  uint16_t version;
  uint16_t flags;
  uint64_t generation;
  uint32_t payload_len;
  uint8_t payload_sha256[32];
} ali_capsule_header;
#pragma pack(pop)
ali_verify_result ali_verify_capsule(const uint8_t *buf, size_t len, uint64_t min_generation);
#endif
