
#include "ali_continuity.h"
#include <string.h>

typedef struct { uint32_t h[8]; uint64_t bits; uint8_t b[64]; size_t n; } S;
static uint32_t R(uint32_t x,unsigned n){return (x>>n)|(x<<(32-n));}
static const uint32_t K[64]={
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
static void block(S*s,const uint8_t*p){uint32_t w[64],a,b,c,d,e,f,g,h;for(int i=0;i<16;i++)w[i]=((uint32_t)p[4*i]<<24)|((uint32_t)p[4*i+1]<<16)|((uint32_t)p[4*i+2]<<8)|p[4*i+3];for(int i=16;i<64;i++){uint32_t x=w[i-15],y=w[i-2];uint32_t q=R(x,7)^R(x,18)^(x>>3),z=R(y,17)^R(y,19)^(y>>10);w[i]=w[i-16]+q+w[i-7]+z;}a=s->h[0];b=s->h[1];c=s->h[2];d=s->h[3];e=s->h[4];f=s->h[5];g=s->h[6];h=s->h[7];for(int i=0;i<64;i++){uint32_t S1=R(e,6)^R(e,11)^R(e,25),ch=(e&f)^((~e)&g),t1=h+S1+ch+K[i]+w[i],S0=R(a,2)^R(a,13)^R(a,22),maj=(a&b)^(a&c)^(b&c),t2=S0+maj;h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;}s->h[0]+=a;s->h[1]+=b;s->h[2]+=c;s->h[3]+=d;s->h[4]+=e;s->h[5]+=f;s->h[6]+=g;s->h[7]+=h;}
static void init(S*s){uint32_t h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};memcpy(s->h,h,sizeof h);s->bits=0;s->n=0;}
static void upd(S*s,const uint8_t*p,size_t n){s->bits+=(uint64_t)n*8;while(n){size_t k=64-s->n;if(k>n)k=n;memcpy(s->b+s->n,p,k);s->n+=k;p+=k;n-=k;if(s->n==64){block(s,s->b);s->n=0;}}}
static void fin(S*s,uint8_t o[32]){uint64_t bits=s->bits;s->b[s->n++]=0x80;if(s->n>56){while(s->n<64)s->b[s->n++]=0;block(s,s->b);s->n=0;}while(s->n<56)s->b[s->n++]=0;for(int i=7;i>=0;i--)s->b[s->n++]=(uint8_t)(bits>>(i*8));block(s,s->b);for(int i=0;i<8;i++){o[4*i]=s->h[i]>>24;o[4*i+1]=s->h[i]>>16;o[4*i+2]=s->h[i]>>8;o[4*i+3]=s->h[i];}}
static void hash(const uint8_t*p,size_t n,uint8_t o[32]){S s;init(&s);upd(&s,p,n);fin(&s,o);}
ali_verify_result ali_verify_capsule(const uint8_t *buf,size_t len,uint64_t min_generation){
 if(!buf||len<sizeof(ali_capsule_header)) return ALI_VERIFY_INVALID;
 ali_capsule_header h; memcpy(&h,buf,sizeof h);
 if(h.magic!=ALI_CAPSULE_MAGIC) return ALI_VERIFY_INVALID;
 if(h.version!=ALI_CAPSULE_VERSION) return ALI_VERIFY_UNSUPPORTED;
 if(h.generation<min_generation) return ALI_VERIFY_ROLLBACK;
 if((size_t)h.payload_len>len-sizeof h) return ALI_VERIFY_INVALID;
 if(sizeof h+(size_t)h.payload_len!=len) return ALI_VERIFY_INVALID;
 uint8_t got[32]; hash(buf+sizeof h,h.payload_len,got);
 return memcmp(got,h.payload_sha256,32)==0?ALI_VERIFY_VERIFIED:ALI_VERIFY_INVALID;
}
