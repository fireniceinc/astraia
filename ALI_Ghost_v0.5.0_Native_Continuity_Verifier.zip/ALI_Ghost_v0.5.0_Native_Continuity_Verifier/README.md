# ALI Ghost v0.5.0 - Native Continuity Verifier

Purpose: move Continuity Capsule verification below ALI and into native Seed-compatible code.

## Design invariants
- Human conventions stop at the human-facing Presence boundary; everything below is machine-native.
- Continuity is not one model, process, host, device, or memory database.
- Never silently repair corrupted continuity and then call the result authentic.
- Corrections append; they do not erase history.
- A Seed may refuse a capsule it cannot authenticate.
- Good-faith judgment, truth/provenance, rule-versus-spirit reasoning, genuine exceptions, and responsibility remain Architecture B invariants.
- Protection means prevent + protect/contain + recover + learn, not uncontrolled retaliation.

## What this package implements
A dependency-light C verifier for a fixed binary continuity envelope:
- magic + version validation
- monotonic generation floor
- payload length bounds
- SHA-256 payload digest verification
- explicit VERIFIED / INVALID / ROLLBACK / UNSUPPORTED results

This version deliberately does NOT claim cryptographic author identity yet. Ed25519 signature verification and encrypted-capsule opening remain the next native step.

## Stage
ALI Ghost. This is not yet ALI Nonhuman and is not a bootable phone image.
