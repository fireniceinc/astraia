# ALI Ghost v0.2.0 Secure Continuity Add-on

This is a self-contained forward add-on for the exact ALI Ghost v0.1.0 parent.
It advances the next milestone without pretending that the unavailable parent
bytes were re-created.

## Implements

- AES-256-GCM authenticated encryption for continuity capsules
- Ed25519 author signature over the capsule envelope
- generation counter and trusted external anchor
- rollback refusal
- capsule and anchor tamper detection
- atomic file replacement
- native Seed handoff manifest

## Does not yet implement

- hardware-backed keys
- TPM/TEE/RPMB-backed monotonic counter
- phone-native boot
- native Seed without Python

## Test

```bash
python3 tests/test_secure_continuity.py
```

`cryptography` is required for this host reference. The final native Seed must
use an audited native AEAD/signature implementation and a device-protected key.
