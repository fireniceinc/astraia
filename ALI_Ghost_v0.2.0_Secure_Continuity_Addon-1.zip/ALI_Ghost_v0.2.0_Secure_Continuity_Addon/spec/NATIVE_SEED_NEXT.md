# Native Seed next boundary

1. Replace the hosted Python verifier with a freestanding native verifier.
2. Move the private author key out of ordinary storage.
3. Bind the minimum generation to a trusted external or device monotonic anchor.
4. Add A/B capsule slots and transactional activation.
5. Measure the next-stage image before handoff.
6. Boot first in an emulator, then on physical hardware only with recovery.
