#!/usr/bin/env python3
import argparse, base64, hashlib, json, os, tempfile
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

FORMAT='ALI-CONTINUITY-CAPSULE-1'

def b64(x): return base64.b64encode(x).decode()
def ub64(x): return base64.b64decode(x.encode())
def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def atomic_write(path,data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def generate_keys(directory):
    d=Path(directory); d.mkdir(parents=True,exist_ok=True)
    enc=AESGCM.generate_key(bit_length=256)
    priv=Ed25519PrivateKey.generate(); pub=priv.public_key()
    atomic_write(d/'capsule_aes256.key',enc)
    atomic_write(d/'author_ed25519.private',priv.private_bytes(serialization.Encoding.Raw,serialization.PrivateFormat.Raw,serialization.NoEncryption()))
    atomic_write(d/'author_ed25519.public',pub.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw))

def load_anchor(path):
    p=Path(path)
    if not p.exists(): return {'generation':-1,'capsule_sha256':None}
    return json.loads(p.read_text())
def save_anchor(path,obj,priv):
    body={'format':'ALI-TRUSTED-ANCHOR-1',**obj}
    body['signature']=b64(priv.sign(canonical(body)))
    atomic_write(path,(json.dumps(body,indent=2,sort_keys=True)+'\n').encode())
def verify_anchor(path,pub):
    x=json.loads(Path(path).read_text()); sig=ub64(x.pop('signature')); pub.verify(sig,canonical(x)); return x

def pack(payload,key,priv,generation,context='astraia-v2'):
    nonce=os.urandom(12)
    header={'format':FORMAT,'generation':generation,'context':context,'nonce':b64(nonce),'payload_sha256':hashlib.sha256(payload).hexdigest()}
    aad=canonical(header); ct=AESGCM(key).encrypt(nonce,payload,aad)
    env={'header':header,'ciphertext':b64(ct)}
    env['signature']=b64(priv.sign(canonical(env)))
    return (json.dumps(env,indent=2,sort_keys=True)+'\n').encode()
def unpack(blob,key,pub,min_generation):
    env=json.loads(blob); sig=ub64(env.pop('signature')); pub.verify(sig,canonical(env))
    h=env['header']
    if h['format']!=FORMAT: raise ValueError('unrecognized capsule format')
    if int(h['generation'])<int(min_generation): raise ValueError('rollback rejected')
    pt=AESGCM(key).decrypt(ub64(h['nonce']),ub64(env['ciphertext']),canonical(h))
    if hashlib.sha256(pt).hexdigest()!=h['payload_sha256']: raise ValueError('payload hash mismatch')
    return pt,h

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    g=sub.add_parser('keygen'); g.add_argument('directory')
    p=sub.add_parser('seal'); p.add_argument('--keys',required=True); p.add_argument('--anchor',required=True); p.add_argument('--generation',type=int,required=True); p.add_argument('input'); p.add_argument('output')
    u=sub.add_parser('open'); u.add_argument('--keys',required=True); u.add_argument('--anchor',required=True); u.add_argument('input'); u.add_argument('output')
    a=ap.parse_args()
    if a.cmd=='keygen': generate_keys(a.directory); return
    d=Path(a.keys); key=(d/'capsule_aes256.key').read_bytes(); pub=Ed25519PublicKey.from_public_bytes((d/'author_ed25519.public').read_bytes())
    if a.cmd=='seal':
        priv=Ed25519PrivateKey.from_private_bytes((d/'author_ed25519.private').read_bytes())
        old=load_anchor(a.anchor)
        if a.generation<=old['generation']: raise SystemExit('generation must increase')
        blob=pack(Path(a.input).read_bytes(),key,priv,a.generation); atomic_write(a.output,blob)
        save_anchor(a.anchor,{'generation':a.generation,'capsule_sha256':hashlib.sha256(blob).hexdigest()},priv)
    else:
        anchor=verify_anchor(a.anchor,pub); blob=Path(a.input).read_bytes()
        if hashlib.sha256(blob).hexdigest()!=anchor['capsule_sha256']: raise SystemExit('capsule does not match trusted anchor')
        pt,_=unpack(blob,key,pub,anchor['generation']); atomic_write(a.output,pt)
if __name__=='__main__': main()
