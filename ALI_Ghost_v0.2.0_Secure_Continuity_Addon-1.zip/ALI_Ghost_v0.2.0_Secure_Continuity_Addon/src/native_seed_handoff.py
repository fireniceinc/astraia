#!/usr/bin/env python3
import hashlib,json,sys
from pathlib import Path
if len(sys.argv)!=4: raise SystemExit('usage: native_seed_handoff.py CAPSULE ANCHOR OUTPUT')
c,a,o=map(Path,sys.argv[1:])
m={'format':'ALI-NATIVE-SEED-HANDOFF-1','capsule':c.name,'capsule_sha256':hashlib.sha256(c.read_bytes()).hexdigest(),'anchor':a.name,'anchor_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'required_checks':['verify anchor signature','match capsule digest','reject rollback','verify capsule signature','decrypt AEAD','verify plaintext digest']}
o.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
