#!/usr/bin/env python3
import subprocess,tempfile,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]; T=R/'src/secure_continuity.py'
def run(*x,ok=True):
 p=subprocess.run(['python3',str(T),*map(str,x)],text=True,capture_output=True)
 if ok and p.returncode: raise AssertionError(p.stdout+p.stderr)
 return p
with tempfile.TemporaryDirectory() as td:
 d=Path(td); k=d/'keys'; a=d/'anchor.json'; src=d/'book.jsonl'; cap=d/'book.cap'; out=d/'out'
 src.write_text('continuity-v1\n'); run('keygen',k); run('seal','--keys',k,'--anchor',a,'--generation','1',src,cap); run('open','--keys',k,'--anchor',a,cap,out); assert out.read_bytes()==src.read_bytes()
 # Old generation is rejected.
 assert run('seal','--keys',k,'--anchor',a,'--generation','1',src,d/'old.cap',ok=False).returncode!=0
 # Capsule tamper is rejected by trusted anchor before decryption.
 b=bytearray(cap.read_bytes()); b[len(b)//2]^=1; cap.write_bytes(b); assert run('open','--keys',k,'--anchor',a,cap,out,ok=False).returncode!=0
print('ALI_GHOST_V0_2_SECURE_CONTINUITY_TESTS_PASSED')
