# UEFI development target

The first firmware target is a development/emulation envelope, not the final
phone boot path. The design will use firmware boot services for pre-boot
execution, memory-map acquisition, console, and media access, then transfer a
measured handoff to the native Seed.

The current host-native C scaffold proves A/B state transition and rollback
logic only. It does not claim UEFI conformance.
