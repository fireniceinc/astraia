#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cd "$ROOT"
sh build.sh >/dev/null
D=$(mktemp -d); trap 'rm -rf "$D"' EXIT
./build/ali-stage0 "$D" init | grep '"active":"A"' >/dev/null
./build/ali-stage0 "$D" observe >/dev/null
test -s "$D/machine_stars.json"
./build/ali-stage0 "$D" install B 2 | grep '"pending":"B"' >/dev/null
./build/ali-stage0 "$D" boot | grep 'boot pending slot B' >/dev/null
./build/ali-stage0 "$D" confirm | grep '"active":"B"' >/dev/null
./build/ali-stage0 "$D" install A 3 >/dev/null
./build/ali-stage0 "$D" boot >/dev/null
set +e
./build/ali-stage0 "$D" boot >/tmp/ali-stage0-test.out 2>&1
RC=$?
set -e
test "$RC" -eq 4
grep 'rollback from A to B' /tmp/ali-stage0-test.out >/dev/null
set +e
./build/ali-stage0 "$D" install A 2 >/dev/null 2>&1
RC=$?
set -e
test "$RC" -eq 3
printf '%s\n' 'ALI_GHOST_V0_3_NATIVE_STAGE0_TESTS_PASSED'
