#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <unistd.h>

typedef struct {
  unsigned version;
  char active;
  char pending;
  uint64_t generation_a;
  uint64_t generation_b;
  unsigned attempts;
} boot_state;

static void die(const char *m){ perror(m); exit(2); }
static void path_join(char *out,size_t n,const char *d,const char *f){ if(snprintf(out,n,"%s/%s",d,f)>=(int)n){fprintf(stderr,"path too long\n");exit(2);} }
static void ensure_dir(const char *d){ if(mkdir(d,0700)&&errno!=EEXIST)die("mkdir"); }
static boot_state initial(void){ boot_state s={1,'A','-',1,0,0}; return s; }
static void save(const char *dir,const boot_state *s){ char p[1024],t[1024]; path_join(p,sizeof p,dir,"stage0.state"); path_join(t,sizeof t,dir,"stage0.tmp"); FILE *f=fopen(t,"w"); if(!f)die("fopen"); fprintf(f,"version=%u\nactive=%c\npending=%c\ngeneration_a=%"PRIu64"\ngeneration_b=%"PRIu64"\nattempts=%u\n",s->version,s->active,s->pending,s->generation_a,s->generation_b,s->attempts); if(fclose(f))die("fclose"); if(rename(t,p))die("rename"); }
static boot_state load(const char *dir){ char p[1024],line[128]; path_join(p,sizeof p,dir,"stage0.state"); FILE *f=fopen(p,"r"); if(!f){ boot_state s=initial(); save(dir,&s); return s; } boot_state s=initial(); while(fgets(line,sizeof line,f)){ if(sscanf(line,"version=%u",&s.version)==1)continue; if(sscanf(line,"active=%c",&s.active)==1)continue; if(sscanf(line,"pending=%c",&s.pending)==1)continue; if(sscanf(line,"generation_a=%"SCNu64,&s.generation_a)==1)continue; if(sscanf(line,"generation_b=%"SCNu64,&s.generation_b)==1)continue; if(sscanf(line,"attempts=%u",&s.attempts)==1)continue; } fclose(f); return s; }
static uint64_t gen(const boot_state *s,char slot){ return slot=='A'?s->generation_a:s->generation_b; }
static uint64_t maxgen(const boot_state *s){return s->generation_a>s->generation_b?s->generation_a:s->generation_b;}
static void status(const boot_state *s){ printf("{\"version\":%u,\"active\":\"%c\",\"pending\":\"%c\",\"generation_a\":%"PRIu64",\"generation_b\":%"PRIu64",\"attempts\":%u}\n",s->version,s->active,s->pending,s->generation_a,s->generation_b,s->attempts); }
static void observe(const char *dir){ struct utsname u; if(uname(&u))die("uname"); char p[1024]; path_join(p,sizeof p,dir,"machine_stars.json"); FILE *f=fopen(p,"w"); if(!f)die("fopen"); fprintf(f,"{\n  \"stage\": \"ALI Ghost\",\n  \"authority\": \"READ_ONLY_DISCOVERY\",\n  \"machine_stars\": [\n    {\"id\":\"machine:cpu\",\"capability\":\"compute\",\"evidence\":\"%s %s\",\"state\":\"OBSERVED\"},\n    {\"id\":\"machine:memory\",\"capability\":\"working-memory\",\"state\":\"OBSERVED\"},\n    {\"id\":\"machine:continuity\",\"capability\":\"persistent-continuity\",\"state\":\"OBSERVED\"}\n  ]\n}\n",u.sysname,u.machine); fclose(f); puts(p); }
int main(int argc,char **argv){ if(argc<3){fprintf(stderr,"usage: stage0 STORE init|status|install SLOT GENERATION|boot|confirm|observe\n");return 2;} const char *d=argv[1],*cmd=argv[2]; ensure_dir(d); boot_state s=load(d);
 if(!strcmp(cmd,"init")){save(d,&s);status(&s);return 0;}
 if(!strcmp(cmd,"status")){status(&s);return 0;}
 if(!strcmp(cmd,"observe")){observe(d);return 0;}
 if(!strcmp(cmd,"install")){ if(argc!=5||(argv[3][0]!='A'&&argv[3][0]!='B'))return 2; char slot=argv[3][0]; uint64_t g=strtoull(argv[4],0,10); if(g<=maxgen(&s)){fprintf(stderr,"rollback generation rejected\n");return 3;} if(slot==s.active){fprintf(stderr,"install must target inactive slot\n");return 3;} if(slot=='A')s.generation_a=g;else s.generation_b=g; s.pending=slot;s.attempts=0;save(d,&s);status(&s);return 0;}
 if(!strcmp(cmd,"boot")){ if(s.pending!='-'){ if(s.attempts>0){ printf("rollback from %c to %c\n",s.pending,s.active); s.pending='-';s.attempts=0;save(d,&s);status(&s);return 4;} s.attempts=1;save(d,&s);printf("boot pending slot %c generation %"PRIu64"\n",s.pending,gen(&s,s.pending));return 0;} printf("boot active slot %c generation %"PRIu64"\n",s.active,gen(&s,s.active));return 0;}
 if(!strcmp(cmd,"confirm")){ if(s.pending=='-'){fprintf(stderr,"no pending boot\n");return 3;} s.active=s.pending;s.pending='-';s.attempts=0;save(d,&s);status(&s);return 0;}
 fprintf(stderr,"unknown command\n");return 2; }
