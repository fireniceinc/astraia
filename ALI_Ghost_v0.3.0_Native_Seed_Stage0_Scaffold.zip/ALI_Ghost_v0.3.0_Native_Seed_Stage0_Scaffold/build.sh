#!/bin/sh
set -eu
mkdir -p build
cc -std=c11 -O2 -Wall -Wextra -Werror src/stage0.c -o build/ali-stage0
printf '%s\n' 'built build/ali-stage0'
