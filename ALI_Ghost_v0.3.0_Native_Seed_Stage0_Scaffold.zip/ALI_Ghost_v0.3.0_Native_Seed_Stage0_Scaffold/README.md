# ALI Ghost v0.3.0 Native Seed / Stage-0 Scaffold

This milestone removes Python from the **boot-state and A/B recovery controller**.
The included C program is host-native and dependency-free. It is not yet a UEFI
image, Android boot image, phone kernel, or cryptographic capsule verifier.

## What works

- native C build
- Stage-0 state initialization
- A/B Seed slots
- monotonic generation activation policy
- pending boot and explicit boot confirmation
- automatic rollback after an unconfirmed attempted boot
- read-only minimum-host observation
- Machine Star JSON projection
- recovery test

## Build and test

```bash
sh build.sh
sh tests/test_stage0.sh
```

## Next

1. Integrate the v0.2 capsule checks into native code using audited crypto.
2. Compile as a `no_std`/freestanding UEFI development image.
3. Boot under QEMU/OVMF when those tools are available.
4. Obtain memory map and storage/console protocols from firmware.
5. Preserve A/B recovery before testing any physical phone.
